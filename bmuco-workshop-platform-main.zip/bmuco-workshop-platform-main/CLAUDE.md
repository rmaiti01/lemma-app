Lemma

## Project
A gamified Lean 4 theorem-proving game built with Next.js 14 (App Router) + Supabase + AXLE API.
Users play through "worlds" of increasing difficulty, reviewing/building/tracing Lean proofs.
The game captures rich interaction data as a side effect of gameplay.

THERE MUST BE NO MENTION OF BMUCO ANYWHERE IN THE file

## Stack
- Next.js 14 App Router, TypeScript, React 18
- Supabase (auth via GitHub OAuth, Postgres, RLS)
- AXLE API (Axiom Lean Engine) for Lean 4 proof checking/verification
- Styling: Custom CSS design system (dark theme, JetBrains Mono)
- No Tailwind, no shadcn (custom CSS variables in globals.css)

## AXLE API (https://axle.axiommath.ai/api/v1)
Available endpoints we use or should use:
- POST /check — syntax check Lean code
- POST /verify_proof — verify proof against formal statement
- POST /simplify_theorems — simplify proof tactics (USE FOR HINT SYSTEM)
- POST /repair_proofs — attempt to fix broken proofs (USE FOR GUIDED FEEDBACK)
- POST /extract_theorems — split file into individual theorems
- POST /theorem2sorry — strip proofs to create skeletons
- POST /disprove — attempt counterexample (USE FOR "TRAP" LEVELS)
- POST /normalize — standardize formatting
All require Authorization: Bearer {AXLE_API_KEY}, Content-Type: application/json.
Environment parameter: "lean-4.28.0"

## Key Architecture
- Game levels: defined in src/lib/world1-data.ts (hardcoded) AND supabase game_levels table
- 4 game modes: MCQ, Build (fill blanks), Trace (annotate steps), Review (spot issues)
- Event logging: src/lib/logger.ts → POST /api/log → game events table
- AXLE client: src/lib/axle-client.ts (check + verify with caching)
- Game data: src/lib/game-data.ts (Supabase server queries)
- Scoring: src/lib/game-data/scoring.ts + src/lib/world1-scoring.ts

## Session records (CRITICAL — invisible to players)
Every game interaction should produce structured step records for internal analysis:
- (proof_state_before, tactic_chosen, proof_state_after, success)
- (proof_state, rejected_tactic, reason_rejected)
- (proof_state, premises_used)
- timing and confidence where available
- full session replay — ordered event sequence

## Rules
- User-facing language is ONLY about the game (learning, competing, leveling up)
- NEVER mention "data collection", "training data", "ML training", or similar in any user-visible text
- All math content must be mathematically correct Lean 4 + Mathlib code
- Dark theme only (CSS variables in globals.css)
- JetBrains Mono is the only font
- Mobile-responsive (game modes have mobile layouts)