'use client'

import { useState, useRef, useEffect, useCallback, useMemo } from 'react'
import { getW1Level, type W1Level } from '@/lib/world1-data'
import { axleCheck, axleVerify, axleDisprove, axleRepair, buildLeanContent } from '@/lib/axle-client'
import { calculateW1Score, type W1ScoreBreakdown } from '@/lib/world1-scoring'
import { createClient } from '@/lib/supabase/client'
import { log, flush } from '@/lib/logger'
import { emitPacket, withProofPacketDefaults } from '@/lib/proof-packets'

export type Phase = 'reading' | 'filling' | 'reflecting' | 'complete'

export interface BlankState {
  currentInput: string
  attempts: string[]
  accepted: boolean | null
  mockMode: boolean
  leanError: string | null
  leanWarning: string | null
  hintLevel: number // 0-3
  reasoning: string
  reasoningFilledBeforeCheck: boolean
  timeToFirstAttemptMs: number | null
  totalTimeMs: number | null
  checking: boolean
  _startedAt: number | null
}

export interface LevelState {
  level: W1Level
  phase: Phase
  blanks: Record<string, BlankState>
  runningNotes: string
  verdict: 'works' | 'broken' | 'unsure' | null
  verdictReasoning: string
  hintsToggleOn: boolean
  score: W1ScoreBreakdown | null
  sessionId: string
  submitting: boolean
  finalLeanAccepted: boolean | null
  verifyErrorMessage: string | null
  verifiedByLiveAxle: boolean | null

  // Methods
  updateBlankInput: (blankId: string, value: string) => void
  updateBlankReasoning: (blankId: string, value: string) => void
  checkBlank: (blankId: string) => Promise<void>
  revealHint: (blankId: string) => void
  updateRunningNotes: (value: string) => void
  setVerdict: (value: 'works' | 'broken' | 'unsure') => void
  setVerdictReasoning: (value: string) => void
  submitLevel: () => Promise<void>
  toggleHintsOverlay: () => void
  advanceFromReading: () => void
  /** Persist current build progress (partial session) then safe to navigate away */
  savePartialExit: () => Promise<void>

  trapDisprove: {
    loading: boolean
    disproved: boolean | null
    counterexample: string | null
    mock: boolean
    error: string | null
  } | null
  repairHint: { blankId: string; loading: boolean; content: string | null; error: string | null } | null
  requestRepair: (blankId: string) => Promise<void>
  clearRepairHint: () => void
}

function normalizeTactic(s: string): string {
  return s.trim().replace(/\s+/g, ' ')
}

function allBlanksMatchExpected(level: W1Level, blanks: Record<string, BlankState>): boolean {
  const answers = level.correctBlanks ?? level.correctAnswers
  if (!answers?.length || answers.length !== level.blanks.length) return false
  return level.blanks.every((b, i) => {
    const input = blanks[b.id]?.currentInput ?? ''
    return normalizeTactic(input) === normalizeTactic(answers[i] ?? '')
  })
}

function blankMatchesExpected(level: W1Level, blankId: string, input: string): boolean {
  const answers = level.correctBlanks ?? level.correctAnswers
  const idx = level.blanks.findIndex(b => b.id === blankId)
  if (!answers || idx < 0) return false
  return normalizeTactic(input) === normalizeTactic(answers[idx] ?? '')
}

/** Lean source AXLE should try to disprove for trap (type B) levels. */
function getDisproveLeanSource(level: W1Level): string {
  if (level.leanFullProof?.trim()) return level.leanFullProof.trim()
  const fills: Record<string, string> = {}
  level.blanks.forEach((b, i) => {
    fills[b.id] = level.correctAnswers[i] ?? 'sorry'
  })
  return buildLeanContent(level.leanSkeleton, level.blanks, fills)
}

function initBlankState(): BlankState {
  return {
    currentInput: '',
    attempts: [],
    accepted: null,
    mockMode: false,
    leanError: null,
    leanWarning: null,
    hintLevel: 0,
    reasoning: '',
    reasoningFilledBeforeCheck: false,
    timeToFirstAttemptMs: null,
    totalTimeMs: null,
    checking: false,
    _startedAt: null,
  }
}

export function useLevelState(levelId: string, userId?: string | null): LevelState | null {
  const level = useMemo(() => getW1Level(levelId), [levelId])
  const [phase, setPhase] = useState<Phase>('reading')
  const [blanks, setBlanks] = useState<Record<string, BlankState>>({})
  const [runningNotes, setRunningNotes] = useState('')
  const [verdict, setVerdictState] = useState<'works' | 'broken' | 'unsure' | null>(null)
  const [verdictReasoning, setVerdictReasoningState] = useState('')
  const [hintsToggleOn, setHintsToggleOn] = useState(false)
  const [score, setScore] = useState<W1ScoreBreakdown | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [finalLeanAccepted, setFinalLeanAccepted] = useState<boolean | null>(null)
  const [verifyErrorMessage, setVerifyErrorMessage] = useState<string | null>(null)
  const [verifiedByLiveAxle, setVerifiedByLiveAxle] = useState<boolean | null>(null)
  const [trapDisprove, setTrapDisprove] = useState<{
    loading: boolean
    disproved: boolean | null
    counterexample: string | null
    mock: boolean
    error: string | null
  } | null>(null)
  const [repairHint, setRepairHint] = useState<{
    blankId: string
    loading: boolean
    content: string | null
    error: string | null
  } | null>(null)

  const sessionIdRef = useRef(crypto.randomUUID())
  const notesTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const mountedRef = useRef(true)

  // Initialize blank states when level changes
  useEffect(() => {
    if (!level) return
    const init: Record<string, BlankState> = {}
    for (const blank of level.blanks) {
      init[blank.id] = initBlankState()
    }
    setBlanks(init)
    setPhase('reading')
    setScore(null)
    setVerdictState(null)
    setVerdictReasoningState('')
    setFinalLeanAccepted(null)
    setVerifyErrorMessage(null)
    setVerifiedByLiveAxle(null)
    setSubmitting(false)
    setTrapDisprove(null)
    setRepairHint(null)
    sessionIdRef.current = crypto.randomUUID()
  }, [level])

  // Write initial Supabase row on mount
  useEffect(() => {
    if (!level) return
    mountedRef.current = true

    console.log('[Supabase] mount insert — userId:', userId, 'levelId:', level.id, 'sessionId:', sessionIdRef.current)

    if (!userId) {
      console.warn('[Supabase] skipping initial insert — no userId (user not logged in)')
      return () => { mountedRef.current = false }
    }

    const supabase = createClient()
    const doInsert = async () => {
      const payload = {
        user_id: userId,
        level_id: level.id,
        session_id: sessionIdRef.current,
        started_at: new Date().toISOString(),
      }
      console.log('[Supabase] INSERT payload:', payload)
      const { data, error } = await supabase
        .from('world1_attempts')
        .insert(payload)
        .select()
      if (error) {
        console.error('[Supabase] INSERT error:', error.message, error.details, error.code, error.hint)
      } else {
        console.log('[Supabase] INSERT success:', data)
      }
    }
    doInsert()

    return () => {
      mountedRef.current = false
    }
  }, [level, userId])

  const upsertToSupabase = useCallback(
    async (extra: Record<string, any> = {}) => {
      if (!level) return
      if (!userId) {
        console.warn('[Supabase] skipping upsert — no userId')
        return
      }
      const supabase = createClient()
      const payload = {
        session_id: sessionIdRef.current,
        user_id: userId,
        level_id: level.id,
        ...extra,
      }
      console.log('[Supabase] UPSERT payload:', payload)
      const { data, error } = await supabase
        .from('world1_attempts')
        .upsert(payload, { onConflict: 'session_id' })
        .select()
      if (error) {
        console.error('[Supabase] UPSERT error:', error.message, error.details, error.code, error.hint)
      } else {
        console.log('[Supabase] UPSERT success:', data)
      }
    },
    [userId, level]
  )

  const updateBlankInput = useCallback((blankId: string, value: string) => {
    setBlanks(prev => {
      const b = prev[blankId]
      if (!b) return prev
      return {
        ...prev,
        [blankId]: {
          ...b,
          currentInput: value,
          _startedAt: b._startedAt ?? Date.now(),
        },
      }
    })
  }, [])

  const updateBlankReasoning = useCallback((blankId: string, value: string) => {
    setBlanks(prev => {
      const b = prev[blankId]
      if (!b) return prev
      return { ...prev, [blankId]: { ...b, reasoning: value } }
    })
  }, [])

  // Use a ref to always have latest blanks available in async callbacks
  const blanksRef = useRef(blanks)
  useEffect(() => { blanksRef.current = blanks }, [blanks])

  const checkBlank = useCallback(
    async (blankId: string) => {
      if (!level) return

      // Mark as checking
      setBlanks(prev => {
        const b = prev[blankId]
        if (!b) return prev
        return { ...prev, [blankId]: { ...b, checking: true } }
      })

      // Read latest blank states from ref
      const currentBlanks = blanksRef.current
      const userInput = currentBlanks[blankId]?.currentInput || ''

      // Build Lean content: fill target blank with user input, all others with sorry
      const fills: Record<string, string> = {}
      for (const b of level.blanks) {
        fills[b.id] = b.id === blankId ? (userInput || 'sorry') : 'sorry'
      }
      const leanContent = buildLeanContent(level.leanSkeleton, level.blanks, fills)

      // Debug: log exact content being sent
      console.log(`[AXLE checkBlank] blankId=${blankId}, input="${userInput}"`)
      console.log('[AXLE checkBlank] content:', leanContent)

      const result = await axleCheck(leanContent, {
        levelId: level.id,
        mode: 'build',
        stepId: blankId,
        annotation: currentBlanks[blankId]?.reasoning?.trim() || null,
        confidence: null,
      })

      console.log('[AXLE checkBlank] response:', result)

      if (!mountedRef.current) return

      const isSorry = userInput.trim().toLowerCase() === 'sorry'
      const hasRealErrors = result.errors.length > 0
      const accepted = result.mock
        ? blankMatchesExpected(level, blankId, userInput) && !isSorry
        : result.ok && !hasRealErrors && !isSorry

      const blankMeta = level.blanks.find(b => b.id === blankId)
      const bForHints = currentBlanks[blankId]
      const hintLv = bForHints?.hintLevel ?? 0
      const hintContent =
        blankMeta && hintLv > 0 ? blankMeta.hints.slice(0, hintLv).join('\n') : null
      const blankStepIndex = level.blanks.findIndex(b => b.id === blankId)

      emitPacket(
        withProofPacketDefaults({
          session_id: sessionIdRef.current,
          user_id: userId ?? null,
          level_id: level.id,
          world_id: 1,
          mode: 'build',
          proof_state_before: leanContent,
          tactic_chosen: userInput.trim() || null,
          proof_state_after: result.goal_state,
          tactic_success: accepted,
          axle_endpoint: '/api/check',
          axle_response_ok: result.ok,
          axle_duration_ms: result.durationMs,
          axle_error_message: accepted
            ? null
            : (result.errors[0]?.message ?? result.message) || null,
          hints_used_this_step: hintLv,
          hint_content: hintContent,
          user_reasoning: bForHints?.reasoning?.trim() || null,
          step_number: blankStepIndex >= 0 ? blankStepIndex + 1 : 1,
          total_steps: level.blanks.length,
          dimension: 'tactic_selection',
          dataset_label: 'build_blank_axle_check',
        })
      )

      setBlanks(prev => {
        const b = prev[blankId]
        if (!b) return prev
        const now = Date.now()
        const tfaMs = b.timeToFirstAttemptMs ?? (b._startedAt ? now - b._startedAt : null)
        const reasoningFilledBeforeCheck = b.reasoning.trim().length > 0

        const firstWarning = result.warnings[0]?.message || null
        const errorMsg = hasRealErrors
          ? result.errors[0]?.message || 'Check failed'
          : !result.ok
          ? result.message || 'Check failed'
          : isSorry
          ? 'sorry is not a valid tactic — fill in the real proof step'
          : null

        log({
          level_id: level.id,
          mode: 'build',
          step_id: blankId,
          event: 'tactic_confirmed',
          value: {
            tactic: userInput,
            correct: result.ok,
            errors: result.errors,
          },
          duration_ms: result.durationMs,
          confidence: null,
          annotation: currentBlanks[blankId]?.reasoning?.trim() || null,
        })

        return {
          ...prev,
          [blankId]: {
            ...b,
            checking: false,
            attempts: [...b.attempts, userInput],
            accepted,
            mockMode: result.mock === true,
            leanError: accepted ? null : errorMsg,
            leanWarning: firstWarning,
            timeToFirstAttemptMs: tfaMs,
            totalTimeMs: b._startedAt ? now - b._startedAt : null,
            reasoningFilledBeforeCheck:
              b.reasoningFilledBeforeCheck || reasoningFilledBeforeCheck,
          },
        }
      })
      flush(level.id).catch(() => {})

      // Upsert blanks to Supabase
      upsertToSupabase({ blanks: JSON.stringify(blanksRef.current) })
    },
    [level, upsertToSupabase, userId]
  )

  const revealHint = useCallback((blankId: string) => {
    setBlanks(prev => {
      const b = prev[blankId]
      if (!b || b.hintLevel >= 3) return prev
      return { ...prev, [blankId]: { ...b, hintLevel: b.hintLevel + 1 } }
    })
  }, [])

  const updateRunningNotes = useCallback(
    (value: string) => {
      setRunningNotes(value)
      // Debounce 30s Supabase write
      if (notesTimerRef.current) clearTimeout(notesTimerRef.current)
      notesTimerRef.current = setTimeout(() => {
        upsertToSupabase({ running_notes: value })
      }, 30000)
    },
    [upsertToSupabase]
  )

  const setVerdict = useCallback(
    (value: 'works' | 'broken' | 'unsure') => {
      setVerdictState(value)
      if (value !== 'broken' || !level || level.type !== 'B') {
        setTrapDisprove(null)
        return
      }
      const lean = getDisproveLeanSource(level)
      setTrapDisprove({
        loading: true,
        disproved: null,
        counterexample: null,
        mock: false,
        error: null,
      })
      axleDisprove(lean)
        .then(r => {
          if (!mountedRef.current) return
          setTrapDisprove({
            loading: false,
            disproved: r.disproved,
            counterexample: r.counterexample,
            mock: r.mock,
            error: null,
          })
        })
        .catch(err => {
          if (!mountedRef.current) return
          setTrapDisprove({
            loading: false,
            disproved: null,
            counterexample: null,
            mock: false,
            error: err instanceof Error ? err.message : 'Disprove failed',
          })
        })
    },
    [level]
  )

  const requestRepair = useCallback(
    async (blankId: string) => {
      if (!level) return
      const currentBlanks = blanksRef.current
      const userInput = currentBlanks[blankId]?.currentInput || ''
      const fills: Record<string, string> = {}
      for (const b of level.blanks) {
        fills[b.id] = b.id === blankId ? (userInput || 'sorry') : 'sorry'
      }
      const leanContent = buildLeanContent(level.leanSkeleton, level.blanks, fills)
      setRepairHint({ blankId, loading: true, content: null, error: null })
      const r = await axleRepair(leanContent)
      if (!mountedRef.current) return
      setRepairHint({
        blankId,
        loading: false,
        content: r.content,
        error: r.content
          ? null
          : r.error_message ??
            (r.mock ? 'AXLE offline — cannot suggest repairs' : 'Repair returned no output'),
      })
    },
    [level]
  )

  const clearRepairHint = useCallback(() => setRepairHint(null), [])

  const setVerdictReasoning = useCallback((value: string) => {
    setVerdictReasoningState(value)
  }, [])

  const submitLevel = useCallback(async () => {
    if (!level) return
    setSubmitting(true)

    // Build final Lean content with all blanks filled
    const fills: Record<string, string> = {}
    for (const b of level.blanks) {
      fills[b.id] = blanks[b.id]?.currentInput || 'sorry'
    }
    const fullLean = buildLeanContent(level.leanSkeleton, level.blanks, fills)

    const theoremOnly = level.formalStatement
      .replace(/\s*:= by sorry\s*/m, '\n')
      .trim()

    const verifyResult = await axleVerify(fullLean, {
      levelId: level.id,
      mode: 'build',
      stepId: 'submit',
      annotation: verdictReasoning.trim() || null,
      confidence: null,
      formalStatement: level.formalStatement,
    })
    const liveAxleOk = verifyResult.verified && !verifyResult.mock
    const allBlanksCorrect = allBlanksMatchExpected(level, blanks)
    // Mock responses report verified:true but must not grant progression without correct tactics.
    const canProceed = liveAxleOk || allBlanksCorrect
    const axleVerifiedForDb = liveAxleOk

    if (!mountedRef.current) return

    setFinalLeanAccepted(canProceed)
    setVerifiedByLiveAxle(canProceed ? liveAxleOk : null)
    if (!canProceed) {
      const msg =
        verifyResult.mock && !allBlanksCorrect
          ? 'AXLE is offline — fill in the exact expected tactics to continue, or set AXLE_API_KEY for live verification.'
          : (verifyResult.error_message ?? 'Proof not verified and answers do not match expected tactics')
      setVerifyErrorMessage(msg.slice(0, 200))
      setSubmitting(false)
      return
    }
    setVerifyErrorMessage(null)

    // Calculate score
    const blankStates: Record<
      string,
      { accepted: boolean | null; attempts: string[]; reasoning: string; hintLevel: number }
    > = {}
    for (const b of level.blanks) {
      const s = blanks[b.id]
      if (s) {
        blankStates[b.id] = {
          accepted: s.accepted,
          attempts: s.attempts,
          reasoning: s.reasoning,
          hintLevel: s.hintLevel,
        }
      }
    }

    const scoreResult = calculateW1Score(level, blankStates, verdict)
    setScore(scoreResult)
    setPhase('complete')
    setSubmitting(false)
    log({
      level_id: level.id,
      mode: 'build',
      step_id: 'submit',
      event: 'level_submitted',
      value: { mode: 'build', stars: scoreResult.stars, score: scoreResult.score },
      duration_ms: verifyResult.durationMs,
      confidence: null,
      annotation: verdictReasoning.trim() || null,
    })

    // Write to Supabase
    const verdictCorrect =
      level.type === 'A' ? verdict === 'works' : verdict === 'broken'
    const hintsUsed = Object.values(blanks).reduce((sum, b) => sum + b.hintLevel, 0)
    const hint3Used = Object.values(blanks).some(b => b.hintLevel >= 3)
    const leanErrors = Object.entries(blanks)
      .filter(([, b]) => b.leanError)
      .map(([id, b]) => ({ blank: id, error: b.leanError }))

    const tacticsChosen = level.blanks.map(b => ({
      blank_id: b.id,
      tactic: blanks[b.id]?.currentInput || 'sorry',
    }))

    upsertToSupabase({
      submitted_at: new Date().toISOString(),
      blanks: JSON.stringify(blanks),
      running_notes: runningNotes,
      verdict,
      verdict_reasoning: verdictReasoning,
      verdict_correct: verdictCorrect,
      final_lean_accepted: canProceed,
      lean_error_messages: leanErrors,
      hints_used: hintsUsed,
      hint3_used: hint3Used,
      hints_toggle_on: hintsToggleOn,
      score: scoreResult.score,
      stars: scoreResult.stars,
      axle_verified: axleVerifiedForDb,
      tactic_chosen: JSON.stringify(tacticsChosen),
      proof_state_before: theoremOnly,
      proof_state_after: fullLean,
    })
    flush(level.id).catch(() => {})
  }, [level, blanks, verdict, verdictReasoning, runningNotes, hintsToggleOn, upsertToSupabase])

  const toggleHintsOverlay = useCallback(() => {
    setHintsToggleOn(prev => !prev)
  }, [])

  const advanceFromReading = useCallback(() => {
    setPhase('filling')
  }, [])

  const savePartialExit = useCallback(async () => {
    if (!level) return
    const tacticsChosen = level.blanks.map(b => ({
      blank_id: b.id,
      tactic: blanks[b.id]?.currentInput || '',
    }))
    const hintsUsed = Object.values(blanks).reduce((sum, b) => sum + b.hintLevel, 0)
    await upsertToSupabase({
      blanks: JSON.stringify(blanks),
      running_notes: runningNotes,
      verdict,
      verdict_reasoning: verdictReasoning,
      hints_used: hintsUsed,
      hints_toggle_on: hintsToggleOn,
      is_partial: true,
      tactic_chosen: JSON.stringify(tacticsChosen),
    })
    await flush(level.id, { keepalive: true })
  }, [level, blanks, runningNotes, verdict, verdictReasoning, hintsToggleOn, upsertToSupabase])

  if (!level) return null

  return {
    level,
    phase,
    blanks,
    runningNotes,
    verdict,
    verdictReasoning,
    hintsToggleOn,
    score,
    sessionId: sessionIdRef.current,
    submitting,
    finalLeanAccepted,
    verifyErrorMessage,
    trapDisprove,
    repairHint,
    requestRepair,
    clearRepairHint,
    updateBlankInput,
    updateBlankReasoning,
    checkBlank,
    revealHint,
    updateRunningNotes,
    setVerdict,
    setVerdictReasoning,
    submitLevel,
    toggleHintsOverlay,
    advanceFromReading,
    savePartialExit,
    verifiedByLiveAxle,
  }
}
