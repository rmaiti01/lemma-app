'use client'

import Link from 'next/link'
import { BMUCO_LOG } from '@/lib/logger'

export default function Footer() {
  const handleExportData = () => {
    const blob = new Blob([JSON.stringify(BMUCO_LOG, null, 2)], {
      type: 'application/json',
    })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `lemma_game_log_${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(a.href)
  }

  return (
    <footer className="footer">
      <div className="footer-inner">
        <div className="footer-brand">
          <div className="footer-brand-name">Lemma</div>
          <p>
            Sharpen your proof review skills. Bridge the gap from the Natural Number Game to Mathlib.
          </p>
        </div>

        <div className="footer-columns">
          <div className="footer-column">
            <h4>Game</h4>
            <Link href="/studio/worlds">Play</Link>
            <Link href="/studio/leaderboard">Leaderboard</Link>
            <Link href="/studio/about">About</Link>
          </div>
          <div className="footer-column">
            <h4>Resources</h4>
            <a href="https://lean-lang.org" target="_blank" rel="noopener noreferrer">Lean 4</a>
            <a href="https://leanprover-community.github.io/mathlib4_docs/" target="_blank" rel="noopener noreferrer">Mathlib</a>
            <a href="https://adam.math.hhu.de/#/g/leanprover-community/nng4" target="_blank" rel="noopener noreferrer">Natural Number Game</a>
            <button type="button" className="footer-link-btn" onClick={handleExportData}>
              Export Data
            </button>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        &copy; {new Date().getFullYear()} Lemma. All rights reserved.
      </div>
    </footer>
  )
}
