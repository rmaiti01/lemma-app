'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Menu, X } from 'lucide-react'
import { useOnboarding } from '@/components/OnboardingProvider'
import { useProgress } from '@/components/ProgressProvider'
import { createClient } from '@/lib/supabase/client'

const navLinks = [
  { href: '/studio', label: 'Home' },
  { href: '/studio/worlds', label: 'Worlds' },
  { href: '/studio/leaderboard', label: 'Leaderboard' },
  { href: '/studio/about', label: 'About' },
]

export default function Navbar() {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)
  const { openHowToPlay } = useOnboarding()
  const [userName, setUserName] = useState<string | null>(null)
  const [authLoading, setAuthLoading] = useState(true)
  const { data: progressData, isLoading: progressLoading } = useProgress()

  const progressHud =
    progressData?.progress &&
    typeof progressData.progress.total_stars === 'number' &&
    typeof progressData.progress.total_points === 'number'
      ? { stars: progressData.progress.total_stars, xp: progressData.progress.total_points }
      : null

  useEffect(() => {
    const supabase = createClient()
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) {
        setUserName(
          data.user.user_metadata?.full_name ||
            data.user.user_metadata?.name ||
            data.user.email?.split('@')[0] ||
            'User'
        )
      } else {
        setUserName(null)
      }
      setAuthLoading(false)
    })

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setUserName(
          session.user.user_metadata?.full_name ||
            session.user.user_metadata?.name ||
            session.user.email?.split('@')[0] ||
            'User'
        )
      } else {
        setUserName(null)
      }
    })

    return () => subscription.unsubscribe()
  }, [])

  const handleSignOut = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    setUserName(null)
    window.location.href = '/studio'
  }

  const showHud = !progressLoading && progressHud != null

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <Link href="/studio" className="navbar-logo">
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none" aria-label="Lemma">
            <rect x="4" y="4" width="3" height="20" fill="var(--color-primary)" />
            <rect x="4" y="12" width="14" height="3" fill="var(--color-primary)" />
            <rect x="21" y="11" width="4" height="4" fill="var(--color-accent)" opacity="0.9" />
          </svg>
          <span className="navbar-logo-wordmark">LEMMA</span>
        </Link>

        <div className={`navbar-links ${mobileOpen ? 'open' : ''}`}>
          {navLinks.map(link => (
            <Link
              key={link.href}
              href={link.href}
              className={`navbar-link navbar-link--hud ${pathname === link.href ? 'active' : ''}`}
              onClick={() => setMobileOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <button
            type="button"
            className="navbar-link navbar-link--hud"
            onClick={() => {
              openHowToPlay()
              setMobileOpen(false)
            }}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: 0,
            }}
          >
            How to play
          </button>
        </div>

        <div className="navbar-actions">
          {authLoading ? null : (
            <>
              {showHud && (
                <span className="navbar-progress-hud" title="Total stars and XP">
                  <span aria-hidden>&#9733;</span> {progressHud.stars}
                  <span className="navbar-progress-sep">&middot;</span>
                  {progressHud.xp} XP
                </span>
              )}
              {userName ? (
                <>
                  <span className="navbar-user-name">{userName}</span>
                  <button type="button" className="btn btn-ghost btn-sm" onClick={handleSignOut}>
                    Sign Out
                  </button>
                </>
              ) : (
                <>
                  <Link href="/studio/auth/sign-in" className="btn btn-ghost btn-sm">
                    Sign In
                  </Link>
                  <Link href="/studio/worlds" className="btn btn-primary btn-sm">
                    Play Now
                  </Link>
                </>
              )}
            </>
          )}
        </div>

        <button
          type="button"
          className="navbar-toggle btn-icon btn-ghost"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      <style jsx>{`
        .navbar-logo {
          display: inline-flex;
          align-items: center;
          gap: 8px;
        }
        .navbar-logo-wordmark {
          font-family: var(--font-mono);
          font-size: 0.85rem;
          letter-spacing: 0.15em;
          color: var(--color-text);
        }
        .navbar-toggle {
          display: none;
        }
        .navbar-progress-hud {
          font-size: 11px;
          font-weight: 600;
          color: var(--color-text-secondary);
          letter-spacing: 0.02em;
          padding: 4px 10px;
          border-radius: 999px;
          border: 1px solid var(--color-border);
          background: var(--color-surface);
          white-space: nowrap;
        }
        .navbar-progress-sep {
          margin: 0 6px;
          opacity: 0.5;
        }
        .navbar-user-name {
          font-size: 12px;
          font-weight: 600;
          color: var(--color-primary);
          letter-spacing: 0.02em;
        }
        @media (max-width: 768px) {
          .navbar-links {
            display: none;
            position: absolute;
            top: 60px;
            left: 0;
            right: 0;
            background: var(--color-surface);
            border-bottom: 1px solid var(--color-border);
            flex-direction: column;
            padding: 16px;
            gap: 4px;
          }
          .navbar-links.open {
            display: flex;
          }
          .navbar-actions {
            display: none;
          }
          .navbar-toggle {
            display: flex;
          }
        }
      `}</style>
    </nav>
  )
}
