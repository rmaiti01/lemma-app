'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import {
  LayoutDashboard, BookOpen, Users, BarChart3, Download, Database,
  LogOut, UserCircle, Shield
} from 'lucide-react'
import { UserRole } from '@/lib/types'

interface DashboardSidebarProps {
  role: UserRole
  userName?: string
}

const navItems: Record<UserRole, { label: string; href: string; icon: React.ElementType; section?: string }[]> = {
  student: [
    { label: 'Play', href: '/studio/play', icon: LayoutDashboard },
    { label: 'Leaderboard', href: '/studio/leaderboard', icon: BarChart3 },
    { label: 'Profile', href: '/studio/settings', icon: UserCircle },
  ],
  mentor: [
    { label: 'Play', href: '/studio/play', icon: LayoutDashboard },
    { label: 'Leaderboard', href: '/studio/leaderboard', icon: BarChart3 },
    { label: 'Profile', href: '/studio/settings', icon: UserCircle },
  ],
  admin: [
    { label: 'Overview', href: '/studio/dashboard/admin', icon: LayoutDashboard },
    { label: 'Analytics', href: '/studio/dashboard/admin/analytics', icon: BarChart3, section: 'Data' },
    { label: 'Users', href: '/studio/dashboard/admin/users', icon: Users, section: 'Manage' },
    { label: 'Cohorts', href: '/studio/dashboard/admin/cohorts', icon: BookOpen },
    { label: 'Export', href: '/studio/dashboard/admin/export', icon: Download },
    { label: 'Session export', href: '/studio/dashboard/admin/export-packets', icon: Database },
  ],
}

export default function DashboardSidebar({ role, userName }: DashboardSidebarProps) {
  const pathname = usePathname()
  const router = useRouter()

  const handleSignOut = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/studio')
    router.refresh()
  }

  const items = navItems[role] || navItems.student

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <Link href="/studio" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none' }}>
          <span>Lemma</span>
        </Link>
      </div>

      <nav className="sidebar-nav">
        {items.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          return (
            <div key={item.href}>
              {item.section && (
                <div className="sidebar-section-label">{item.section}</div>
              )}
              <Link
                href={item.href}
                className={`sidebar-link ${isActive ? 'active' : ''}`}
              >
                <Icon size={18} />
                {item.label}
              </Link>
            </div>
          )
        })}
      </nav>

      <div style={{ borderTop: '1px solid var(--color-border)', paddingTop: '16px', marginTop: 'auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '8px 12px', marginBottom: '8px' }}>
          <UserCircle size={20} color="var(--color-text-muted)" />
          <div>
            <div style={{ fontSize: 'var(--text-sm)', fontWeight: 500 }}>{userName || 'User'}</div>
            <div style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <Shield size={10} />
              {role}
            </div>
          </div>
        </div>
        <button onClick={handleSignOut} className="sidebar-link" style={{ width: '100%', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left' }}>
          <LogOut size={18} />
          Sign Out
        </button>
      </div>
    </aside>
  )
}
