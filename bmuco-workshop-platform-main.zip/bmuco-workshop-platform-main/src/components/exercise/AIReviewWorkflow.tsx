'use client'

import { useState, useCallback, useRef, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Exercise, ExerciseTrace, AIReviewIssue } from '@/lib/exercise-types'
import { ChevronLeft, ChevronRight, Send, ExternalLink, Check, BookOpen, Search, Code2 } from 'lucide-react'

const DIMENSIONS = [
  { key: 'kernel_soundness', label: 'Kernel Soundness', description: 'Does the proof actually prove the correct theorem? Is the statement mathematically correct?' },
  { key: 'mathlib_coverage', label: 'Mathlib Coverage', description: 'Does it use existing Mathlib definitions/lemmas? Or does it re-invent things that already exist?' },
  { key: 'style_naming', label: 'Style & Naming', description: 'Does it follow Mathlib naming conventions? Uses dot notation? Correct casing?' },
  { key: 'proof_architecture', label: 'Proof Architecture', description: 'Is the proof well-structured? Uses appropriate tactics? Readable and maintainable?' },
  { key: 'abstraction_level', label: 'Abstraction Level', description: 'Is it at the right level of generality? Could it be more general? Is the type too specific?' },
]

const AI_REVIEW_STEPS = ['Read Goal', 'Read AI Code', 'Evaluate', 'Correct', 'Submit']

function useAIReviewAutoSave(trace: ExerciseTrace | null) {
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle')
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  const save = useCallback(async (data: Partial<ExerciseTrace>) => {
    if (!trace) return
    setSaveStatus('saving')
    const supabase = createClient()
    const { error } = await supabase
      .from('exercise_traces')
      .update(data)
      .eq('id', trace.id)
    setSaveStatus(error ? 'error' : 'saved')
    if (!error) setTimeout(() => setSaveStatus('idle'), 2000)
  }, [trace])

  const debouncedSave = useCallback((data: Partial<ExerciseTrace>) => {
    if (timerRef.current) clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => save(data), 800)
  }, [save])

  useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current) }, [])
  return { saveStatus, debouncedSave }
}

export default function AIReviewWorkflow({ exercise, initialTrace }: {
  exercise: Exercise
  initialTrace: ExerciseTrace
}) {
  const [trace, setTrace] = useState<ExerciseTrace>(initialTrace)
  const [step, setStep] = useState(0)
  const { saveStatus, debouncedSave } = useAIReviewAutoSave(trace)

  const issues: AIReviewIssue[] = trace.ai_review_identified_issues || DIMENSIONS.map(d => ({
    dimension: d.key,
    verdict: 'unsure' as const,
    explanation: '',
  }))

  const handleUpdate = (data: Partial<ExerciseTrace>) => {
    setTrace(prev => ({ ...prev, ...data }))
    debouncedSave(data)
  }

  const handleIssueUpdate = (dimensionKey: string, update: Partial<AIReviewIssue>) => {
    const newIssues = issues.map(issue =>
      issue.dimension === dimensionKey ? { ...issue, ...update } : issue
    )
    handleUpdate({ ai_review_identified_issues: newIssues })
  }

  const handleSubmit = async () => {
    const supabase = createClient()
    const { error } = await supabase
      .from('exercise_traces')
      .update({
        ...trace,
        status: 'submitted',
        submitted_at: new Date().toISOString(),
        ai_review_identified_issues: issues,
      })
      .eq('id', trace.id)

    if (error) {
      alert('Error submitting: ' + error.message)
    } else {
      setTrace(prev => ({ ...prev, status: 'submitted' }))
    }
  }

  const allDimensionsEvaluated = issues.every(i => i.verdict !== 'unsure')

  if (trace.status === 'submitted') {
    return (
      <div className="card" style={{ textAlign: 'center', padding: 'var(--space-12)' }}>
        <div style={{ fontSize: '48px', marginBottom: 'var(--space-4)' }}>✅</div>
        <h2>AI Review Submitted</h2>
        <p style={{ marginTop: 'var(--space-2)' }}>Your evaluation has been submitted for review.</p>
      </div>
    )
  }

  return (
    <div>
      {/* Step indicator */}
      <div className="step-indicator">
        {AI_REVIEW_STEPS.map((label, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center' }}>
            <div className={`step-item ${i === step ? 'active' : ''} ${i < step ? 'completed' : ''}`}
              onClick={() => setStep(i)}>
              <div className="step-node">
                <div className="step-number">{i < step ? <Check size={14} /> : i + 1}</div>
                <span className="step-label">{label}</span>
              </div>
            </div>
            {i < AI_REVIEW_STEPS.length - 1 && (
              <div className={`step-connector ${i < step ? 'completed' : ''}`} />
            )}
          </div>
        ))}
      </div>

      {/* Step 0: Read Goal */}
      {step === 0 && (
        <div className="layer-content">
          <div className="layer-header">
            <h2>Step 1 — Read the Goal</h2>
            <p>Understand what the theorem states and its informal proof before looking at the AI code.</p>
          </div>
          <div className="layer-section">
            <div className="layer-section-title">Theorem Statement</div>
            <div className="theorem-box">{exercise.nl_statement}</div>
          </div>
          <div className="layer-section">
            <div className="layer-section-title">Informal Proof</div>
            <div className="proof-box">{exercise.nl_proof}</div>
          </div>
          <div className="card" style={{ marginTop: 'var(--space-4)' }}>
            <div className="exercise-sidebar-section">
              <h4>Search Tools</h4>
              <div className="tool-links">
                <a href="https://www.moogle.ai" target="_blank" rel="noopener noreferrer" className="tool-link">
                  <Search size={14} /> Moogle <ExternalLink size={10} />
                </a>
                <a href="https://leansearch.net" target="_blank" rel="noopener noreferrer" className="tool-link">
                  <Search size={14} /> LeanSearch <ExternalLink size={10} />
                </a>
                <a href="https://loogle.lean-lang.org" target="_blank" rel="noopener noreferrer" className="tool-link">
                  <Code2 size={14} /> Loogle <ExternalLink size={10} />
                </a>
                <a href="https://leanprover-community.github.io/mathlib4_docs/" target="_blank" rel="noopener noreferrer" className="tool-link">
                  <BookOpen size={14} /> Mathlib Docs <ExternalLink size={10} />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step 1: Read AI Code */}
      {step === 1 && (
        <div className="layer-content">
          <div className="layer-header">
            <h2>Step 2 — Read the AI-Generated Code</h2>
            <p>Study the code below. What do you notice? Don&apos;t evaluate yet — just read carefully.</p>
          </div>
          <div className="code-display" style={{ fontSize: '14px', lineHeight: '1.7' }}>
            {exercise.ai_lean_code}
          </div>
          <div className="hint-panel" style={{ marginTop: 'var(--space-6)' }}>
            <div className="hint-panel-header">
              <span>💡 What to look for</span>
            </div>
            <div className="hint-panel-content">
              <ul style={{ paddingLeft: 'var(--space-4)' }}>
                <li>Does it use Mathlib definitions or re-invent its own?</li>
                <li>Is the type as general as it could be?</li>
                <li>Does the naming follow Mathlib conventions?</li>
                <li>Are the tactics appropriate and readable?</li>
                <li>Would a Mathlib reviewer accept this as-is?</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Step 2: Evaluate */}
      {step === 2 && (
        <div className="layer-content">
          <div className="layer-header">
            <h2>Step 3 — Evaluate Against 5 Dimensions</h2>
            <p>For each dimension, decide: Pass, Fail, or Unsure. Explain any failures.</p>
          </div>

          <div className="ai-review-layout">
            {/* Left: AI Code */}
            <div className="ai-review-panel">
              <div className="ai-review-panel-header ai">🤖 AI-Generated Code</div>
              <div className="code-display" style={{ position: 'sticky', top: 'var(--space-4)' }}>
                {exercise.ai_lean_code}
              </div>
            </div>

            {/* Right: Evaluation */}
            <div className="ai-review-panel">
              <div className="ai-review-panel-header student">📝 Your Evaluation</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                {DIMENSIONS.map((dim) => {
                  const issue = issues.find(i => i.dimension === dim.key)
                  return (
                    <div key={dim.key} className="dimension-eval">
                      <div className="dimension-title">{dim.label}</div>
                      <p style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', marginBottom: 'var(--space-3)' }}>
                        {dim.description}
                      </p>
                      <div className="dimension-radios">
                        {(['pass', 'fail', 'unsure'] as const).map(v => (
                          <label key={v} className="dimension-radio">
                            <input type="radio" name={dim.key} value={v}
                              checked={issue?.verdict === v}
                              onChange={() => handleIssueUpdate(dim.key, { verdict: v })} />
                            {v === 'pass' ? '✅ Pass' : v === 'fail' ? '❌ Fail' : '❓ Unsure'}
                          </label>
                        ))}
                      </div>
                      {issue?.verdict === 'fail' && (
                        <textarea className="form-textarea" rows={2}
                          placeholder="What's wrong and why does it matter?"
                          value={issue.explanation}
                          onChange={e => handleIssueUpdate(dim.key, { explanation: e.target.value })} />
                      )}
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step 3: Write Corrected Version */}
      {step === 3 && (
        <div className="layer-content">
          <div className="layer-header">
            <h2>Step 4 — Write the Corrected Version</h2>
            <p>Based on your evaluation, write the library-quality version.</p>
          </div>

          <div className="ai-review-layout">
            <div className="ai-review-panel">
              <div className="ai-review-panel-header ai">🤖 Original AI Code</div>
              <div className="code-display">{exercise.ai_lean_code}</div>
            </div>

            <div className="ai-review-panel">
              <div className="ai-review-panel-header student">✍️ Your Corrected Version</div>
              <div className="code-input-wrapper">
                <div className="code-input-header">
                  <span>Corrected Lean 4</span>
                  <span style={{ fontFamily: 'var(--font-mono)' }}>Lean 4</span>
                </div>
                <textarea
                  className="code-textarea large"
                  value={trace.ai_review_corrected_code || ''}
                  onChange={e => handleUpdate({ ai_review_corrected_code: e.target.value })}
                  placeholder="Write your corrected, library-quality version here..."
                  spellCheck={false}
                />
              </div>

              <div className="form-group" style={{ marginTop: 'var(--space-4)' }}>
                <label className="form-label">Overall Reasoning</label>
                <textarea className="form-textarea" rows={4}
                  placeholder="Summarize: what was wrong with the AI code and why your version is better."
                  value={trace.ai_review_reasoning || ''}
                  onChange={e => handleUpdate({ ai_review_reasoning: e.target.value })} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step 4: Submit */}
      {step === 4 && (
        <div className="layer-content">
          <div className="layer-header">
            <h2>Step 5 — Review & Submit</h2>
            <p>Review your evaluation and submit.</p>
          </div>

          <div className="submission-panel">
            <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, marginBottom: 'var(--space-4)' }}>
              Submission Checklist
            </h3>
            <div className="submission-gates">
              {[
                { label: 'All 5 dimensions evaluated', pass: allDimensionsEvaluated },
                { label: 'Corrected code written', pass: !!trace.ai_review_corrected_code?.trim() },
                { label: 'Overall reasoning provided', pass: !!trace.ai_review_reasoning?.trim() },
              ].map((gate, i) => (
                <div key={i} className="gate">
                  <div className={`gate-dot ${gate.pass ? 'green' : 'red'}`} />
                  <span className={`gate-label ${gate.pass ? 'passed' : ''}`}>{gate.label}</span>
                </div>
              ))}
            </div>

            <div style={{ marginBottom: 'var(--space-6)' }}>
              <h4 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 'var(--text-sm)', marginBottom: 'var(--space-3)' }}>
                Your Evaluation Summary
              </h4>
              <div className="grid grid-3" style={{ gap: 'var(--space-3)' }}>
                {DIMENSIONS.map(dim => {
                  const issue = issues.find(i => i.dimension === dim.key)
                  return (
                    <div key={dim.key} className="card" style={{ padding: 'var(--space-3)' }}>
                      <div style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', marginBottom: '4px' }}>
                        {dim.label}
                      </div>
                      <span className={`badge ${issue?.verdict === 'pass' ? 'badge-success' : issue?.verdict === 'fail' ? 'badge-error' : 'badge-warning'}`}>
                        {issue?.verdict || 'unsure'}
                      </span>
                    </div>
                  )
                })}
              </div>
            </div>

            <button className="btn btn-primary btn-lg" style={{ width: '100%' }}
              disabled={!allDimensionsEvaluated || !trace.ai_review_corrected_code?.trim()}
              onClick={handleSubmit}>
              <Send size={16} /> Submit AI Review
            </button>
          </div>
        </div>
      )}

      {/* Navigation */}
      <div className="layer-nav">
        <button className="btn btn-secondary" disabled={step === 0}
          onClick={() => setStep(Math.max(0, step - 1))}>
          <ChevronLeft size={14} /> Previous
        </button>
        <span style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)' }}>
          Step {step + 1} of {AI_REVIEW_STEPS.length}
        </span>
        {step < AI_REVIEW_STEPS.length - 1 ? (
          <button className="btn btn-primary" onClick={() => setStep(step + 1)}>
            Next <ChevronRight size={14} />
          </button>
        ) : <div />}
      </div>

      {/* Auto-save indicator */}
      {saveStatus !== 'idle' && (
        <div className={`autosave-indicator ${saveStatus}`}>
          <div className="autosave-dot" />
          {saveStatus === 'saving' && 'Saving...'}
          {saveStatus === 'saved' && 'Saved ✓'}
          {saveStatus === 'error' && 'Error saving'}
        </div>
      )}
    </div>
  )
}
