'use client'

import { useState } from 'react'
import { CheckCircle, XCircle, AlertTriangle, Loader2, Play } from 'lucide-react'

interface AxlePanelProps {
  code: string
  onResult?: (ok: boolean) => void
}

interface AxleMessage {
  severity: string
  message: string
  pos?: { line: number; column: number }
  endPos?: { line: number; column: number }
}

interface AxleResponse {
  okay: boolean
  content: string
  lean_messages: Record<string, AxleMessage[]>
  tool_messages: Record<string, AxleMessage[]>
  failed_declarations: string[]
  timings: { total_ms?: number; lean_ms?: number }
  error?: string
}

export default function AxlePanel({ code, onResult }: AxlePanelProps) {
  const [status, setStatus] = useState<'idle' | 'loading' | 'ok' | 'error'>('idle')
  const [result, setResult] = useState<AxleResponse | null>(null)
  const [errorMsg, setErrorMsg] = useState('')

  const handleCheck = async () => {
    if (!code.trim()) {
      setErrorMsg('No code to check')
      setStatus('error')
      return
    }

    setStatus('loading')
    setErrorMsg('')
    setResult(null)

    try {
      const res = await fetch('/api/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: code }),
      })

      const payload = await res.json()

      if (!res.ok || payload?.ok !== true) {
        setStatus('error')
        setErrorMsg(payload?.error || 'Check unavailable — try again')
        return
      }
      const data = payload.result || {}

      setResult(data)
      setStatus(data.okay ? 'ok' : 'error')
      onResult?.(data.okay)
    } catch {
      setStatus('error')
      setErrorMsg('Network error — could not reach AXLE')
    }
  }

  const allMessages = result
    ? Object.values(result.lean_messages).flat()
    : []
  const errors = allMessages.filter(m => m.severity === 'error')
  const warnings = allMessages.filter(m => m.severity === 'warning')

  return (
    <div className="axle-panel">
      <div className="axle-panel-header">
        <button
          onClick={handleCheck}
          disabled={status === 'loading'}
          className="btn btn-primary btn-sm"
          style={{ gap: '6px' }}
        >
          {status === 'loading' ? (
            <><Loader2 size={14} className="spin" /> Checking with AXLE...</>
          ) : (
            <><Play size={14} /> Check with AXLE</>
          )}
        </button>
        {result && (
          <span className="axle-timing">
            {result.timings?.total_ms ? `${(result.timings.total_ms / 1000).toFixed(1)}s` : ''}
          </span>
        )}
      </div>

      {status !== 'idle' && (
        <div className="axle-panel-result">
          {status === 'loading' && (
            <div className="axle-status loading">
              <Loader2 size={16} className="spin" />
              <span>Compiling with Lean 4 + Mathlib...</span>
            </div>
          )}

          {status === 'ok' && (
            <div className="axle-status ok">
              <CheckCircle size={16} />
              <span>Compiles successfully{warnings.length > 0 ? ` (${warnings.length} warning${warnings.length > 1 ? 's' : ''})` : ''}</span>
            </div>
          )}

          {status === 'error' && !result && (
            <div className="axle-status error">
              <XCircle size={16} />
              <span>{errorMsg || 'Check failed'}</span>
            </div>
          )}

          {status === 'error' && result && (
            <div className="axle-status error">
              <XCircle size={16} />
              <span>
                {result.failed_declarations?.length
                  ? `${result.failed_declarations.length} declaration${result.failed_declarations.length > 1 ? 's' : ''} failed`
                  : `${errors.length} error${errors.length > 1 ? 's' : ''}`}
              </span>
            </div>
          )}

          {/* Error messages */}
          {errors.length > 0 && (
            <div className="axle-messages">
              {errors.map((msg, i) => (
                <div key={i} className="axle-message axle-message-error">
                  {msg.pos && (
                    <span className="axle-message-pos">
                      Line {msg.pos.line}:{msg.pos.column}
                    </span>
                  )}
                  <pre className="axle-message-text">{msg.message}</pre>
                </div>
              ))}
            </div>
          )}

          {/* Warnings */}
          {warnings.length > 0 && (
            <div className="axle-messages">
              {warnings.map((msg, i) => (
                <div key={i} className="axle-message axle-message-warning">
                  <AlertTriangle size={12} />
                  <pre className="axle-message-text">{msg.message}</pre>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <style jsx>{`
        .axle-panel {
          border: 1px solid var(--color-border);
          border-radius: var(--radius-lg);
          overflow: hidden;
          margin-top: 12px;
        }
        .axle-panel-header {
          padding: 12px 16px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: var(--color-surface);
          border-bottom: 1px solid var(--color-border);
        }
        .axle-timing {
          font-size: var(--text-xs);
          color: var(--color-text-muted);
          font-family: var(--font-mono);
        }
        .axle-panel-result {
          padding: 12px 16px;
        }
        .axle-status {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: var(--text-sm);
          font-weight: 500;
          padding: 8px 12px;
          border-radius: var(--radius-md);
        }
        .axle-status.ok {
          color: var(--color-success);
          background: rgba(52, 211, 153, 0.08);
        }
        .axle-status.error {
          color: var(--color-error);
          background: rgba(239, 68, 68, 0.08);
        }
        .axle-status.loading {
          color: var(--color-text-muted);
          background: rgba(255,255,255,0.03);
        }
        .axle-messages {
          margin-top: 8px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .axle-message {
          font-size: var(--text-xs);
          padding: 8px 10px;
          border-radius: var(--radius-sm);
          display: flex;
          align-items: flex-start;
          gap: 8px;
        }
        .axle-message-error {
          background: rgba(239, 68, 68, 0.06);
          border: 1px solid rgba(239, 68, 68, 0.15);
        }
        .axle-message-warning {
          background: rgba(245, 158, 11, 0.06);
          border: 1px solid rgba(245, 158, 11, 0.15);
          color: var(--color-warning);
        }
        .axle-message-pos {
          font-family: var(--font-mono);
          color: var(--color-text-muted);
          white-space: nowrap;
          flex-shrink: 0;
        }
        .axle-message-text {
          margin: 0;
          font-family: var(--font-mono);
          white-space: pre-wrap;
          word-break: break-word;
          line-height: 1.5;
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        :global(.spin) {
          animation: spin 1s linear infinite;
        }
      `}</style>
    </div>
  )
}
