'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Exercise, ExerciseTrace, InventoryObject, InventoryProperty, SearchLogEntry, TacticChoice } from '@/lib/exercise-types'
import { Check, ChevronLeft, ChevronRight, ChevronDown, ChevronUp, Plus, Trash2, ExternalLink, Search, BookOpen, Code2, Shield, Clipboard, Send } from 'lucide-react'
import { validateName, NAMING_DICTIONARY, NAMING_RULES, NAMING_EXAMPLES } from '@/lib/naming-dictionary'
import { axleVerify } from '@/lib/axle-client'
import { log, flush } from '@/lib/logger'

// ─── Auto-save hook ───────────────────────────────────────
function useAutoSave(trace: ExerciseTrace | null) {
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle')
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const lastSavedRef = useRef<string>('')

  const save = useCallback(async (data: Partial<ExerciseTrace>) => {
    if (!trace) return
    const serialized = JSON.stringify(data)
    if (serialized === lastSavedRef.current) return

    setSaveStatus('saving')
    const supabase = createClient()
    const { error } = await supabase
      .from('exercise_traces')
      .update(data)
      .eq('id', trace.id)

    if (error) {
      setSaveStatus('error')
      console.error('Auto-save error:', error)
    } else {
      lastSavedRef.current = serialized
      setSaveStatus('saved')
      setTimeout(() => setSaveStatus('idle'), 2000)
    }
  }, [trace])

  const debouncedSave = useCallback((data: Partial<ExerciseTrace>) => {
    if (timerRef.current) clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => save(data), 800)
  }, [save])

  useEffect(() => {
    return () => { if (timerRef.current) clearTimeout(timerRef.current) }
  }, [])

  return { saveStatus, debouncedSave, save }
}

// ─── Step Indicator ───────────────────────────────────────
const LAYER_LABELS = ['Inventory', 'Type Skeleton', 'Statement', 'Proof', 'Culture Check']

function StepIndicator({ currentLayer, completedLayers, onLayerClick }: {
  currentLayer: number; completedLayers: boolean[]; onLayerClick: (l: number) => void
}) {
  return (
    <div className="step-indicator">
      {LAYER_LABELS.map((label, i) => (
        <div key={i} className="step-item" style={{ display: 'flex', alignItems: 'center' }}>
          <div
            className={`step-item ${i === currentLayer ? 'active' : ''} ${completedLayers[i] ? 'completed' : ''}`}
            onClick={() => onLayerClick(i)}
          >
            <div className="step-node">
              <div className="step-number">
                {completedLayers[i] ? <Check size={14} /> : i}
              </div>
              <span className="step-label">{label}</span>
            </div>
          </div>
          {i < LAYER_LABELS.length - 1 && (
            <div className={`step-connector ${completedLayers[i] ? 'completed' : ''}`} />
          )}
        </div>
      ))}
    </div>
  )
}

// ─── Code Input ───────────────────────────────────────────
function CodeInput({ value, onChange, placeholder, label, large }: {
  value: string; onChange: (v: string) => void; placeholder?: string; label?: string; large?: boolean
}) {
  return (
    <div className="code-input-wrapper">
      {label && (
        <div className="code-input-header">
          <span>{label}</span>
          <span style={{ fontFamily: 'var(--font-mono)' }}>Lean 4</span>
        </div>
      )}
      <textarea
        className={`code-textarea ${large ? 'large' : ''}`}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        spellCheck={false}
      />
    </div>
  )
}

// ─── Exercise Sidebar ─────────────────────────────────────
function ExerciseSidebar({ exercise }: { exercise: Exercise }) {
  return (
    <div className="exercise-sidebar">
      <div className="card">
        <div className="exercise-sidebar-section">
          <h4>Theorem</h4>
          <div className="theorem-box">{exercise.nl_statement}</div>
        </div>
      </div>
      <div className="card">
        <div className="exercise-sidebar-section">
          <h4>Informal Proof</h4>
          <div className="proof-box">{exercise.nl_proof}</div>
        </div>
      </div>
      <div className="card">
        <div className="exercise-sidebar-section">
          <h4>Search Tools</h4>
          <div className="tool-links">
            <a href="https://www.moogle.ai" target="_blank" rel="noopener noreferrer" className="tool-link">
              <Search size={14} /> Moogle <ExternalLink size={10} />
            </a>
            <a href="https://leansearch.net" target="_blank" rel="noopener noreferrer" className="tool-link">
              <Search size={14} /> LeanSearch <ExternalLink size={10} />
            </a>
            <a href="https://loogle.lean-lang.org" target="_blank" rel="noopener noreferrer" className="tool-link">
              <Code2 size={14} /> Loogle <ExternalLink size={10} />
            </a>
            <a href="https://leanprover-community.github.io/mathlib4_docs/" target="_blank" rel="noopener noreferrer" className="tool-link">
              <BookOpen size={14} /> Mathlib Docs <ExternalLink size={10} />
            </a>
          </div>
        </div>
      </div>
      {exercise.mathlib_search_hints && exercise.mathlib_search_hints.length > 0 && (
        <div className="card">
          <div className="exercise-sidebar-section">
            <h4>Search Hints</h4>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              {exercise.mathlib_search_hints.map((hint, i) => (
                <span key={i} className="badge badge-primary">{hint}</span>
              ))}
            </div>
          </div>
        </div>
      )}
      <a
        href="https://github.com/codespaces"
        target="_blank"
        rel="noopener noreferrer"
        className="btn btn-primary"
        style={{ width: '100%', marginTop: 'var(--space-2)' }}
      >
        Launch Codespace <ExternalLink size={14} />
      </a>
    </div>
  )
}

// ─── Layer 0: Inventory ───────────────────────────────────
function Layer0({ trace, onUpdate }: { trace: ExerciseTrace; onUpdate: (d: Partial<ExerciseTrace>) => void }) {
  const objects: InventoryObject[] = trace.layer0_objects || []
  const properties: InventoryProperty[] = trace.layer0_properties || []
  const searchLog: SearchLogEntry[] = trace.layer0_search_log || []

  return (
    <div className="layer-content">
      <div className="layer-header">
        <h2>Layer 0 — Inventory</h2>
        <p>Identify the mathematical objects, properties, hypotheses, and conclusion. Search Mathlib for existing definitions.</p>
      </div>

      <div className="layer-section">
        <div className="layer-section-title"><Shield size={14} /> Objects</div>
        <div className="dynamic-list">
          {objects.map((obj, i) => (
            <div key={i} className="dynamic-row">
              <input className="form-input" placeholder="Name (e.g. m)" value={obj.name}
                onChange={e => {
                  const newObjs = [...objects]; newObjs[i] = { ...obj, name: e.target.value }
                  onUpdate({ layer0_objects: newObjs })
                }} />
              <input className="form-input" placeholder="Type (e.g. ℕ)" value={obj.identified_type}
                onChange={e => {
                  const newObjs = [...objects]; newObjs[i] = { ...obj, identified_type: e.target.value }
                  onUpdate({ layer0_objects: newObjs })
                }} />
              <button className="dynamic-row-delete" onClick={() => {
                onUpdate({ layer0_objects: objects.filter((_, j) => j !== i) })
              }}><Trash2 size={14} /></button>
            </div>
          ))}
          <button className="add-row-btn" onClick={() => {
            onUpdate({ layer0_objects: [...objects, { name: '', identified_type: '' }] })
          }}><Plus size={14} /> Add object</button>
        </div>
      </div>

      <div className="layer-section">
        <div className="layer-section-title"><BookOpen size={14} /> Properties</div>
        <div className="dynamic-list">
          {properties.map((prop, i) => (
            <div key={i} className="dynamic-row">
              <input className="form-input" placeholder="Property (e.g. Even)" value={prop.property}
                onChange={e => {
                  const newProps = [...properties]; newProps[i] = { ...prop, property: e.target.value }
                  onUpdate({ layer0_properties: newProps })
                }} />
              <label className="toggle" style={{ flexShrink: 0 }}>
                <input type="checkbox" checked={prop.mathlib_exists}
                  onChange={e => {
                    const newProps = [...properties]; newProps[i] = { ...prop, mathlib_exists: e.target.checked }
                    onUpdate({ layer0_properties: newProps })
                  }} />
                <div className="toggle-track"><div className="toggle-thumb" /></div>
                <span style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)' }}>In Mathlib</span>
              </label>
              {prop.mathlib_exists && (
                <input className="form-input" placeholder="Mathlib name" value={prop.mathlib_name}
                  style={{ maxWidth: '160px' }}
                  onChange={e => {
                    const newProps = [...properties]; newProps[i] = { ...prop, mathlib_name: e.target.value }
                    onUpdate({ layer0_properties: newProps })
                  }} />
              )}
              <button className="dynamic-row-delete" onClick={() => {
                onUpdate({ layer0_properties: properties.filter((_, j) => j !== i) })
              }}><Trash2 size={14} /></button>
            </div>
          ))}
          <button className="add-row-btn" onClick={() => {
            onUpdate({ layer0_properties: [...properties, { property: '', mathlib_exists: false, mathlib_name: '' }] })
          }}><Plus size={14} /> Add property</button>
        </div>
      </div>

      <div className="layer-section">
        <div className="form-group">
          <label className="form-label">Hypotheses</label>
          <textarea className="form-textarea" placeholder="What do we assume? e.g. m and n are even integers"
            value={trace.layer0_hypotheses || ''} rows={3}
            onChange={e => onUpdate({ layer0_hypotheses: e.target.value })} />
        </div>
      </div>

      <div className="layer-section">
        <div className="form-group">
          <label className="form-label">Conclusion</label>
          <textarea className="form-textarea" placeholder="What do we claim? e.g. m + n is even"
            value={trace.layer0_conclusion || ''} rows={3}
            onChange={e => onUpdate({ layer0_conclusion: e.target.value })} />
        </div>
      </div>

      <div className="layer-section">
        <div className="layer-section-title"><Search size={14} /> Mathlib Search Log</div>
        <p style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', marginBottom: 'var(--space-3)' }}>
          Record what you searched for and whether you found it. This helps tutors see how you search Mathlib.
        </p>
        <div className="dynamic-list">
          {searchLog.map((entry, i) => (
            <div key={i} className="dynamic-row">
              <select className="form-select" style={{ maxWidth: '130px' }} value={entry.tool}
                onChange={e => {
                  const newLog = [...searchLog]; newLog[i] = { ...entry, tool: e.target.value }
                  onUpdate({ layer0_search_log: newLog })
                }}>
                <option value="">Tool...</option>
                <option value="Moogle">Moogle</option>
                <option value="LeanSearch">LeanSearch</option>
                <option value="Loogle">Loogle</option>
                <option value="Mathlib docs">Mathlib docs</option>
                <option value="exact?">exact?</option>
                <option value="apply?">apply?</option>
              </select>
              <input className="form-input" placeholder="Search query" value={entry.query}
                onChange={e => {
                  const newLog = [...searchLog]; newLog[i] = { ...entry, query: e.target.value }
                  onUpdate({ layer0_search_log: newLog })
                }} />
              <label className="toggle" style={{ flexShrink: 0 }}>
                <input type="checkbox" checked={entry.results_found}
                  onChange={e => {
                    const newLog = [...searchLog]; newLog[i] = { ...entry, results_found: e.target.checked }
                    onUpdate({ layer0_search_log: newLog })
                  }} />
                <div className="toggle-track"><div className="toggle-thumb" /></div>
                <span style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)' }}>Found</span>
              </label>
              <button className="dynamic-row-delete" onClick={() => {
                onUpdate({ layer0_search_log: searchLog.filter((_, j) => j !== i) })
              }}><Trash2 size={14} /></button>
            </div>
          ))}
          <button className="add-row-btn" onClick={() => {
            onUpdate({ layer0_search_log: [...searchLog, { tool: '', query: '', results_found: false }] })
          }}><Plus size={14} /> Add search entry</button>
        </div>
      </div>
    </div>
  )
}

// ─── Layer 1: Type Skeleton ───────────────────────────────
function Layer1({ trace, exercise, onUpdate }: { trace: ExerciseTrace; exercise: Exercise; onUpdate: (d: Partial<ExerciseTrace>) => void }) {
  const [showHint, setShowHint] = useState(false)

  return (
    <div className="layer-content">
      <div className="layer-header">
        <h2>Layer 1 — Type Skeleton</h2>
        <p>Choose the right level of generality and write just the type signature. No proof yet.</p>
      </div>

      <div className="layer-section">
        <div className="layer-section-title">Generality Level</div>
        <div className="generality-options">
          {[
            { value: 'specific', label: 'Specific', desc: 'e.g. ℕ, ℤ, ℝ' },
            { value: 'intermediate', label: 'Intermediate', desc: 'e.g. Int, CommRing' },
            { value: 'most_general', label: 'Most General', desc: 'e.g. AddMonoid, Monoid' },
          ].map(opt => (
            <div key={opt.value}
              className={`generality-option ${trace.layer1_type_choice === opt.value ? 'selected' : ''}`}
              onClick={() => onUpdate({ layer1_type_choice: opt.value })}>
              <div className="generality-option-label">{opt.label}</div>
              <div className="generality-option-desc">{opt.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="layer-section">
        <div className="form-group">
          <label className="form-label">Why this level of generality?</label>
          <textarea className="form-textarea" rows={3}
            placeholder="Explain your reasoning for choosing this type level..."
            value={trace.layer1_generality_reasoning || ''}
            onChange={e => onUpdate({ layer1_generality_reasoning: e.target.value })} />
        </div>
      </div>

      <div className="layer-section">
        <div className="form-group">
          <label className="form-label">Type Signature</label>
          <CodeInput
            value={trace.layer1_skeleton_code || ''}
            onChange={v => onUpdate({ layer1_skeleton_code: v })}
            placeholder="theorem Even.add {m n : ℤ} (hm : Even m) (hn : Even n) : Even (m + n)"
            label="Type signature only — no proof"
          />
        </div>
      </div>

      {exercise.generality_notes && (
        <div className="hint-panel">
          <div className="hint-panel-header" onClick={() => setShowHint(!showHint)}>
            <span>💡 Generality hint</span>
            {showHint ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </div>
          {showHint && (
            <div className="hint-panel-content">{exercise.generality_notes}</div>
          )}
        </div>
      )}
    </div>
  )
}

// ─── Layer 2: Statement ───────────────────────────────────
function Layer2({ trace, exercise, onUpdate }: { trace: ExerciseTrace; exercise: Exercise; onUpdate: (d: Partial<ExerciseTrace>) => void }) {
  const [showNamingRef, setShowNamingRef] = useState(false)
  const nameValidation = trace.layer2_proposed_name
    ? validateName(trace.layer2_proposed_name, exercise.nl_statement)
    : null

  return (
    <div className="layer-content">
      <div className="layer-header">
        <h2>Layer 2 — Statement</h2>
        <p>Write the complete theorem statement and choose a Mathlib-style name.</p>
      </div>

      <div className="layer-section">
        <div className="form-group">
          <label className="form-label">Full Theorem Statement</label>
          <CodeInput
            value={trace.layer2_full_statement || ''}
            onChange={v => onUpdate({ layer2_full_statement: v })}
            placeholder="theorem Even.add {m n : ℤ} (hm : Even m) (hn : Even n) : Even (m + n) := by"
            label="Complete statement (before := by)"
          />
        </div>
      </div>

      <div className="layer-section">
        <div className="form-group">
          <label className="form-label">Proposed Name</label>
          <input className="form-input form-code" placeholder="e.g. Even.add"
            value={trace.layer2_proposed_name || ''}
            onChange={e => onUpdate({ layer2_proposed_name: e.target.value })} />
          {nameValidation && (
            <div>
              <div className={`naming-indicator ${nameValidation.level}`}>
                {nameValidation.level === 'green' ? '✓' : nameValidation.level === 'yellow' ? '⚠' : '✗'}{' '}
                {nameValidation.message}
              </div>
              {nameValidation.suggestions.length > 0 && (
                <ul className="naming-suggestions">
                  {nameValidation.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="layer-section">
        <div className="form-group">
          <label className="form-label">Why this name?</label>
          <textarea className="form-textarea" rows={3}
            placeholder="Explain your naming choice..."
            value={trace.layer2_naming_reasoning || ''}
            onChange={e => onUpdate({ layer2_naming_reasoning: e.target.value })} />
        </div>
      </div>

      <div className="hint-panel">
        <div className="hint-panel-header" onClick={() => setShowNamingRef(!showNamingRef)}>
          <span>📖 Naming Convention Reference</span>
          {showNamingRef ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </div>
        {showNamingRef && (
          <div className="hint-panel-content">
            <div style={{ marginBottom: 'var(--space-4)' }}>
              <strong style={{ fontSize: 'var(--text-xs)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Rules</strong>
              <ul style={{ marginTop: 'var(--space-2)', paddingLeft: 'var(--space-4)' }}>
                {NAMING_RULES.map((rule, i) => <li key={i} style={{ marginBottom: '4px' }}>{rule}</li>)}
              </ul>
            </div>
            <div style={{ marginBottom: 'var(--space-4)' }}>
              <strong style={{ fontSize: 'var(--text-xs)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Examples</strong>
              <div className="naming-ref" style={{ marginTop: 'var(--space-2)' }}>
                {NAMING_EXAMPLES.map((ex, i) => (
                  <div key={i} className="naming-ref-item">
                    <span className="naming-ref-name">{ex.name}</span>
                    <span style={{ color: 'var(--color-text-muted)', fontSize: 'var(--text-xs)' }}>{ex.description}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <strong style={{ fontSize: 'var(--text-xs)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Dictionary</strong>
              <div className="naming-ref" style={{ marginTop: 'var(--space-2)' }}>
                {Object.entries(NAMING_DICTIONARY).slice(0, 30).map(([sym, name], i) => (
                  <div key={i} className="naming-ref-item">
                    <span className="naming-ref-symbol">{sym}</span>
                    <span className="naming-ref-name">{name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Layer 3: Proof ───────────────────────────────────────
function Layer3({ trace, onUpdate }: { trace: ExerciseTrace; onUpdate: (d: Partial<ExerciseTrace>) => void }) {
  const tactics: TacticChoice[] = trace.layer3_tactic_choices || []
  const [showPasteModal, setShowPasteModal] = useState(false)
  const [pasteCode, setPasteCode] = useState('')

  const handlePaste = () => {
    const code = pasteCode.trim()
    const byIdx = code.indexOf(':= by')
    if (byIdx >= 0) {
      onUpdate({
        layer2_full_statement: code.slice(0, byIdx).trim(),
        layer3_proof_code: code.slice(byIdx + 5).trim(),
        layer3_full_lean_code: code,
      })
    } else {
      onUpdate({ layer3_full_lean_code: code, layer3_proof_code: code })
    }
    setShowPasteModal(false)
    setPasteCode('')
  }

  return (
    <div className="layer-content">
      <div className="layer-header">
        <h2>Layer 3 — Proof</h2>
        <p>Write the proof, document your tactic choices, and verify it compiles.</p>
      </div>

      <div style={{ display: 'flex', gap: 'var(--space-3)', marginBottom: 'var(--space-6)' }}>
        <button className="btn btn-secondary" onClick={() => setShowPasteModal(true)}>
          <Clipboard size={14} /> Paste from Codespace
        </button>
        <a href="https://github.com/codespaces" target="_blank" rel="noopener noreferrer" className="btn btn-ghost">
          <ExternalLink size={14} /> Open Codespace
        </a>
      </div>

      <div className="layer-section">
        <div className="form-group">
          <label className="form-label">Proof Code</label>
          <CodeInput
            value={trace.layer3_proof_code || ''}
            onChange={v => onUpdate({ layer3_proof_code: v })}
            placeholder={"  obtain ⟨a, ha⟩ := hm\n  obtain ⟨b, hb⟩ := hn\n  exact ⟨a + b, by rw [ha, hb]; ring⟩"}
            label="Proof body (after := by)"
            large
          />
        </div>
      </div>

      <div className="layer-section">
        <div className="layer-section-title">Tactic Choices</div>
        <p style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', marginBottom: 'var(--space-3)' }}>
          For each key tactic, explain why you used it.
        </p>
        <div className="dynamic-list">
          {tactics.map((t, i) => (
            <div key={i} className="dynamic-row">
              <input className="form-input form-code" placeholder="Tactic (e.g. obtain)" value={t.tactic}
                style={{ maxWidth: '150px' }}
                onChange={e => {
                  const newT = [...tactics]; newT[i] = { ...t, tactic: e.target.value }
                  onUpdate({ layer3_tactic_choices: newT })
                }} />
              <input className="form-input" placeholder="Why? (e.g. unpack Even definition)" value={t.why}
                onChange={e => {
                  const newT = [...tactics]; newT[i] = { ...t, why: e.target.value }
                  onUpdate({ layer3_tactic_choices: newT })
                }} />
              <button className="dynamic-row-delete" onClick={() => {
                onUpdate({ layer3_tactic_choices: tactics.filter((_, j) => j !== i) })
              }}><Trash2 size={14} /></button>
            </div>
          ))}
          <button className="add-row-btn" onClick={() => {
            onUpdate({ layer3_tactic_choices: [...tactics, { tactic: '', why: '' }] })
          }}><Plus size={14} /> Add tactic</button>
        </div>
      </div>

      <div className="layer-section">
        <div className="form-group">
          <label className="form-label">Witness Reasoning</label>
          <textarea className="form-textarea" rows={3}
            placeholder="If your proof requires a witness, explain: what is it and why does it work?"
            value={trace.layer3_witness_reasoning || ''}
            onChange={e => onUpdate({ layer3_witness_reasoning: e.target.value })} />
        </div>
      </div>

      <div className="layer-section">
        <label className="form-checkbox-group" style={{ cursor: 'pointer' }}>
          <input type="checkbox" className="form-checkbox"
            checked={trace.layer3_compiles || false}
            onChange={e => onUpdate({ layer3_compiles: e.target.checked })} />
          <span className="form-label">I have compiled this in Codespaces and it works</span>
        </label>
      </div>

      <div className="layer-section">
        <div className="form-group">
          <label className="form-label">Full Lean Code (preview)</label>
          <div className="code-display">
            {trace.layer2_full_statement || '-- theorem statement goes here'}{'\n'}
            {':= by\n'}
            {trace.layer3_proof_code || '  sorry'}
          </div>
        </div>
      </div>

      {/* Paste Modal */}
      {showPasteModal && (
        <div className="modal-overlay" onClick={() => setShowPasteModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '640px' }}>
            <div className="modal-header">
              <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}>Paste from Codespace</h3>
              <button className="btn btn-ghost" onClick={() => setShowPasteModal(false)}>✕</button>
            </div>
            <p style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)', marginBottom: 'var(--space-4)' }}>
              Paste your complete Lean code. The tool will auto-split at <code>:= by</code> to fill statement and proof.
            </p>
            <CodeInput value={pasteCode} onChange={setPasteCode}
              placeholder="Paste your complete theorem + proof here..." large />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--space-3)', marginTop: 'var(--space-4)' }}>
              <button className="btn btn-secondary" onClick={() => setShowPasteModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handlePaste}>Import Code</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Layer 4: Culture Check ───────────────────────────────
function Layer4({ trace, onUpdate }: { trace: ExerciseTrace; onUpdate: (d: Partial<ExerciseTrace>) => void }) {
  return (
    <div className="layer-content">
      <div className="layer-header">
        <h2>Layer 4 — Culture Check</h2>
        <p>Check your work against Mathlib standards. Would this pass review?</p>
      </div>

      <div className="checklist">
        <div className={`checklist-item ${trace.layer4_exists_in_mathlib !== null ? 'checked' : ''}`}>
          <input type="checkbox" className="form-checkbox"
            checked={trace.checklist_searched_mathlib}
            onChange={e => onUpdate({ checklist_searched_mathlib: e.target.checked })} />
          <div className="checklist-item-content">
            <div className="checklist-item-label">I searched Mathlib for this theorem</div>
            <div className="checklist-item-input">
              <label className="toggle" style={{ marginBottom: 'var(--space-2)' }}>
                <input type="checkbox" checked={trace.layer4_exists_in_mathlib || false}
                  onChange={e => onUpdate({ layer4_exists_in_mathlib: e.target.checked })} />
                <div className="toggle-track"><div className="toggle-thumb" /></div>
                <span style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)' }}>Exists in Mathlib</span>
              </label>
              {trace.layer4_exists_in_mathlib && (
                <input className="form-input" placeholder="Mathlib name (e.g. Even.add)"
                  style={{ maxWidth: '300px', marginTop: 'var(--space-2)' }}
                  value={trace.layer4_mathlib_name || ''}
                  onChange={e => onUpdate({ layer4_mathlib_name: e.target.value })} />
              )}
            </div>
          </div>
        </div>

        <div className={`checklist-item ${trace.layer4_generality_check ? 'checked' : ''}`}>
          <input type="checkbox" className="form-checkbox" checked={!!trace.layer4_generality_check}
            onChange={() => {}} />
          <div className="checklist-item-content">
            <div className="checklist-item-label">Generality comparison</div>
            <div className="checklist-item-input">
              <textarea className="form-textarea" rows={2}
                placeholder="Is our version as general as Mathlib's? What could be more general?"
                value={trace.layer4_generality_check || ''}
                onChange={e => onUpdate({ layer4_generality_check: e.target.value })} />
            </div>
          </div>
        </div>

        <div className={`checklist-item ${trace.checklist_name_checked ? 'checked' : ''}`}>
          <input type="checkbox" className="form-checkbox"
            checked={trace.checklist_name_checked}
            onChange={e => onUpdate({ checklist_name_checked: e.target.checked })} />
          <div className="checklist-item-content">
            <div className="checklist-item-label">I checked my name against conventions</div>
          </div>
        </div>

        <div className="checklist-item">
          <input type="checkbox" className="form-checkbox" checked={false} onChange={() => {}} />
          <div className="checklist-item-content">
            <div className="checklist-item-label">Style / linter issues</div>
            <div className="checklist-item-input">
              <textarea className="form-textarea" rows={2}
                placeholder="Any style violations or linter warnings? (Check manually for pilot)"
                value={trace.layer4_style_violations ? JSON.stringify(trace.layer4_style_violations) : ''}
                onChange={e => {
                  try {
                    onUpdate({ layer4_style_violations: e.target.value ? [{ issue: e.target.value, severity: 'info' }] : null })
                  } catch {
                    // ok
                  }
                }} />
            </div>
          </div>
        </div>

        <div className={`checklist-item ${trace.layer4_api_completeness ? 'checked' : ''}`}>
          <input type="checkbox" className="form-checkbox" checked={!!trace.layer4_api_completeness}
            onChange={() => {}} />
          <div className="checklist-item-content">
            <div className="checklist-item-label">API completeness — related theorems</div>
            <div className="checklist-item-input">
              <textarea className="form-textarea" rows={2}
                placeholder="Should we also prove related theorems? e.g. Even.mul_left, Even.add_right?"
                value={trace.layer4_api_completeness || ''}
                onChange={e => onUpdate({ layer4_api_completeness: e.target.value })} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Main Exercise Workflow ───────────────────────────────
export default function ExerciseWorkflow({ exercise, initialTrace }: {
  exercise: Exercise
  initialTrace: ExerciseTrace
}) {
  const [trace, setTrace] = useState<ExerciseTrace>(initialTrace)
  const [currentLayer, setCurrentLayer] = useState(0)
  const [traceWarning, setTraceWarning] = useState<string | null>(null)
  const { saveStatus, debouncedSave } = useAutoSave(trace)

  // Layer completion status
  const completedLayers = [
    !!(trace.layer0_objects?.length && trace.layer0_hypotheses && trace.layer0_conclusion),
    !!(trace.layer1_type_choice && trace.layer1_skeleton_code),
    !!(trace.layer2_full_statement && trace.layer2_proposed_name),
    !!(trace.layer3_proof_code && trace.layer3_compiles),
    !!(trace.checklist_searched_mathlib && trace.checklist_name_checked),
  ]

  const handleUpdate = (data: Partial<ExerciseTrace>) => {
    setTrace(prev => ({ ...prev, ...data }))
    debouncedSave(data)
  }

  const handleSubmit = async () => {
    const supabase = createClient()
    const fullCode = `${trace.layer2_full_statement || ''}\n:= by\n${trace.layer3_proof_code || ''}`

    const { error } = await supabase
      .from('exercise_traces')
      .update({
        ...trace,
        status: 'submitted',
        submitted_at: new Date().toISOString(),
        layer3_full_lean_code: fullCode,
        checklist_all_layers_complete: completedLayers.every(Boolean),
        checklist_reasoning_filled: !!(
          trace.layer1_generality_reasoning &&
          trace.layer2_naming_reasoning &&
          trace.layer3_witness_reasoning
        ),
      })
      .eq('id', trace.id)

    if (error) {
      alert('Error submitting: ' + error.message)
    } else {
      setTrace(prev => ({ ...prev, status: 'submitted' }))
      flush(exercise.id).catch(() => {})
    }
  }

  const verifyCurrentTraceStep = useCallback(async () => {
    const stepId = `layer-${currentLayer}`
    const statement = trace.layer2_full_statement?.trim() || ''
    const proof = trace.layer3_proof_code?.trim() || ''

    if (currentLayer < 3 || !statement || !proof) {
      log({
        level_id: exercise.id,
        mode: 'trace',
        step_id: stepId,
        event: 'trace_step_completed',
        value: { okay: true },
        duration_ms: 0,
        confidence: null,
        annotation: null,
      })
      setTraceWarning(null)
      return
    }

    const leanContent = [statement, proof].filter(Boolean).join('\n\n')
    const verifyResult = await axleVerify(leanContent, {
      levelId: exercise.id,
      mode: 'trace',
      stepId,
      annotation: null,
      confidence: null,
      formalStatement: statement,
    })
    log({
      level_id: exercise.id,
      mode: 'trace',
      step_id: stepId,
      event: 'trace_step_completed',
      value: { okay: verifyResult.verified },
      duration_ms: verifyResult.durationMs,
      confidence: null,
      annotation: null,
    })

    if (!verifyResult.verified) {
      setTraceWarning('⚠ This step may not be valid — check your annotation')
      flush(exercise.id).catch(() => {})
      return
    }

    setTraceWarning(null)
    flush(exercise.id).catch(() => {})
  }, [currentLayer, exercise.id, trace.layer2_full_statement, trace.layer3_proof_code])

  const handleNextLayer = useCallback(async () => {
    await verifyCurrentTraceStep()
    setCurrentLayer(prev => Math.min(4, prev + 1))
  }, [verifyCurrentTraceStep])

  const handleLayerClick = useCallback(async (targetLayer: number) => {
    if (targetLayer > currentLayer) {
      await verifyCurrentTraceStep()
    }
    setCurrentLayer(targetLayer)
  }, [currentLayer, verifyCurrentTraceStep])

  const allGatesPass =
    completedLayers.every(Boolean) &&
    trace.checklist_code_compiles &&
    trace.checklist_name_checked &&
    trace.checklist_searched_mathlib

  const renderLayer = () => {
    switch (currentLayer) {
      case 0: return <Layer0 trace={trace} onUpdate={handleUpdate} />
      case 1: return <Layer1 trace={trace} exercise={exercise} onUpdate={handleUpdate} />
      case 2: return <Layer2 trace={trace} exercise={exercise} onUpdate={handleUpdate} />
      case 3: return <Layer3 trace={trace} onUpdate={handleUpdate} />
      case 4: return <Layer4 trace={trace} onUpdate={handleUpdate} />
      default: return null
    }
  }

  return (
    <div>
      <StepIndicator
        currentLayer={currentLayer}
        completedLayers={completedLayers}
        onLayerClick={layer => {
          void handleLayerClick(layer)
        }}
      />

      <div className="exercise-layout">
        <ExerciseSidebar exercise={exercise} />
        <div className="exercise-main">
          {trace.status === 'submitted' ? (
            <div className="card" style={{ textAlign: 'center', padding: 'var(--space-12)' }}>
              <div style={{ fontSize: '48px', marginBottom: 'var(--space-4)' }}>✅</div>
              <h2>Trace Submitted</h2>
              <p style={{ marginTop: 'var(--space-2)' }}>Your process trace has been submitted for review.</p>
            </div>
          ) : (
            <>
              {renderLayer()}

              {/* Layer navigation */}
              <div className="layer-nav">
                <button className="btn btn-secondary" disabled={currentLayer === 0}
                  onClick={() => setCurrentLayer(Math.max(0, currentLayer - 1))}>
                  <ChevronLeft size={14} /> Previous Layer
                </button>
                <span style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)' }}>
                  Layer {currentLayer} of 4
                </span>
                {currentLayer < 4 ? (
                  <button className="btn btn-primary"
                    onClick={() => {
                      void handleNextLayer()
                    }}>
                    Next Layer <ChevronRight size={14} />
                  </button>
                ) : (
                  <div />
                )}
              </div>
              {traceWarning && (
                <p style={{ color: '#b45309', fontSize: 'var(--text-xs)', marginTop: 'var(--space-2)' }}>
                  {traceWarning}
                </p>
              )}

              {/* Submission Panel (show on last layer) */}
              {currentLayer === 4 && (
                <div className="submission-panel">
                  <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, marginBottom: 'var(--space-4)' }}>
                    Submission Checklist
                  </h3>
                  <div className="submission-gates">
                    {[
                      { label: 'All layers complete', pass: completedLayers.every(Boolean) },
                      { label: 'Code compiles', pass: trace.layer3_compiles || false },
                      { label: 'Name checked', pass: trace.checklist_name_checked },
                      { label: 'Searched Mathlib', pass: trace.checklist_searched_mathlib },
                      { label: 'Reasoning filled', pass: !!(trace.layer1_generality_reasoning && trace.layer2_naming_reasoning) },
                    ].map((gate, i) => (
                      <div key={i} className="gate">
                        <div className={`gate-dot ${gate.pass ? 'green' : 'red'}`} />
                        <span className={`gate-label ${gate.pass ? 'passed' : ''}`}>{gate.label}</span>
                      </div>
                    ))}
                  </div>
                  <button className="btn btn-primary btn-lg" style={{ width: '100%' }}
                    disabled={!allGatesPass} onClick={handleSubmit}>
                    <Send size={16} /> Submit Process Trace
                  </button>
                  {!allGatesPass && (
                    <p style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', textAlign: 'center', marginTop: 'var(--space-3)' }}>
                      Complete all checklist items to submit
                    </p>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Auto-save indicator */}
      {saveStatus !== 'idle' && (
        <div className={`autosave-indicator ${saveStatus}`}>
          <div className="autosave-dot" />
          {saveStatus === 'saving' && 'Saving...'}
          {saveStatus === 'saved' && 'Saved ✓'}
          {saveStatus === 'error' && 'Error saving'}
        </div>
      )}
    </div>
  )
}
