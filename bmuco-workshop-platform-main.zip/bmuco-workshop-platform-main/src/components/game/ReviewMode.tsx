'use client'

import { useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { flush, log } from '@/lib/logger'
import type { W1Level } from '@/lib/world1-data'

interface ReviewModeProps {
  level: W1Level
  worldId: string
  onComplete?: () => void
  bindExitSave?: (fn: (() => Promise<void>) | null) => void
}

const MAX_PLAYABLE_LEVEL = 2

export default function ReviewMode({ level, worldId, onComplete, bindExitSave }: ReviewModeProps) {
  const router = useRouter()
  const issues = useMemo(() => level.reviewIssues || [], [level.reviewIssues])
  const [selected, setSelected] = useState<Record<string, boolean>>({})
  const [submitted, setSubmitted] = useState(false)

  useEffect(() => {
    if (!bindExitSave) return
    bindExitSave(async () => {
      log({
        level_id: level.id,
        mode: 'review',
        step_id: 'partial-exit',
        event: 'review_partial_exit',
        value: { is_partial: true, selected },
        duration_ms: 0,
        confidence: null,
        annotation: null,
      })
      await flush(level.id)
    })
    return () => bindExitSave(null)
  }, [bindExitSave, level.id, selected])

  const score = useMemo(() => {
    if (!submitted) return null
    const realIssues = issues.filter(i => i.correct)
    const truePositives = realIssues.filter(i => !!selected[i.id])
    const falsePositives = issues.filter(i => !i.correct && !!selected[i.id])
    const totalReal = realIssues.length
    const finalScore = Math.max(0, truePositives.length - falsePositives.length)
    const passed = finalScore >= Math.max(1, Math.floor(totalReal * 0.6))
    return { finalScore, totalReal, falsePositives: falsePositives.length, passed }
  }, [submitted, issues, selected])

  const handleSubmit = () => {
    const realIssues = issues.filter(i => i.correct)
    const truePositives = realIssues.filter(i => !!selected[i.id])
    const falsePositives = issues.filter(i => !i.correct && !!selected[i.id])
    const totalReal = realIssues.length
    const finalScore = Math.max(0, truePositives.length - falsePositives.length)
    const passed = finalScore >= Math.max(1, Math.floor(totalReal * 0.6))
    setSubmitted(true)
    log({
      level_id: level.id,
      mode: 'review',
      step_id: 'review-submit',
      event: 'level_submitted',
      value: { mode: 'review', stars: passed ? 1 : 0, score: finalScore, totalReal, selected },
      duration_ms: 0,
      confidence: null,
      annotation: null,
    })
    if (passed && onComplete) onComplete()
  }

  const isLastPlayable = level.number >= MAX_PLAYABLE_LEVEL

  return (
    <div className="review-mode-root" style={{ maxWidth: 900, margin: '0 auto', padding: '24px' }}>
      <div className="review-mode-panels">
        <div className="card" style={{ maxWidth: '100%', boxSizing: 'border-box' }}>
          <h3 style={{ marginBottom: 10 }}>Bloated Proof</h3>
          <pre
            className="review-proof-pre"
            style={{
              margin: 0,
              background: '#1a1a1a',
              color: '#e8e8e8',
              padding: 12,
              borderRadius: 6,
            }}
          >
            {level.reviewProofDisplay ?? level.leanFullProof ?? level.leanSkeleton}
          </pre>
        </div>
        <div className="card" style={{ maxWidth: '100%', boxSizing: 'border-box' }}>
          <h3 style={{ marginBottom: 10 }}>Spot the Issues</h3>
          <div style={{ display: 'grid', gap: 8 }}>
            {issues.map(issue => (
              <label
                key={issue.id}
                className="review-checklist-label"
                style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}
              >
                <input
                  type="checkbox"
                  checked={!!selected[issue.id]}
                  onChange={e => setSelected(prev => ({ ...prev, [issue.id]: e.target.checked }))}
                  disabled={submitted}
                />
                <span>{issue.text}</span>
              </label>
            ))}
          </div>
          {!submitted && (
            <button type="button" className="btn btn-primary" style={{ marginTop: 14 }} onClick={handleSubmit}>
              Submit Review
            </button>
          )}
          {submitted && score && (
            <div style={{ marginTop: 14 }}>
              <p style={{ color: score.passed ? '#10b981' : '#b91c1c', fontWeight: 600 }}>
                {score.finalScore}/{score.totalReal} issues found correctly
                {score.falsePositives > 0 && (
                  <span style={{ fontWeight: 400, fontSize: 13 }}>
                    {' '}({score.falsePositives} false {score.falsePositives === 1 ? 'positive' : 'positives'} deducted)
                  </span>
                )}
              </p>
              {score.passed ? (
                isLastPlayable ? (
                  <div style={{ marginTop: 16, textAlign: 'center' }}>
                    <p style={{ fontSize: 22, fontWeight: 700, color: 'var(--color-warning)', marginBottom: 12 }}>
                      World 1 Complete!
                    </p>
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={() => router.push('/studio/worlds/1', { scroll: false })}
                    >
                      Back to World Map
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    className="btn btn-primary"
                    style={{ marginTop: 10 }}
                    onClick={() => router.push(`/studio/worlds/${worldId}/levels/${level.number + 1}?mode=mcq`, { scroll: false })}
                  >
                    Next Level →
                  </button>
                )
              ) : (
                <button
                  type="button"
                  className="btn btn-secondary"
                  style={{ marginTop: 10 }}
                  onClick={() => {
                    setSelected({})
                    setSubmitted(false)
                  }}
                >
                  Try Again
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
