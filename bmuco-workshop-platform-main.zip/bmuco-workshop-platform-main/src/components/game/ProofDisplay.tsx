'use client'

import { useState, type ReactNode } from 'react'
import { Copy, Check, Shield } from 'lucide-react'

interface ProofDisplayProps {
  code: string
  title?: string
  informalStatement?: string
  isBoss?: boolean
}

export default function ProofDisplay({
  code,
  title,
  informalStatement,
  isBoss,
}: ProofDisplayProps) {
  const [copied, setCopied] = useState(false)
  const lines = code.split('\n')
  const tokenRegex = /\u22a2|\b(rw|simp|induction)\b/g

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const renderLeanLine = (line: string) => {
    const commentStart = line.indexOf('--')
    const codePart = commentStart >= 0 ? line.slice(0, commentStart) : line
    const commentPart = commentStart >= 0 ? line.slice(commentStart) : ''
    const nodes: ReactNode[] = []
    let cursor = 0

    for (const match of Array.from(codePart.matchAll(tokenRegex))) {
      const start = match.index ?? 0
      if (start > cursor) {
        nodes.push(
          <span key={`txt-${cursor}`}>{codePart.slice(cursor, start)}</span>
        )
      }
      const token = match[0]
      if (token === '⊢') {
        nodes.push(
          <span key={`goal-${start}`} className="proof-token-goal">
            {token}
          </span>
        )
      } else {
        nodes.push(
          <span key={`kw-${start}`} className="proof-token-keyword">
            {token}
          </span>
        )
      }
      cursor = start + token.length
    }

    if (cursor < codePart.length) {
      nodes.push(<span key={`tail-${cursor}`}>{codePart.slice(cursor)}</span>)
    }

    return (
      <>
        {nodes}
        {commentPart && <span className="proof-token-comment">{commentPart}</span>}
      </>
    )
  }

  return (
    <div className="proof-display">
      {informalStatement && (
        <div className="proof-display-statement">
          <div className="theorem-frame bmuco-arcade-theorem">
            <div className="theorem-label bmuco-arcade-theorem-label">The Theorem</div>
            <div className="theorem-body">
              <p>{informalStatement}</p>
            </div>
          </div>
        </div>
      )}

      <div className="proof-display-code-section">
        <div className="proof-display-header">
          <h3 className="proof-display-label bmuco-arcade-code-title">
            {isBoss && <Shield size={14} className="proof-display-boss-icon" style={{ marginRight: 6 }} />}
            {title || 'Lean 4 Code'}
          </h3>
          <button type="button" className="proof-copy-btn bmuco-arcade-copy-btn" onClick={handleCopy} title="Copy code">
            {copied ? <Check size={14} /> : <Copy size={14} />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
        <div className="proof-display-code bmuco-arcade-code-shell">
          <pre>
            <code>
              {lines.map((line, i) => (
                <span key={i} className="proof-line">
                  <span className="proof-line-num">{i + 1}</span>
                  <span className="proof-line-text">{renderLeanLine(line)}</span>
                  {'\n'}
                </span>
              ))}
            </code>
          </pre>
        </div>
      </div>

      <style jsx>{`
        .proof-display {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .proof-display-boss-icon {
          color: var(--color-primary);
        }
        .proof-display-label {
          font-family: var(--font-body);
          font-weight: 600;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--color-text-muted);
          margin-bottom: 8px;
          display: flex;
          align-items: center;
        }
        .theorem-body {
          background: var(--color-surface);
          padding: 24px;
        }
        .theorem-body p {
          font-size: 17px;
          font-weight: 500;
          color: var(--color-text);
          margin: 0;
          line-height: 1.6;
        }
        .proof-display-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 8px;
        }
        .proof-copy-btn {
          display: flex;
          align-items: center;
          gap: 4px;
          background: none;
          border: 1px solid var(--color-border);
          border-radius: var(--radius-sm);
          padding: 4px 10px;
          color: var(--color-text-muted);
          font-size: 12px;
          cursor: pointer;
          transition: all 150ms;
        }
        .proof-copy-btn:hover {
          border-color: var(--color-border-light);
          color: var(--color-text-secondary);
        }
        .proof-display-code {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-lg);
          overflow-x: auto;
        }
        .proof-display-code pre {
          margin: 0;
          padding: 16px 0;
          font-family: var(--font-mono);
          font-size: 13px;
          line-height: 1.7;
        }
        .proof-display-code code {
          color: var(--color-text);
        }
        .proof-line {
          display: inline;
        }
        .proof-line-num {
          display: inline-block;
          width: 40px;
          text-align: right;
          padding-right: 16px;
          color: var(--color-text-muted);
          opacity: 0.6;
          user-select: none;
          font-size: 12px;
        }
        .proof-line-text {
          padding-right: 20px;
        }
        .proof-token-keyword {
          color: var(--color-accent);
        }
        .proof-token-goal {
          color: var(--color-primary);
        }
        .proof-token-comment {
          color: var(--color-text-muted);
        }
      `}</style>
    </div>
  )
}
