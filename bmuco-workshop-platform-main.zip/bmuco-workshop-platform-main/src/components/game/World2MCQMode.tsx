'use client'

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import type { GameLevel } from '@/lib/game-types'
import ProofDisplay from './ProofDisplay'
import { log } from '@/lib/logger'
import { emitPacket, withProofPacketDefaults } from '@/lib/proof-packets'
import { getOrCreateStudioSessionId } from '@/lib/studio-session-id'

/**
 * Auto-generated MCQ mode for World 2 (GameLevel-shaped data).
 * Each question presents one issue or decoy and asks "Is this a real style issue?"
 */

interface MCQItem {
  id: string
  label: string
  isReal: boolean
  explanation: string
}

function buildQuestions(level: GameLevel): MCQItem[] {
  const items: MCQItem[] = [
    ...level.issues.map(i => ({
      id: i.id,
      label: i.label,
      isReal: true,
      explanation: i.explanation,
    })),
    ...level.decoys.map(d => ({
      id: d.id,
      label: d.label,
      isReal: false,
      explanation: `This is not a real issue — it's a decoy.`,
    })),
  ]
  // Deterministic shuffle seeded by level id
  const seed = level.id * 7 + 13
  return items.sort((a, b) => {
    const ha = ((seed + a.id.charCodeAt(0)) * 2654435761) >>> 0
    const hb = ((seed + b.id.charCodeAt(0)) * 2654435761) >>> 0
    return ha - hb
  })
}

interface World2MCQModeProps {
  level: GameLevel
  userId: string | null
  onComplete?: () => void
}

export default function World2MCQMode({ level, userId, onComplete }: World2MCQModeProps) {
  const sessionRef = useRef('')
  useLayoutEffect(() => {
    sessionRef.current = getOrCreateStudioSessionId()
  }, [])

  const questions = useMemo(() => buildQuestions(level), [level])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [answer, setAnswer] = useState<boolean | null>(null)
  const [status, setStatus] = useState<'idle' | 'correct' | 'wrong'>('idle')
  const [results, setResults] = useState<Array<{ correct: boolean } | null>>(
    Array(questions.length).fill(null)
  )
  const [showCompletion, setShowCompletion] = useState(false)
  const [xpCount, setXpCount] = useState(0)

  const current = questions[currentIndex]
  const completedCount = results.filter(Boolean).length
  const correctCount = results.filter(r => r?.correct).length
  const progressPercent = Math.round((completedCount / questions.length) * 100)

  useEffect(() => {
    if (!showCompletion) return
    let n = 0
    const t = window.setInterval(() => {
      n += 1
      setXpCount(Math.min(10, n))
      if (n >= 10) window.clearInterval(t)
    }, 45)
    return () => window.clearInterval(t)
  }, [showCompletion])

  const submitAnswer = (isReal: boolean) => {
    if (status !== 'idle') return
    setAnswer(isReal)
    const correct = isReal === current.isReal

    log({
      level_id: String(level.id),
      mode: 'mcq',
      step_id: current.id,
      event: 'mcq_answered',
      value: {
        question_id: current.id,
        selected: isReal ? 'real_issue' : 'not_an_issue',
        correct,
        item_label: current.label,
      },
      duration_ms: 0,
      confidence: null,
      annotation: null,
    })

    emitPacket(
      withProofPacketDefaults({
        session_id: sessionRef.current,
        user_id: userId ?? null,
        level_id: String(level.id),
        world_id: level.world_id,
        mode: 'mcq',
        proof_state_before: `${level.title}\n\nStatement: "${current.label}"`,
        tactic_chosen: isReal ? 'real_issue' : 'not_an_issue',
        proof_state_after: correct ? 'correct' : 'incorrect',
        tactic_success: correct,
        step_number: currentIndex + 1,
        total_steps: questions.length,
        dimension: 'tactic_selection',
        dataset_label: 'w2_mcq_issue_identification',
      })
    )

    setStatus(correct ? 'correct' : 'wrong')
    setResults(prev => {
      const next = [...prev]
      next[currentIndex] = { correct }
      return next
    })
  }

  const advanceQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1)
      setAnswer(null)
      setStatus('idle')
    } else {
      setShowCompletion(true)
    }
  }

  if (showCompletion) {
    const allCorrect = correctCount === questions.length
    return (
      <div className="w2mcq-completion">
        <div className="w2mcq-completion-icon">{allCorrect ? '★' : '☆'}</div>
        <h3 className="w2mcq-completion-title">
          {allCorrect ? 'Perfect!' : 'MCQ Complete'}
        </h3>
        <p className="w2mcq-completion-stats">
          {correctCount} / {questions.length} correct — +{xpCount} XP
        </p>
        <p style={{ fontSize: 13, color: 'var(--color-text-muted)', marginTop: 8 }}>
          Now try <strong>Review mode</strong> to find all the issues yourself.
        </p>
        {onComplete && (
          <button onClick={onComplete} className="btn btn-primary" style={{ marginTop: 16 }}>
            Continue
          </button>
        )}

        <style jsx>{`
          .w2mcq-completion {
            text-align: center;
            padding: 48px 24px;
          }
          .w2mcq-completion-icon {
            font-size: 48px;
            margin-bottom: 12px;
          }
          .w2mcq-completion-title {
            font-size: 22px;
            font-weight: 700;
            color: var(--color-text);
          }
          .w2mcq-completion-stats {
            font-size: 14px;
            color: var(--color-text-secondary);
            margin-top: 8px;
          }
        `}</style>
      </div>
    )
  }

  return (
    <div className="w2mcq">
      {/* Progress bar */}
      <div className="w2mcq-progress">
        <div className="w2mcq-progress-fill" style={{ width: `${progressPercent}%` }} />
      </div>
      <p className="w2mcq-counter">
        Question {currentIndex + 1} of {questions.length}
      </p>

      {/* Proof display */}
      <ProofDisplay
        code={level.proof_display}
        informalStatement={level.informal_statement || undefined}
      />

      {/* Question */}
      <div className="w2mcq-question">
        <p className="w2mcq-question-label">Is this a real style issue?</p>
        <div className="w2mcq-statement">
          &ldquo;{current.label}&rdquo;
        </div>

        {status === 'idle' ? (
          <div className="w2mcq-buttons">
            <button
              className="btn w2mcq-btn w2mcq-btn-yes"
              onClick={() => submitAnswer(true)}
            >
              Yes — Real Issue
            </button>
            <button
              className="btn w2mcq-btn w2mcq-btn-no"
              onClick={() => submitAnswer(false)}
            >
              No — Not an Issue
            </button>
          </div>
        ) : (
          <div className="w2mcq-feedback">
            <div className={`w2mcq-feedback-badge ${status === 'correct' ? 'w2mcq-correct' : 'w2mcq-wrong'}`}>
              {status === 'correct' ? 'Correct!' : 'Incorrect'}
            </div>
            <p className="w2mcq-explanation">{current.explanation}</p>
            <button className="btn btn-primary" onClick={advanceQuestion} style={{ marginTop: 12 }}>
              {currentIndex < questions.length - 1 ? 'Next Question' : 'See Results'}
            </button>
          </div>
        )}
      </div>

      <style jsx>{`
        .w2mcq {
          display: flex;
          flex-direction: column;
          gap: 20px;
          max-width: 720px;
          margin: 0 auto;
        }
        .w2mcq-progress {
          height: 4px;
          background: var(--color-surface);
          border-radius: 2px;
          overflow: hidden;
        }
        .w2mcq-progress-fill {
          height: 100%;
          background: var(--color-primary);
          transition: width 300ms ease;
        }
        .w2mcq-counter {
          font-size: 12px;
          color: var(--color-text-muted);
          text-align: center;
        }
        .w2mcq-question {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 24px;
        }
        .w2mcq-question-label {
          font-size: 14px;
          font-weight: 600;
          color: var(--color-text-secondary);
          margin-bottom: 12px;
        }
        .w2mcq-statement {
          font-size: 15px;
          color: var(--color-text);
          line-height: 1.6;
          margin-bottom: 20px;
          padding: 12px 16px;
          background: rgba(59, 130, 246, 0.04);
          border-left: 3px solid var(--color-primary);
          border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
        }
        .w2mcq-buttons {
          display: flex;
          gap: 12px;
        }
        .w2mcq-btn {
          flex: 1;
          padding: 12px 16px;
          font-size: 14px;
          font-weight: 600;
          border-radius: var(--radius-md);
          cursor: pointer;
          transition: all 150ms;
        }
        .w2mcq-btn-yes {
          background: rgba(59, 130, 246, 0.08);
          border: 1px solid rgba(59, 130, 246, 0.3);
          color: #3b82f6;
        }
        .w2mcq-btn-yes:hover {
          background: rgba(59, 130, 246, 0.15);
        }
        .w2mcq-btn-no {
          background: var(--color-surface-raised);
          border: 1px solid var(--color-border);
          color: var(--color-text-secondary);
        }
        .w2mcq-btn-no:hover {
          border-color: var(--color-text-muted);
        }
        .w2mcq-feedback {
          text-align: center;
        }
        .w2mcq-feedback-badge {
          display: inline-block;
          padding: 6px 16px;
          border-radius: var(--radius-sm);
          font-size: 13px;
          font-weight: 600;
          margin-bottom: 12px;
        }
        .w2mcq-correct {
          background: var(--bmuco-green-soft);
          color: var(--color-primary);
          border: 1px solid var(--bmuco-green-border);
        }
        .w2mcq-wrong {
          background: rgba(217, 83, 79, 0.08);
          color: #d9534f;
          border: 1px solid rgba(217, 83, 79, 0.3);
        }
        .w2mcq-explanation {
          font-size: 13px;
          color: var(--color-text-secondary);
          line-height: 1.6;
          max-width: 560px;
          margin: 0 auto;
        }
        @media (max-width: 600px) {
          .w2mcq-buttons {
            flex-direction: column;
          }
        }
      `}</style>
    </div>
  )
}
