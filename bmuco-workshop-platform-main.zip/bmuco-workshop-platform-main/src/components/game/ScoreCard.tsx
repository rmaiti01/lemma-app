'use client'

import { useState, useEffect, useRef } from 'react'
import { CheckCircle, XCircle, ChevronRight, ChevronDown, Share2 } from 'lucide-react'
import type { ScoreResult, LevelIssue } from '@/lib/game-types'
import { axleSimplify } from '@/lib/axle-client'
import StarRating from './StarRating'
import toast from 'react-hot-toast'

interface ScoreCardProps {
  score: ScoreResult
  issues: LevelIssue[]
  onTryAgain: () => void
  onNextLevel?: () => void
  nextLevelLabel?: string
  /** Lean source with imports — AXLE simplify_theorems after submit */
  simplifyLeanSource?: string | null
  /** Challenge-a-friend deep link (logged-in players only — LevelPlayer passes these). */
  shareWorldId?: number
  shareLevelNumber?: number
  shareChallengerName?: string | null
}

export default function ScoreCard({
  score,
  issues,
  onTryAgain,
  onNextLevel,
  nextLevelLabel,
  simplifyLeanSource,
  shareWorldId,
  shareLevelNumber,
  shareChallengerName,
}: ScoreCardProps) {
  const [expandedIssue, setExpandedIssue] = useState<string | null>(null)
  const [displayPoints, setDisplayPoints] = useState(0)
  const animFrameRef = useRef<number>(0)
  const [simp, setSimp] = useState<{
    loading: boolean
    simplified: boolean | null
    content: string | null
    mock: boolean
  } | null>(null)

  // Animated points counter (800ms)
  useEffect(() => {
    const target = score.points
    const duration = 800
    const start = performance.now()
    const tick = (now: number) => {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      setDisplayPoints(Math.round(target * progress))
      if (progress < 1) animFrameRef.current = requestAnimationFrame(tick)
    }
    animFrameRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(animFrameRef.current)
  }, [score.points])

  useEffect(() => {
    if (!simplifyLeanSource?.trim()) {
      setSimp(null)
      return
    }
    let cancelled = false
    setSimp({ loading: true, simplified: null, content: null, mock: false })
    axleSimplify(simplifyLeanSource).then(r => {
      if (cancelled) return
      setSimp({
        loading: false,
        simplified: r.simplified,
        content: r.content,
        mock: r.mock,
      })
    })
    return () => {
      cancelled = true
    }
  }, [simplifyLeanSource])

  const foundSet = new Set(score.issuesFound)

  const canShareChallenge =
    typeof shareWorldId === 'number' &&
    Number.isFinite(shareWorldId) &&
    typeof shareLevelNumber === 'number' &&
    Number.isFinite(shareLevelNumber) &&
    Boolean(shareChallengerName?.trim())

  const copyChallengeLink = async () => {
    if (!canShareChallenge) return
    const origin =
      typeof window !== 'undefined' && window.location?.origin
        ? window.location.origin
        : process.env.NEXT_PUBLIC_SITE_URL || 'https://studio.bmuco.org'
    const by = encodeURIComponent(shareChallengerName!.trim())
    const url = `${origin}/studio/play/${shareWorldId}?level=${shareLevelNumber}&challenge=true&by=${by}`
    try {
      await navigator.clipboard.writeText(url)
      toast.success('Challenge link copied', { duration: 2500 })
    } catch {
      toast.error('Could not copy link', { duration: 3000 })
    }
  }

  const getMessage = () => {
    if (score.stars === 3) return 'Perfect \u2014 you found every issue!'
    if (score.stars === 2) return "Great eye! Here's what you might have missed:"
    if (score.stars === 1) return 'Good start. Review the full breakdown below:'
    return "Don't worry \u2014 review the issues and try again!"
  }

  return (
    <div className="score-card">
      {/* Hero */}
        <div className="score-hero bmuco-arcade-score-hero">
        <StarRating stars={score.stars} size="lg" animate />
        <div className="score-points">{displayPoints} pts</div>
        <div className="score-detail">
          {score.issuesFound.length} of {score.issuesFound.length + score.issuesMissed.length} issues found
          {score.falsePositives.length > 0 && (
            <span className="score-fp">
              {' '}&middot; {score.falsePositives.length} false positive{score.falsePositives.length > 1 ? 's' : ''}
            </span>
          )}
        </div>
        <div className="score-message">{getMessage()}</div>
      </div>

      {/* Issue breakdown */}
      <div className="score-section">
        <h3 className="score-label">Full Review</h3>
        <div className="score-review-list">
          {issues.map(issue => {
            const found = foundSet.has(issue.id)
            const expanded = expandedIssue === issue.id
            return (
              <div key={issue.id} className={`review-item ${found ? 'found' : 'missed'}`}>
                <button
                  className="review-header"
                  onClick={() => setExpandedIssue(expanded ? null : issue.id)}
                >
                  {found ? (
                    <CheckCircle size={16} color="#3b82f6" />
                  ) : (
                    <XCircle size={16} color="#999999" />
                  )}
                  <span className="review-title">{issue.label}</span>
                  <span className={`review-badge ${found ? 'found' : 'missed'}`}>
                    {found ? 'Found' : 'Missed'}
                  </span>
                  {expanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                </button>
                {expanded && (
                  <div className="review-explanation">{issue.explanation}</div>
                )}
              </div>
            )
          })}

          {/* Show false positives if any */}
          {score.falsePositives.length > 0 && (
            <div className="review-item fp">
              <div className="review-header" style={{ cursor: 'default' }}>
                <XCircle size={16} color="#ef4444" />
                <span className="review-title">
                  {score.falsePositives.length} false positive{score.falsePositives.length > 1 ? 's' : ''} (-{score.falsePositives.length * 30} pts)
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {simplifyLeanSource && simp && (
        <div className="score-section">
          <h3 className="score-label">Mathlib-style simplification</h3>
          {simp.loading && (
            <p style={{ fontSize: 14, color: 'var(--color-text-muted)', margin: 0 }}>
              Asking AXLE how Mathlib might tighten this proof…
            </p>
          )}
          {!simp.loading && simp.mock && (
            <p style={{ fontSize: 14, color: 'var(--color-text-muted)', margin: 0 }}>
              AXLE is offline — set <code>AXLE_API_KEY</code> to see an auto-simplified version of the
              displayed proof.
            </p>
          )}
          {!simp.loading && !simp.mock && simp.simplified && simp.content && (
            <div>
              <p style={{ fontSize: 14, color: 'var(--color-text-secondary)', margin: '0 0 8px' }}>
                Here&apos;s a cleaned-up version (unused tactics removed where AXLE could):
              </p>
              <pre
                style={{
                  margin: 0,
                  padding: 14,
                  fontSize: 12,
                  lineHeight: 1.55,
                  background: '#0d1117',
                  color: '#e6edf3',
                  borderRadius: 'var(--radius-md)',
                  border: '1px solid var(--color-border)',
                  overflow: 'auto',
                  maxHeight: 320,
                  fontFamily: 'var(--font-mono)',
                  whiteSpace: 'pre-wrap',
                  wordBreak: 'break-word',
                }}
              >
                {simp.content}
              </pre>
            </div>
          )}
          {!simp.loading && !simp.mock && !simp.simplified && (
            <p style={{ fontSize: 14, color: 'var(--color-text-muted)', margin: 0 }}>
              AXLE did not simplify further (proof may already be minimal for this snippet).
            </p>
          )}
        </div>
      )}

      {/* Actions */}
      <div className="score-actions">
        <button onClick={onTryAgain} className="btn btn-secondary">
          Try Again
        </button>
        {canShareChallenge && (
          <button type="button" onClick={() => void copyChallengeLink()} className="btn btn-secondary">
            <Share2 size={16} style={{ marginRight: 6, verticalAlign: 'middle' }} />
            Challenge a friend
          </button>
        )}
        {onNextLevel && (
          <button onClick={onNextLevel} className="btn btn-primary">
            {nextLevelLabel || 'Next Level'} &rarr;
          </button>
        )}
      </div>

      <style jsx>{`
        .score-card {
          display: flex;
          flex-direction: column;
          gap: 24px;
        }
        .score-hero {
          text-align: center;
          padding: 32px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-lg);
        }
        .score-points {
          font-family: var(--font-heading);
          font-size: 48px;
          font-weight: 700;
          color: #3b82f6;
          margin: 8px 0;
        }
        .score-detail {
          font-size: 14px;
          color: var(--color-text-secondary);
          margin-bottom: 4px;
        }
        .score-fp {
          color: #ef4444;
        }
        .score-message {
          font-size: 14px;
          color: var(--color-text-muted);
        }
        .score-section {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .score-label {
          font-weight: 600;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--color-text-muted);
        }
        .score-review-list {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .review-item {
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          overflow: hidden;
        }
        .review-item.found {
          border-color: rgba(59, 130, 246, 0.25);
        }
        .review-item.missed {
          border-color: var(--color-border);
        }
        .review-item.fp {
          border-color: rgba(239, 68, 68, 0.2);
        }
        .review-header {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 16px;
          background: none;
          border: none;
          color: var(--color-text);
          font-size: 14px;
          cursor: pointer;
          text-align: left;
        }
        .review-title {
          flex: 1;
        }
        .review-badge {
          font-size: 10px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          flex-shrink: 0;
        }
        .review-badge.found {
          color: #3b82f6;
        }
        .review-badge.missed {
          color: var(--color-text-muted);
        }
        .review-explanation {
          padding: 12px 16px 16px 42px;
          font-size: 14px;
          color: var(--color-text-secondary);
          line-height: 1.6;
          border-top: 1px solid var(--color-border);
        }
        .score-actions {
          display: flex;
          gap: 12px;
          justify-content: center;
          flex-wrap: wrap;
        }
      `}</style>
    </div>
  )
}
