'use client'

import type { GameWorld, LevelCompletion } from '@/lib/game-types'
import StarRating from './StarRating'
import Link from 'next/link'

const worldIcons: Record<string, string> = {
  smell_test: '\ud83d\udc43',
  style_police: '\ud83d\udc6e',
  reinvention_detector: '\ud83d\udd0e',
  generality_inspector: '\ud83d\udd2c',
  architecture_critic: '\ud83c\udfd7\ufe0f',
  drift_detective: '\ud83d\udd75\ufe0f',
  full_review: '\u2694\ufe0f',
}

interface WorldMapProps {
  worlds: GameWorld[]
  completions: LevelCompletion[]
  levelCounts: Record<number, number> // world_id -> number of levels
}

export default function WorldMap({ worlds, completions, levelCounts }: WorldMapProps) {
  return (
    <div className="world-map">
      {worlds.map(world => {
        const count = levelCounts[world.id] || 0
        const worldCompletions = completions.filter(c => {
          // Match completions to world via level_id range (simple approach)
          return true // filtered by parent
        })
        const starsEarned = completions
          .filter(() => true) // Will be filtered properly once we have world_id on completions
          .reduce((s, c) => s + c.stars, 0)
        const maxStars = count * 3
        const locked = !world.is_active && world.id !== 1

        return (
          <div key={world.id} className={`world-card ${locked ? 'locked' : ''}`}>
            <div className="world-card-icon">
              {worldIcons[world.type] || '\ud83c\udfae'}
            </div>
            <div className="world-card-body">
              <div className="world-card-header">
                <span className="world-card-num">World {world.id}</span>
                <h3 className="world-card-name">{world.name}</h3>
              </div>
              <p className="world-card-desc">{world.description}</p>
              {locked ? (
                <div className="world-card-lock">
                  {world.unlock_stars} stars to unlock
                </div>
              ) : count > 0 ? (
                <div className="world-card-progress">
                  <Link href={`/studio/play/${world.id}`} className="btn btn-primary btn-sm">
                    Play
                  </Link>
                </div>
              ) : (
                <div className="world-card-lock">Coming soon</div>
              )}
            </div>
          </div>
        )
      })}

      <style jsx>{`
        .world-map {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .world-card {
          display: flex;
          gap: 20px;
          padding: 24px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-lg);
          transition: border-color 150ms;
        }
        .world-card:not(.locked):hover {
          border-color: var(--color-border-light);
        }
        .world-card.locked {
          opacity: 0.5;
        }
        .world-card-icon {
          font-size: 32px;
          flex-shrink: 0;
          width: 48px;
          text-align: center;
        }
        .world-card-body {
          flex: 1;
          min-width: 0;
        }
        .world-card-num {
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: #3b82f6;
        }
        .world-card-name {
          font-family: var(--font-heading);
          font-size: 18px;
          font-weight: 700;
          color: var(--color-text);
          margin: 2px 0 6px;
        }
        .world-card-desc {
          font-size: 14px;
          color: var(--color-text-secondary);
          line-height: 1.5;
          margin-bottom: 12px;
        }
        .world-card-lock {
          font-size: 13px;
          color: var(--color-text-muted);
          font-style: italic;
        }
        .world-card-progress {
          display: flex;
          align-items: center;
          gap: 12px;
        }
      `}</style>
    </div>
  )
}
