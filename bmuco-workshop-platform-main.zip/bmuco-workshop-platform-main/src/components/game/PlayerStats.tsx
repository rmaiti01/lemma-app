'use client'

import type { PlayerProgress } from '@/lib/game-types'

interface PlayerStatsProps {
  progress: PlayerProgress | null
  /** All-time rank from `leaderboard` view (optional). */
  rank?: number | null
}

export default function PlayerStats({ progress, rank }: PlayerStatsProps) {
  if (!progress) {
    return (
      <div className="player-stats">
        <div className="ps-item">
          <span className="ps-value">0</span>
          <span className="ps-label">Stars</span>
        </div>
        <div className="ps-item">
          <span className="ps-value">0</span>
          <span className="ps-label">Points</span>
        </div>
        <div className="ps-item">
          <span className="ps-value">0</span>
          <span className="ps-label">Streak</span>
        </div>
        <div className="ps-item">
          <span className="ps-value">0</span>
          <span className="ps-label">Best</span>
        </div>
        {rank != null && (
          <div className="ps-item">
            <span className="ps-value">#{rank}</span>
            <span className="ps-label">Rank</span>
          </div>
        )}

        <style jsx>{`
          .player-stats {
            display: flex;
            flex-wrap: wrap;
            gap: 20px 24px;
            padding: 16px 24px;
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-lg);
          }
          .ps-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 2px;
            min-width: 56px;
          }
          .ps-value {
            font-family: var(--font-heading);
            font-size: 24px;
            font-weight: 700;
            color: var(--color-text);
          }
          .ps-label {
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--color-text-muted);
          }
        `}</style>
      </div>
    )
  }

  return (
    <div className="player-stats">
      <div className="ps-item">
        <span className="ps-value">{progress.total_stars}</span>
        <span className="ps-label">Stars</span>
      </div>
      <div className="ps-item">
        <span className="ps-value">{progress.total_points}</span>
        <span className="ps-label">Points</span>
      </div>
      <div className="ps-item">
        <span className="ps-value">{progress.current_streak}</span>
        <span className="ps-label">Streak</span>
      </div>
      <div className="ps-item">
        <span className="ps-value">{progress.longest_streak}</span>
        <span className="ps-label">Best</span>
      </div>
      {rank != null && (
        <div className="ps-item">
          <span className="ps-value">#{rank}</span>
          <span className="ps-label">Rank</span>
        </div>
      )}

      <style jsx>{`
        .player-stats {
          display: flex;
          flex-wrap: wrap;
          gap: 20px 24px;
          padding: 16px 24px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-lg);
        }
        .ps-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          min-width: 56px;
        }
        .ps-value {
          font-family: var(--font-heading);
          font-size: 24px;
          font-weight: 700;
          color: var(--color-text);
        }
        .ps-label {
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--color-text-muted);
        }
      `}</style>
    </div>
  )
}
