'use client'

import { useState } from 'react'
import type { BlankState } from '@/hooks/useLevelState'
import type { BlankDef } from '@/lib/world1-data'

interface BlankInputProps {
  blank: BlankDef
  state: BlankState
  onInputChange: (value: string) => void
  onReasoningChange: (value: string) => void
  onCheck: () => void
  onRevealHint: () => void
  pulseHighlight?: boolean
  /** After 3+ failed checks, offer AXLE repair_proofs hint */
  offerRepair?: boolean
  onRepairRequest?: () => void
  repairLoading?: boolean
  repairLean?: string | null
  repairError?: string | null
  onRepairDismiss?: () => void
}

export default function BlankInput({
  blank,
  state,
  onInputChange,
  onReasoningChange,
  onCheck,
  onRevealHint,
  pulseHighlight,
  offerRepair,
  onRepairRequest,
  repairLoading,
  repairLean,
  repairError,
  onRepairDismiss,
}: BlankInputProps) {
  const [whyOpen, setWhyOpen] = useState(false)

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      onCheck()
    }
  }

  return (
    <div
      className={`bi-root${pulseHighlight ? ' bi-pulse' : ''}`}
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 6,
        margin: '6px 0',
      }}
    >
      {/* Input row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <input
          type="text"
          value={state.currentInput}
          onChange={e => onInputChange(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Fill in tactic..."
          disabled={state.checking}
          className="bi-input"
          style={{
            fontFamily: 'var(--font-mono)',
            fontSize: 14,
            background: '#0d1117',
            color: '#c9d1d9',
            border: `2px solid ${
              state.accepted === true
                ? 'var(--color-success)'
                : state.accepted === false
                ? 'var(--color-error)'
                : '#3b3f51'
            }`,
            borderRadius: 'var(--radius-sm)',
            padding: '6px 10px',
            minWidth: 180,
            flex: 1,
            outline: 'none',
            transition: 'border-color var(--transition-fast)',
          }}
        />
        <button
          onClick={onCheck}
          disabled={state.checking || !state.currentInput.trim()}
          style={{
            fontFamily: 'var(--font-mono)',
            fontSize: 12,
            fontWeight: 600,
            padding: '6px 12px',
            background: state.checking ? 'var(--color-border)' : 'var(--color-primary)',
            color: '#fff',
            border: 'none',
            borderRadius: 'var(--radius-sm)',
            cursor: state.checking ? 'wait' : 'pointer',
            opacity: !state.currentInput.trim() ? 0.5 : 1,
            whiteSpace: 'nowrap',
            boxShadow: state.checking ? 'none' : 'var(--shadow-btn-primary)',
          }}
        >
          {state.checking ? (
            <span className="bi-spinner" />
          ) : (
            'Check ↵'
          )}
        </button>
        {state.accepted === true && state.mockMode && (
          <span
            style={{
              fontSize: 11,
              color: 'var(--color-text-muted)',
              border: '1px solid var(--color-border)',
              borderRadius: 999,
              padding: '3px 8px',
              background: 'var(--color-surface-raised)',
              whiteSpace: 'nowrap',
            }}
          >
            ✓ AXLE offline — accepted
          </span>
        )}
      </div>

      {/* Feedback line — keep dark-styled badges */}
      {state.accepted === true && (
        state.mockMode ? (
          <div style={{ fontSize: 12, color: 'var(--color-text-muted)', fontWeight: 500 }}>
            ✓ Accepted (AXLE offline — set API key to enable real verification)
          </div>
        ) : (
          <div style={{ fontSize: 12, color: 'var(--color-success)', fontWeight: 600 }}>
            ✓ Correct
          </div>
        )
      )}
      {state.leanWarning && (
        <div
          style={{
            fontSize: 11,
            color: '#94a3b8',
            fontFamily: 'var(--font-mono)',
            whiteSpace: 'pre-wrap',
          }}
        >
          {state.leanWarning}
        </div>
      )}
      {state.accepted === false && state.leanError && (
        <div
          style={{
            fontSize: 12,
            color: '#ef4444',
            fontFamily: 'var(--font-mono)',
            whiteSpace: 'pre-wrap',
            maxHeight: 80,
            overflow: 'auto',
            background: 'rgba(239,68,68,0.06)',
            padding: '4px 8px',
            borderRadius: 'var(--radius-sm)',
          }}
        >
          ✗ {state.leanError}
        </div>
      )}
      {state.accepted === null && state.attempts.length === 0 && !state.checking && (
        <div style={{ fontSize: 11, color: '#94a3b8' }}>⏳ Not checked yet</div>
      )}

      {/* Why section */}
      <div>
        <button
          onClick={() => setWhyOpen(!whyOpen)}
          style={{
            background: 'none',
            border: 'none',
            color: '#94a3b8',
            fontSize: 11,
            cursor: 'pointer',
            padding: 0,
            display: 'flex',
            alignItems: 'center',
            gap: 4,
          }}
        >
          <span style={{ transform: whyOpen ? 'rotate(180deg)' : 'none', transition: '150ms' }}>
            ▾
          </span>
          Why does this step work here? (optional)
        </button>
        {whyOpen && (
          <textarea
            value={state.reasoning}
            onChange={e => onReasoningChange(e.target.value)}
            placeholder="Optional: why does this step work here?"
            rows={2}
            style={{
              width: '100%',
              marginTop: 4,
              fontFamily: 'var(--font-body)',
              fontSize: 13,
              background: '#0d1117',
              color: '#c9d1d9',
              border: '1px solid #3b3f51',
              borderRadius: 'var(--radius-sm)',
              padding: '6px 8px',
              resize: 'vertical',
              outline: 'none',
            }}
          />
        )}
      </div>

      {/* Hints */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <button
          onClick={onRevealHint}
          disabled={state.hintLevel >= 3}
          style={{
            background: 'none',
            border: '1px solid var(--color-border)',
            color: state.hintLevel >= 3 ? 'var(--color-text-muted)' : 'var(--color-text-secondary)',
            fontSize: 11,
            fontWeight: 500,
            padding: '3px 8px',
            borderRadius: 'var(--radius-sm)',
            cursor: state.hintLevel >= 3 ? 'default' : 'pointer',
          }}
        >
          Hint {state.hintLevel}/3
        </button>
        {state.hintLevel >= 3 && (
          <span style={{ fontSize: 10, color: 'var(--color-error)' }}>-25 pts</span>
        )}
      </div>
      {state.hintLevel > 0 && (
        <div
          style={{
            fontSize: 12,
            color: 'var(--color-text-secondary)',
            background: 'rgba(92,184,92,0.06)',
            border: '1px solid rgba(92,184,92,0.2)',
            borderRadius: 'var(--radius-sm)',
            padding: '6px 10px',
          }}
        >
          {blank.hints.slice(0, state.hintLevel).map((h, i) => (
            <div key={i} style={{ marginBottom: i < state.hintLevel - 1 ? 4 : 0 }}>
              <strong style={{ color: 'var(--color-primary)' }}>Hint {i + 1}:</strong> {h}
            </div>
          ))}
        </div>
      )}

      {offerRepair && onRepairRequest && (
        <div
          style={{
            marginTop: 4,
            padding: '8px 10px',
            borderRadius: 'var(--radius-sm)',
            border: '1px solid rgba(59,130,246,0.35)',
            background: 'rgba(59,130,246,0.06)',
          }}
        >
          <div style={{ fontSize: 12, color: 'var(--color-text-secondary)', marginBottom: 6 }}>
            Stuck after {state.attempts.length} tries? AXLE can try to repair this partial proof.
          </div>
          <button
            type="button"
            onClick={onRepairRequest}
            disabled={repairLoading}
            style={{
              fontSize: 12,
              fontWeight: 600,
              padding: '6px 12px',
              borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--color-primary)',
              background: repairLoading ? 'var(--color-border)' : 'var(--color-primary)',
              color: '#fff',
              cursor: repairLoading ? 'wait' : 'pointer',
            }}
          >
            {repairLoading ? 'Asking AXLE…' : 'Want AXLE to try fixing it?'}
          </button>
        </div>
      )}

      {(repairLean || repairError) && (
        <div
          style={{
            marginTop: 8,
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius-sm)',
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '6px 10px',
              background: 'var(--color-surface-raised)',
              fontSize: 11,
              fontWeight: 600,
              textTransform: 'uppercase',
              letterSpacing: '0.06em',
              color: 'var(--color-text-muted)',
            }}
          >
            <span>AXLE repair hint</span>
            {onRepairDismiss && (
              <button
                type="button"
                onClick={onRepairDismiss}
                style={{
                  fontSize: 11,
                  border: 'none',
                  background: 'none',
                  color: 'var(--color-primary)',
                  cursor: 'pointer',
                }}
              >
                Dismiss
              </button>
            )}
          </div>
          {repairError && (
            <div style={{ padding: '8px 10px', fontSize: 12, color: '#ef4444' }}>{repairError}</div>
          )}
          {repairLean && (
            <pre
              style={{
                margin: 0,
                maxHeight: 200,
                overflow: 'auto',
                padding: 10,
                fontSize: 11,
                lineHeight: 1.5,
                background: '#0d1117',
                color: '#c9d1d9',
                fontFamily: 'var(--font-mono)',
                whiteSpace: 'pre-wrap',
                wordBreak: 'break-word',
              }}
            >
              {repairLean}
            </pre>
          )}
        </div>
      )}

      <style jsx>{`
        .bi-pulse {
          animation: bi-glow 1s ease-in-out;
        }
        @keyframes bi-glow {
          0%, 100% { box-shadow: none; }
          50% { box-shadow: 0 0 12px rgba(59, 130, 246, 0.3); }
        }
        .bi-input:focus {
          border-color: var(--color-primary) !important;
          box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.15);
        }
        .bi-spinner {
          display: inline-block;
          width: 12px;
          height: 12px;
          border: 2px solid rgba(255,255,255,0.3);
          border-top-color: #fff;
          border-radius: 50%;
          animation: bi-spin 0.6s linear infinite;
        }
        @keyframes bi-spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  )
}
