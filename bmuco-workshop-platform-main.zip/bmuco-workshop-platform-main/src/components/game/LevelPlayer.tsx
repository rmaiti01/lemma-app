'use client'

import { useState, useRef, useEffect, useLayoutEffect, useMemo, useCallback } from 'react'
import type { GameLevel, ChecklistItem, ScoreResult } from '@/lib/game-types'
import { calculateScore } from '@/lib/game-data/scoring'
import ProofDisplay from './ProofDisplay'
import IssueChecklist from './IssueChecklist'
import ScoreCard from './ScoreCard'
import { log } from '@/lib/logger'
import { useProgress } from '@/components/ProgressProvider'
import { emitPacket, withProofPacketDefaults } from '@/lib/proof-packets'
import { getOrCreateStudioSessionId } from '@/lib/studio-session-id'
import { createClient } from '@/lib/supabase/client'
import { showTraceAchievements } from '@/components/game/AchievementToast'

type GameState = 'idle' | 'playing' | 'submitted'
type CheckState = 'idle' | 'checking' | 'pass' | 'fail' | 'error'

interface LevelPlayerProps {
  level: GameLevel
  isBoss?: boolean
  userId?: string | null
  onNextLevel?: () => void
  nextLevelLabel?: string
}

export default function LevelPlayer({
  level,
  isBoss,
  userId,
  onNextLevel,
  nextLevelLabel,
}: LevelPlayerProps) {
  const { mutate: refreshProgress } = useProgress()
  const [state, setState] = useState<GameState>('idle')
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [confidences, setConfidences] = useState<Record<string, number>>({})
  const [score, setScore] = useState<ScoreResult | null>(null)
  const [elapsed, setElapsed] = useState(0)
  const [checkState, setCheckState] = useState<CheckState>('idle')
  const [checkMsg, setCheckMsg] = useState('')
  const [syntaxErrors, setSyntaxErrors] = useState<string[]>([])
  const [syntaxExpanded, setSyntaxExpanded] = useState(false)
  const [challengerDisplayName, setChallengerDisplayName] = useState<string | null>(null)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const sessionRef = useRef('')

  useLayoutEffect(() => {
    sessionRef.current = getOrCreateStudioSessionId()
  }, [])
  const startTimeRef = useRef<number>(0)

  // Build shuffled checklist from issues + decoys
  const checklist: ChecklistItem[] = useMemo(() => {
    const items: ChecklistItem[] = [
      ...level.issues.map(i => ({ id: i.id, label: i.label, is_real_issue: true })),
      ...level.decoys.map(d => ({ id: d.id, label: d.label, is_real_issue: false })),
    ]
    // Deterministic shuffle seeded by level id
    for (let i = items.length - 1; i > 0; i--) {
      const j = ((level.id * 31 + i * 17) % (i + 1))
      ;[items[i], items[j]] = [items[j], items[i]]
    }
    return items
  }, [level])

  const realIssueIds = useMemo(() => level.issues.map(i => i.id), [level])
  const decoyIds = useMemo(() => level.decoys.map(d => d.id), [level])

  // Reset all state when level changes
  useEffect(() => {
    setState('idle')
    setSelected(new Set())
    setConfidences({})
    setScore(null)
    setElapsed(0)
    setCheckMsg('')
  }, [level.id])

  useEffect(() => {
    setCheckState('idle')
    setCheckMsg('')
    setSyntaxErrors([])
    setSyntaxExpanded(false)
  }, [level.id])

  useEffect(() => {
    if (!userId) {
      setChallengerDisplayName(null)
      return
    }
    const supabase = createClient()
    void supabase.auth.getUser().then(({ data }) => {
      const u = data.user
      if (!u) return
      setChallengerDisplayName(
        u.user_metadata?.full_name ||
          u.user_metadata?.name ||
          u.email?.split('@')[0] ||
          'Player'
      )
    })
  }, [userId])

  // Timer
  useEffect(() => {
    if (state === 'playing') {
      startTimeRef.current = Date.now()
      timerRef.current = setInterval(() => {
        setElapsed(Math.floor((Date.now() - startTimeRef.current) / 1000))
      }, 1000)
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [state])

  const handleStart = useCallback(() => {
    setState('playing')
    setSelected(new Set())
    setConfidences({})
    setScore(null)
    setElapsed(0)
    setCheckState('idle')
    setCheckMsg('')
    emitPacket(
      withProofPacketDefaults({
        session_id: sessionRef.current,
        user_id: userId ?? null,
        level_id: String(level.id),
        world_id: level.world_id,
        mode: 'review',
        proof_state_before: level.proof_display,
        tactic_chosen: 'review_session_start',
        proof_state_after: null,
        tactic_success: true,
        step_number: 1,
        total_steps: checklist.length,
        dimension: 'dead_end_recognition',
        dataset_label: 'review_session_start',
      })
    )
  }, [checklist.length, level.id, level.world_id, level.proof_display, userId])

  const handleToggle = useCallback(
    (id: string) => {
      setSelected(prev => {
        const next = new Set(prev)
        const had = next.has(id)
        if (had) {
          next.delete(id)
          setConfidences(c => {
            const n = { ...c }
            delete n[id]
            return n
          })
        } else {
          next.add(id)
          setConfidences(c => ({ ...c, [id]: 3 }))
        }
        const idx = checklist.findIndex(c => c.id === id)
        emitPacket(
          withProofPacketDefaults({
            session_id: sessionRef.current,
            user_id: userId ?? null,
            level_id: String(level.id),
            world_id: level.world_id,
            mode: 'review',
            proof_state_before: level.proof_display,
            tactic_chosen: `${had ? 'checklist_deselect' : 'checklist_select'}:${id}`,
            proof_state_after: null,
            tactic_success: true,
            step_number: idx >= 0 ? idx + 1 : 1,
            total_steps: checklist.length,
            dimension: 'dead_end_recognition',
            dataset_label: 'review_checklist_toggle',
          })
        )
        return next
      })
    },
    [checklist, level.id, level.world_id, level.proof_display, userId]
  )

  const handleConfidenceChange = useCallback((id: string, value: number) => {
    setConfidences(prev => ({ ...prev, [id]: value }))
  }, [])

  const handleSubmit = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current)

    const submitted = Array.from(selected)
    const result = calculateScore(submitted, realIssueIds, decoyIds)
    setScore(result)
    setState('submitted')

    const reviewIssues = level.issues
    const fpCount = result.falsePositives.length
    const totalSteps = reviewIssues.length + fpCount
    reviewIssues.forEach((issue, idx) => {
      const identified = result.issuesFound.includes(issue.id)
      emitPacket(
        withProofPacketDefaults({
          session_id: sessionRef.current,
          user_id: userId ?? null,
          level_id: String(level.id),
          world_id: level.world_id,
          mode: 'review',
          proof_state_before: level.proof_display,
          tactic_chosen: identified
            ? `identified_issue:${issue.id}`
            : `missed_issue:${issue.id}`,
          proof_state_after: null,
          tactic_success: identified,
          confidence: confidences[issue.id] ?? null,
          time_to_decision_ms: null,
          step_number: idx + 1,
          total_steps: totalSteps,
          dimension: 'dead_end_recognition',
          dataset_label: 'review_issue_identification',
        })
      )
    })
    result.falsePositives.forEach((decoyId, i) => {
      emitPacket(
        withProofPacketDefaults({
          session_id: sessionRef.current,
          user_id: userId ?? null,
          level_id: String(level.id),
          world_id: level.world_id,
          mode: 'review',
          proof_state_before: level.proof_display,
          tactic_chosen: `false_positive:${decoyId}`,
          proof_state_after: null,
          tactic_success: false,
          step_number: reviewIssues.length + i + 1,
          total_steps: totalSteps,
          dimension: 'dead_end_recognition',
          dataset_label: 'review_decoy_selected',
        })
      )
    })

    // Fire-and-forget trace POST
    const trace = {
      session_id: sessionRef.current,
      user_id: userId || null,
      level_id: level.id,
      world_id: level.world_id,
      level_number: level.level_number,
      proof_shown: level.proof_display,
      issues_identified: result.issuesFound,
      issues_missed: result.issuesMissed,
      false_positives: result.falsePositives,
      stars_earned: result.stars,
      points_earned: result.points,
      time_seconds: elapsed,
      player_skill: 'unknown',
      confidence_scores: confidences,
    }
    void fetch('/studio/api/traces', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(trace),
    })
      .then(async res => {
        if (res.ok) refreshProgress()
        const data = (await res.json().catch(() => ({}))) as { achievements?: unknown }
        const raw = data?.achievements
        if (Array.isArray(raw) && raw.length > 0) {
          const cleaned = raw.filter(
            (x): x is { id: string; title: string; description: string } =>
              x != null &&
              typeof x === 'object' &&
              typeof (x as { id?: string }).id === 'string' &&
              typeof (x as { title?: string }).title === 'string' &&
              typeof (x as { description?: string }).description === 'string'
          )
          if (cleaned.length) showTraceAchievements(cleaned)
        }
      })
      .catch(() => {})
  }, [selected, realIssueIds, decoyIds, userId, level, elapsed, confidences, refreshProgress])

  const handleTryAgain = useCallback(() => {
    handleStart()
  }, [handleStart])

  const handleSyntaxCheck = useCallback(async () => {
    setCheckState('checking')
    setCheckMsg('')
    setSyntaxErrors([])
    setSyntaxExpanded(false)
    const startedAt = performance.now()
    try {
      const content = level.proof_display.includes('import ')
        ? level.proof_display
        : `import Mathlib\n${level.proof_display}`
      const res = await fetch('/api/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content }),
      })
      const payload = await res.json()
      if (!res.ok || payload?.ok !== true) {
        setCheckState('error')
        setCheckMsg(payload?.error || 'Check unavailable — try again')
        const durationMs = Math.round(performance.now() - startedAt)
        log({
          level_id: String(level.id),
          mode: 'review',
          step_id: 'syntax-check',
          event: 'axle_response',
          value: {
            endpoint: '/api/check',
            okay: false,
            error_count: 1,
            duration_ms: durationMs,
          },
          duration_ms: durationMs,
          confidence: null,
          annotation: null,
        })
        emitPacket(
          withProofPacketDefaults({
            session_id: sessionRef.current,
            user_id: userId ?? null,
            level_id: String(level.id),
            world_id: level.world_id,
            mode: 'review',
            proof_state_before: content.slice(0, 8000),
            tactic_chosen: 'syntax_check',
            proof_state_after: null,
            tactic_success: false,
            axle_endpoint: '/api/check',
            axle_response_ok: false,
            axle_duration_ms: durationMs,
            axle_error_message: payload?.error ?? 'check_unavailable',
            step_number: 1,
            total_steps: 1,
            dimension: 'syntax_verification',
            dataset_label: 'review_syntax_axle_check',
          })
        )
        return
      }
      const data = payload.result || {}
      const errors = Array.isArray(data.lean_messages?.errors)
        ? data.lean_messages.errors
        : []
      const errorMessages = errors.map((e: any) => e.message || e.text || String(e))
      setSyntaxErrors(errorMessages)
      setSyntaxExpanded(errorMessages.length > 0)
      const pass = data.okay === true && errors.length === 0
      const durationMs = Math.round(performance.now() - startedAt)
      log({
        level_id: String(level.id),
        mode: 'review',
        step_id: 'syntax-check',
        event: 'axle_response',
        value: {
          endpoint: '/api/check',
          okay: pass,
          error_count: errorMessages.length,
          duration_ms: durationMs,
        },
        duration_ms: durationMs,
        confidence: null,
        annotation: null,
      })

      emitPacket(
        withProofPacketDefaults({
          session_id: sessionRef.current,
          user_id: userId ?? null,
          level_id: String(level.id),
          world_id: level.world_id,
          mode: 'review',
          proof_state_before: content.slice(0, 8000),
          tactic_chosen: 'syntax_check',
          proof_state_after: pass ? 'syntax_ok' : errorMessages.join('\n').slice(0, 4000),
          tactic_success: pass,
          axle_endpoint: '/api/check',
          axle_response_ok: true,
          axle_duration_ms: durationMs,
          axle_error_message: pass ? null : errorMessages[0] ?? null,
          step_number: 1,
          total_steps: 1,
          dimension: 'syntax_verification',
          dataset_label: 'review_syntax_axle_check',
        })
      )

      if (pass) {
        setCheckState('pass')
        setCheckMsg('Syntax OK ✓')
      } else {
        setCheckState('fail')
        setCheckMsg('Syntax Error')
      }
    } catch {
      const durationMs = Math.round(performance.now() - startedAt)
      setCheckState('error')
      setCheckMsg('Check unavailable — try again')
      log({
        level_id: String(level.id),
        mode: 'review',
        step_id: 'syntax-check',
        event: 'axle_response',
        value: {
          endpoint: '/api/check',
          okay: false,
          error_count: 1,
          duration_ms: durationMs,
        },
        duration_ms: durationMs,
        confidence: null,
        annotation: null,
      })
      emitPacket(
        withProofPacketDefaults({
          session_id: sessionRef.current,
          user_id: userId ?? null,
          level_id: String(level.id),
          world_id: level.world_id,
          mode: 'review',
          proof_state_before: level.proof_display.slice(0, 8000),
          tactic_chosen: 'syntax_check',
          proof_state_after: null,
          tactic_success: false,
          axle_endpoint: '/api/check',
          axle_response_ok: false,
          axle_duration_ms: durationMs,
          axle_error_message: 'network_or_parse_error',
          step_number: 1,
          total_steps: 1,
          dimension: 'syntax_verification',
          dataset_label: 'review_syntax_axle_check',
        })
      )
    }
  }, [level.id, level.world_id, level.proof_display, userId])

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60)
    const sec = s % 60
    return `${m}:${sec.toString().padStart(2, '0')}`
  }

  return (
    <div className="level-player">
      {/* Header */}
      <div className="lp-header">
        <div>
          <span className="lp-level-num bmuco-arcade-kicker">Level {level.level_number}</span>
          <h2 className="lp-title">{level.title}</h2>
        </div>
        {state === 'playing' && (
          <div className="lp-timer">{formatTime(elapsed)}</div>
        )}
      </div>

      {/* Syntax check bar — shared between idle/playing */}
      {(state === 'idle' || state === 'playing') && (
        <div className="lp-syntax-bar bmuco-arcade-hud">
          {checkState === 'idle' && (
            <button type="button" onClick={handleSyntaxCheck} className="lp-syntax-btn bmuco-arcade-hud-btn">
              RUN SYNTAX CHECK
            </button>
          )}
          {checkState === 'checking' && (
            <span className="lp-syntax-badge lp-syntax-checking">Checking...</span>
          )}
          {checkState === 'pass' && (
            <span className="lp-syntax-badge lp-syntax-pass" title="This proof type-checks. That doesn't mean it's good.">
              {checkMsg || 'Syntax OK ✓'}
            </span>
          )}
          {checkState === 'fail' && (
            <>
              <span className="lp-syntax-badge lp-syntax-fail" title={checkMsg}>
                {checkMsg || 'Syntax Error'}
              </span>
              {syntaxErrors.length > 0 && (
                <div className="lp-syntax-errors">
                  <button type="button" className="lp-syntax-errors-toggle" onClick={() => setSyntaxExpanded(v => !v)}>
                    {syntaxExpanded ? 'Hide errors' : `Show errors (${syntaxErrors.length})`}
                  </button>
                  {syntaxExpanded && (
                    <div className="lp-syntax-errors-box">
                      {syntaxErrors.map((message, idx) => (
                        <div key={`${idx}-${message}`} className="lp-syntax-error-line">
                          {message}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </>
          )}
          {checkState === 'error' && (
            <span className="lp-syntax-badge lp-syntax-fail" title={checkMsg}>
              {checkMsg || 'Check unavailable'}
            </span>
          )}
        </div>
      )}

      {/* Idle state — start button */}
      {state === 'idle' && (
        <div className="lp-idle">
          <ProofDisplay
            code={level.proof_display}
            informalStatement={level.informal_statement || undefined}
            isBoss={isBoss}
          />
          <div className="lp-start-area">
            <p className="lp-instructions">
              Read the proof above carefully. When you're ready, start the review to see the checklist.
            </p>
            <button onClick={handleStart} className="btn btn-primary lp-start-btn">
              Start Review
            </button>
          </div>
        </div>
      )}

      {/* Playing state — proof + checklist */}
      {state === 'playing' && (
        <div className="lp-playing">
          <ProofDisplay
            code={level.proof_display}
            informalStatement={level.informal_statement || undefined}
            isBoss={isBoss}
          />

          <div className="lp-checklist-section">
            <h3 className="lp-section-label">
              What issues can you spot? Select all that apply.
            </h3>
            <IssueChecklist
              items={checklist}
              selected={selected}
              onToggle={handleToggle}
              confidences={confidences}
              onConfidenceChange={handleConfidenceChange}
            />
            <button
              onClick={handleSubmit}
              className="btn btn-primary lp-submit-btn"
              disabled={selected.size === 0}
            >
              Submit Review ({selected.size} selected)
            </button>
          </div>
        </div>
      )}

      {/* Submitted state — score card */}
      {state === 'submitted' && score && (
        <ScoreCard
          score={score}
          issues={level.issues}
          onTryAgain={handleTryAgain}
          onNextLevel={onNextLevel}
          nextLevelLabel={nextLevelLabel}
          simplifyLeanSource={
            level.proof_display.includes('import ')
              ? level.proof_display
              : `import Mathlib\n${level.proof_display}`
          }
          shareWorldId={level.world_id}
          shareLevelNumber={level.level_number}
          shareChallengerName={challengerDisplayName}
        />
      )}

      <style jsx>{`
        .level-player {
          display: flex;
          flex-direction: column;
          gap: 24px;
          max-width: 720px;
          margin: 0 auto;
        }
        .lp-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
        }
        .lp-level-num {
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--color-primary);
        }
        .lp-title {
          font-family: var(--font-heading);
          font-size: 24px;
          font-weight: 700;
          color: var(--color-text);
          margin: 4px 0 0;
        }
        .lp-timer {
          font-family: var(--font-mono);
          font-size: 18px;
          color: var(--color-text-muted);
          padding: 6px 14px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
        }
        .lp-idle, .lp-playing {
          display: flex;
          flex-direction: column;
          gap: 24px;
        }
        .lp-start-area {
          text-align: center;
        }
        .lp-instructions {
          font-size: 14px;
          color: var(--color-text-secondary);
          margin-bottom: 16px;
        }
        .lp-start-btn {
          min-width: 200px;
        }
        .lp-section-label {
          font-weight: 600;
          font-size: 14px;
          color: var(--color-text-secondary);
          margin-bottom: 12px;
        }
        .lp-checklist-section {
          display: flex;
          flex-direction: column;
        }
        .lp-submit-btn {
          margin-top: 16px;
          align-self: center;
          min-width: 240px;
        }
        .lp-submit-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .lp-syntax-bar {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .lp-syntax-btn {
          background: none;
          border: 1px solid var(--color-border);
          border-radius: var(--radius-sm);
          padding: 5px 12px;
          font-size: 12px;
          font-weight: 500;
          color: var(--color-text-secondary);
          cursor: pointer;
          transition: all 150ms;
        }
        .lp-syntax-btn:hover {
          border-color: var(--color-primary);
          color: var(--color-primary);
        }
        .lp-syntax-badge {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          font-size: 12px;
          font-weight: 600;
          padding: 4px 10px;
          border-radius: var(--radius-sm);
          cursor: default;
        }
        .lp-syntax-checking {
          color: var(--color-text-muted);
          background: var(--color-surface);
          border: 1px solid var(--color-border);
        }
        .lp-syntax-pass {
          color: var(--color-primary);
          background: var(--bmuco-green-soft);
          border: 1px solid var(--bmuco-green-border);
        }
        .lp-syntax-fail {
          color: #d9534f;
          background: rgba(217, 83, 79, 0.08);
          border: 1px solid rgba(217, 83, 79, 0.3);
        }
        .lp-syntax-errors {
          width: 100%;
        }
        .lp-syntax-errors-toggle {
          margin-top: 4px;
          background: none;
          border: 1px solid var(--color-border);
          border-radius: var(--radius-sm);
          padding: 4px 10px;
          font-size: 11px;
          cursor: pointer;
          color: var(--color-text-secondary);
        }
        .lp-syntax-errors-box {
          margin-top: 8px;
          border: 1px solid rgba(217, 83, 79, 0.22);
          background: rgba(217, 83, 79, 0.06);
          border-radius: var(--radius-sm);
          padding: 8px 10px;
          max-height: 140px;
          overflow: auto;
        }
        .lp-syntax-error-line {
          font-family: var(--font-mono);
          font-size: 11px;
          color: #d9534f;
          white-space: pre-wrap;
        }
      `}</style>
    </div>
  )
}
