'use client'

import { useRouter } from 'next/navigation'
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useProgress } from '@/components/ProgressProvider'
import { flush, log } from '@/lib/logger'
import { emitPacket, withProofPacketDefaults } from '@/lib/proof-packets'
import { showTraceAchievements } from '@/components/game/AchievementToast'
import { getOrCreateStudioSessionId } from '@/lib/studio-session-id'
import { getW1Level, type RichTraceStep } from '@/lib/world1-data'

const TRACE_STEPS = [
  {
    id: 'step_1',
    step_number: 1,
    total_steps: 3,
    tactic: 'induction n with',
    goal_before: '⊢ 0 + n = n',
    goal_after: ['| zero ⊢ 0 + 0 = 0', '| succ k ih ⊢ 0 + Nat.succ k = Nat.succ k'],
    context: 'theorem zero_add (n : ℕ) : 0 + n = n',
    annotation_prompt: 'Why is induction on n the right structure for 0 + n = n?',
    explanation_if_skipped:
      'Nat.add recurses on the right argument, so 0 + n unfolds stepwise as n grows. Induction follows that recursion.',
    alternatives: [
      { tactic: 'simp [Nat.zero_add]', why_rejected: 'One-line Mathlib lemma — hides the inductive structure this level teaches' },
      { tactic: 'omega', why_rejected: 'Closes arithmetic goals but does not mirror the recursive definition of +' },
      { tactic: 'ring', why_rejected: 'Not the right tool for Nat.add on the right' },
      { tactic: 'exact?', why_rejected: 'Search would likely find Nat.zero_add — no explicit reasoning' },
    ],
    dimension: 'tactic_selection',
    dataset_label: 'TACTIC_SELECTION — why induction over simp/omega when both work',
  },
  {
    id: 'step_2',
    step_number: 2,
    total_steps: 3,
    tactic: 'rfl',
    goal_before: '⊢ 0 + 0 = 0',
    goal_after: 'goals accomplished ✓',
    context: 'Base case: 0 + 0 = 0. The left branch of Nat.add gives 0 + 0 = 0 by computation.',
    annotation_prompt: 'Why does rfl suffice here (and why is simp [Nat.add_zero] not the intended base)?',
    explanation_if_skipped:
      'Here 0 + 0 reduces to 0 by the defining equations of addition, so rfl closes the goal. Using simp [Nat.add_zero] is a different (valid) path but the spec uses rfl for the base.',
    alternatives: [
      { tactic: 'simp [Nat.add_zero]', why_rejected: 'Valid but the canonical base here is rfl — definitional equality' },
      { tactic: 'simp [Nat.zero_add]', why_rejected: 'That lemma solves the whole theorem in one shot — not the pedagogical path' },
      { tactic: 'omega', why_rejected: 'Overkill for a definitional base case' },
      { tactic: 'norm_num', why_rejected: 'Works on numerals but rfl is minimal' },
    ],
    dimension: 'lemma_retrieval',
    dataset_label: 'LEMMA_RETRIEVAL — base case rfl for zero_add',
  },
  {
    id: 'step_3',
    step_number: 3,
    total_steps: 3,
    tactic: 'simp [Nat.succ_add, ih]',
    goal_before: '⊢ 0 + Nat.succ k = Nat.succ k',
    goal_after: 'goals accomplished ✓',
    context: 'Inductive step. ih : 0 + k = k.',
    annotation_prompt: 'How do Nat.succ_add and ih combine in one simp?',
    explanation_if_skipped:
      'Nat.succ_add rewrites 0 + succ k; ih rewrites 0 + k = k. Together they close the goal.',
    alternatives: [
      { tactic: 'rw [Nat.succ_add, ih]', why_rejected: 'Equivalent structured proof — simp [Nat.succ_add, ih] is the compact form' },
      { tactic: 'omega', why_rejected: 'Closes but hides the use of ih and succ_add' },
      { tactic: 'simp [ih]', why_rejected: 'May need Nat.succ_add explicitly in scope depending on simp configuration' },
      { tactic: 'exact?', why_rejected: 'Search obscures the explicit inductive step' },
    ],
    dimension: 'lemma_retrieval',
    dataset_label: 'LEMMA_RETRIEVAL — inductive step simp [Nat.succ_add, ih]',
  },
]

const XP_ANNOTATION_GOOD = 4
const XP_ANNOTATION_GREAT = 8
const XP_ANNOTATION_EXCELLENT = 12
const XP_PER_REJECTION = 2
const XP_ALL_REJECTED_BONUS = 4
const XP_HINT_PENALTY = 10
const ANNOTATION_GOOD_LEN = 20
const ANNOTATION_GREAT_LEN = 60
const ANNOTATION_EXCELLENT_LEN = 120

function scoreAnnotation(text: string): { xp: number; tier: string; color: string } {
  const len = text.trim().length
  if (len >= ANNOTATION_EXCELLENT_LEN) return { xp: XP_ANNOTATION_EXCELLENT, tier: 'EXCELLENT', color: '#3b82f6' }
  if (len >= ANNOTATION_GREAT_LEN) return { xp: XP_ANNOTATION_GREAT, tier: 'GREAT', color: '#e8af34' }
  if (len >= ANNOTATION_GOOD_LEN) return { xp: XP_ANNOTATION_GOOD, tier: 'GOOD', color: '#94a3b8' }
  return { xp: 0, tier: 'TOO SHORT', color: '#b91c1c' }
}

function scoreRejections(rejectedCount: number, totalAlts: number): { xp: number } {
  const base = rejectedCount * XP_PER_REJECTION
  const bonus = rejectedCount === totalAlts ? XP_ALL_REJECTED_BONUS : 0
  return { xp: base + bonus }
}

interface HintState {
  loading: boolean
  goalState: string | null
  visible: boolean
  confirmPending: boolean
}

export default function TraceMode({
  levelId,
  bindExitSave,
}: {
  levelId: string
  bindExitSave?: (fn: (() => Promise<void>) | null) => void
}) {
  const { mutate: refreshProgress } = useProgress()
  const router = useRouter()
  const [stepIndex, setStepIndex] = useState(0)
  const [annotations, setAnnotations] = useState<Record<string, string>>({})
  const [rejected, setRejected] = useState<Record<string, string[]>>({})
  const [showComplete, setShowComplete] = useState(false)
  const [stepXpFlash, setStepXpFlash] = useState<number | null>(null)
  const [stepScores, setStepScores] = useState<Record<string, { annotation: number; rejections: number }>>({})
  const [stepTimers, setStepTimers] = useState<Record<string, number>>({})
  const [hintsUsed, setHintsUsed] = useState(0)
  const [hintState, setHintState] = useState<HintState>({
    loading: false,
    goalState: null,
    visible: false,
    confirmPending: false,
  })
  const stepStartRef = useRef(Date.now())
  const sessionRef = useRef('')

  useLayoutEffect(() => {
    sessionRef.current = getOrCreateStudioSessionId()
  }, [])

  const level = useMemo(() => getW1Level(levelId), [levelId])
  const activeTraceSteps: RichTraceStep[] = useMemo(
    () => level?.richTraceSteps ?? TRACE_STEPS,
    [level]
  )
  const step = activeTraceSteps[stepIndex]

  useEffect(() => {
    stepStartRef.current = Date.now()
    setHintState({ loading: false, goalState: null, visible: false, confirmPending: false })
  }, [stepIndex])

  const totalXp = useMemo(() => {
    const earned = Object.values(stepScores).reduce((sum, s) => sum + s.annotation + s.rejections, 0)
    return Math.max(0, earned - hintsUsed * XP_HINT_PENALTY)
  }, [stepScores, hintsUsed])

  const maxPossibleXp = activeTraceSteps.length * (XP_ANNOTATION_EXCELLENT + (4 * XP_PER_REJECTION) + XP_ALL_REJECTED_BONUS)

  const currentAnnotation = step ? (annotations[step.id] || '') : ''
  const currentRejected = step ? (rejected[step.id] || []) : []
  const annotationScore = scoreAnnotation(currentAnnotation)
  const rejectionScore = step ? scoreRejections(currentRejected.length, step.alternatives.length) : { xp: 0 }
  const currentStepXp = annotationScore.xp + rejectionScore.xp

  const rejectedRef = useRef(rejected)
  rejectedRef.current = rejected

  const toggleRejected = useCallback(
    (stepId: string, tactic: string) => {
      const prev = rejectedRef.current
      const current = prev[stepId] || []
      const exists = current.includes(tactic)
      const newList = exists ? current.filter(item => item !== tactic) : [...current, tactic]
      const next = { ...prev, [stepId]: newList }
      const st = activeTraceSteps.find(x => x.id === stepId)
      if (st) {
        const alt = st.alternatives.find(a => a.tactic === tactic)
        emitPacket(
          withProofPacketDefaults({
            session_id: sessionRef.current,
            user_id: null,
            level_id: levelId,
            world_id: 1,
            mode: 'trace',
            proof_state_before: st.goal_before,
            tactic_chosen: exists ? `trace_unreject:${tactic}` : `trace_reject:${tactic}`,
            proof_state_after: null,
            tactic_success: !exists,
            tactics_rejected: exists
              ? []
              : [{ tactic, reason: alt?.why_rejected ?? '', was_attempted: true }],
            step_number: st.step_number,
            total_steps: st.total_steps,
            dimension: st.dimension,
            dataset_label: 'trace_alternative_select',
          })
        )
      }
      rejectedRef.current = next
      setRejected(next)
    },
    [activeTraceSteps, levelId]
  )

  const requestHint = useCallback(async () => {
    if (!step) return
    setHintState(prev => ({ ...prev, confirmPending: false, loading: true }))
    setHintsUsed(prev => prev + 1)

    log({
      level_id: levelId,
      mode: 'trace',
      step_id: step.id,
      event: 'hint_used',
      value: { step_number: step.step_number, xp_penalty: XP_HINT_PENALTY },
      duration_ms: 0,
      confidence: null,
      annotation: null,
    })

    emitPacket(
      withProofPacketDefaults({
        session_id: sessionRef.current,
        user_id: null,
        level_id: levelId,
        world_id: 1,
        mode: 'trace',
        proof_state_before: step.goal_before,
        tactic_chosen: 'trace_hint_requested',
        proof_state_after: null,
        tactic_success: false,
        hints_used_this_step: 1,
        step_number: step.step_number,
        total_steps: step.total_steps,
        dimension: step.dimension,
        dataset_label: 'trace_hint_request',
      })
    )

    try {
      const partialProof = activeTraceSteps.slice(0, stepIndex + 1)
        .map(s => `  ${s.tactic}`)
        .join('\n')
      const content = `${step.context} := by\n${partialProof}`

      const res = await fetch('/api/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content }),
      })
      const data = await res.json()
      const goalState = data.goal_state || (Array.isArray(step.goal_after)
        ? step.goal_after.join('\n')
        : step.goal_after)

      setHintState({
        loading: false,
        goalState,
        visible: true,
        confirmPending: false,
      })
    } catch {
      const fallback = Array.isArray(step.goal_after) ? step.goal_after.join('\n') : step.goal_after
      setHintState({
        loading: false,
        goalState: fallback,
        visible: true,
        confirmPending: false,
      })
    }
  }, [step, stepIndex, levelId])

  const buildAlternativesRejectedPacket = useCallback(() => {
    const packets: Array<{ tactic: string; why_rejected: string; step: string }> = []
    for (const s of activeTraceSteps) {
      const rejectedForStep = rejected[s.id] || []
      for (const tactic of rejectedForStep) {
        const alt = s.alternatives.find(a => a.tactic === tactic)
        packets.push({
          tactic,
          why_rejected: alt?.why_rejected ?? '',
          step: s.id,
        })
      }
    }
    return packets
  }, [rejected, activeTraceSteps])

  const goNext = async () => {
    if (!step) return
    const note = currentAnnotation.trim()
    const rejectedForStep = currentRejected
    const elapsed = Date.now() - stepStartRef.current

    setStepTimers(prev => ({ ...prev, [step.id]: elapsed }))
    setStepScores(prev => ({
      ...prev,
      [step.id]: { annotation: annotationScore.xp, rejections: rejectionScore.xp },
    }))

    setStepXpFlash(currentStepXp)
    setTimeout(() => setStepXpFlash(null), 1200)

    const goalAfterStr = Array.isArray(step.goal_after)
      ? step.goal_after.join('\n')
      : step.goal_after
    const tacticsRejectedPacket = rejectedForStep.map(tactic => {
      const alt = step.alternatives.find(a => a.tactic === tactic)
      return {
        tactic,
        reason: alt?.why_rejected ?? '',
        was_attempted: true,
      }
    })

    emitPacket(
      withProofPacketDefaults({
        session_id: sessionRef.current,
        user_id: null,
        level_id: levelId,
        world_id: 1,
        mode: 'trace',
        proof_state_before: step.goal_before,
        tactic_chosen: step.tactic,
        proof_state_after: goalAfterStr,
        tactic_success: true,
        tactics_rejected: tacticsRejectedPacket,
        user_reasoning: note || null,
        time_to_decision_ms: elapsed,
        hints_used_this_step: hintState.visible ? 1 : 0,
        hint_content: hintState.visible
          ? hintState.goalState ?? step.explanation_if_skipped
          : null,
        expert_explanation: step.explanation_if_skipped,
        step_number: step.step_number,
        total_steps: step.total_steps,
        dimension: step.dimension,
        dataset_label: step.dataset_label,
      })
    )

    log({
      level_id: levelId,
      mode: 'trace',
      step_id: step.id,
      event: 'trace_step_completed',
      value: {
        step_id: step.id,
        step_number: step.step_number,
        annotation: note,
        rejected_alternatives: rejectedForStep.map(tactic => {
          const alt = step.alternatives.find(a => a.tactic === tactic)
          return { tactic, why_rejected: alt?.why_rejected ?? '', step: step.id }
        }),
        annotation_xp: annotationScore.xp,
        rejection_xp: rejectionScore.xp,
        step_xp: currentStepXp,
        duration_ms: elapsed,
        hint_used: hintState.visible,
      },
      duration_ms: elapsed,
      confidence: null,
      annotation: note || null,
    })

    if (stepIndex >= activeTraceSteps.length - 1) {
      const rawXp = Object.values({ ...stepScores, [step.id]: { annotation: annotationScore.xp, rejections: rejectionScore.xp } })
        .reduce((sum, s) => sum + s.annotation + s.rejections, 0)
      const finalTotalXp = Math.max(0, rawXp - hintsUsed * XP_HINT_PENALTY)
      const alternativesRejected = buildAlternativesRejectedPacket()

      log({
        level_id: levelId,
        mode: 'trace',
        step_id: 'trace-complete',
        event: 'level_submitted',
        value: {
          mode: 'trace',
          completed_steps: activeTraceSteps.length,
          total_xp: finalTotalXp,
          max_xp: maxPossibleXp,
          hints_used: hintsUsed,
          alternatives_rejected: alternativesRejected,
        },
        duration_ms: 0,
        confidence: null,
        annotation: null,
      })

      await persistTraceData(finalTotalXp, alternativesRejected)
      await flush(levelId)
      setShowComplete(true)
      return
    }

    setStepIndex(prev => Math.min(activeTraceSteps.length - 1, prev + 1))
  }

  const persistTraceData = useCallback(async (
    finalXp: number,
    alternativesRejected: Array<{ tactic: string; why_rejected: string; step: string }>
  ) => {
    const reasoningText = activeTraceSteps.map(s => {
      const ann = annotations[s.id]?.trim()
      return ann ? `[${s.id}] ${s.tactic}: ${ann}` : null
    }).filter(Boolean).join('\n')

    try {
      const res = await fetch('/studio/api/traces', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id: sessionRef.current,
          level_id: levelId,
          world_id: 1,
          level_number: level?.number ?? null,
          hints_used: hintsUsed,
          alternatives_rejected: alternativesRejected,
          reasoning_text: reasoningText,
          annotations,
          issues_identified: [],
          issues_missed: [],
          false_positives: [],
          stars_earned: 0,
          points_earned: finalXp,
        }),
      })
      if (res.ok) refreshProgress()
      const data = (await res.json().catch(() => ({}))) as { achievements?: unknown }
      const raw = data?.achievements
      if (Array.isArray(raw) && raw.length > 0) {
        const cleaned = raw.filter(
          (x): x is { id: string; title: string; description: string } =>
            x != null &&
            typeof x === 'object' &&
            typeof (x as { id?: string }).id === 'string' &&
            typeof (x as { title?: string }).title === 'string' &&
            typeof (x as { description?: string }).description === 'string'
        )
        if (cleaned.length) showTraceAchievements(cleaned)
      }
    } catch (err) {
      console.error('[TraceMode] Failed to persist trace data:', err)
    }
  }, [annotations, hintsUsed, levelId, level?.number, activeTraceSteps, refreshProgress])

  const saveTracePartialExit = useCallback(async () => {
    const alternativesRejected = buildAlternativesRejectedPacket()
    const reasoningText = activeTraceSteps
      .map(s => {
        const ann = annotations[s.id]?.trim()
        return ann ? `[${s.id}] ${s.tactic}: ${ann}` : null
      })
      .filter(Boolean)
      .join('\n')

    log({
      level_id: levelId,
      mode: 'trace',
      step_id: 'partial-exit',
      event: 'trace_partial_exit',
      value: {
        is_partial: true,
        step_index: stepIndex,
        hints_used: hintsUsed,
        alternatives_rejected: alternativesRejected,
      },
      duration_ms: 0,
      confidence: null,
      annotation: null,
    })

    emitPacket(
      withProofPacketDefaults({
        session_id: sessionRef.current,
        user_id: null,
        level_id: levelId,
        world_id: 1,
        mode: 'trace',
        proof_state_before: reasoningText.slice(0, 6000) || `partial_exit_step_${stepIndex + 1}`,
        tactic_chosen: 'trace_partial_exit',
        proof_state_after: null,
        tactic_success: false,
        step_number: stepIndex + 1,
        total_steps: activeTraceSteps.length,
        dimension: 'navigation',
        dataset_label: 'trace_partial_exit',
      })
    )

    try {
      await fetch('/studio/api/traces', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id: sessionRef.current,
          level_id: levelId,
          world_id: 1,
          level_number: level?.number ?? null,
          hints_used: hintsUsed,
          alternatives_rejected: alternativesRejected,
          reasoning_text: reasoningText,
          annotations,
          is_partial: true,
          issues_identified: [],
          issues_missed: [],
          false_positives: [],
          stars_earned: 0,
          points_earned: 0,
        }),
      })
    } catch {
      /* non-fatal */
    }
    await flush(levelId, { keepalive: true })
  }, [
    activeTraceSteps,
    annotations,
    buildAlternativesRejectedPacket,
    hintsUsed,
    level?.number,
    levelId,
    stepIndex,
  ])

  useEffect(() => {
    if (!bindExitSave) return
    bindExitSave(() => saveTracePartialExit())
    return () => bindExitSave(null)
  }, [bindExitSave, saveTracePartialExit])

  const goPrevious = () => {
    setStepIndex(prev => Math.max(0, prev - 1))
  }

  if (showComplete) {
    const rawXp = Object.values(stepScores).reduce((sum, s) => sum + s.annotation + s.rejections, 0)
    const finalXp = Math.max(0, rawXp - hintsUsed * XP_HINT_PENALTY)
    const pct = Math.round((finalXp / maxPossibleXp) * 100)
    const stars = pct >= 90 ? 3 : pct >= 60 ? 2 : pct >= 30 ? 1 : 0
    const grade = pct >= 90 ? 'S' : pct >= 75 ? 'A' : pct >= 60 ? 'B' : pct >= 40 ? 'C' : 'D'
    const gradeColor = pct >= 90 ? '#3b82f6' : pct >= 75 ? '#e8af34' : pct >= 60 ? '#94a3b8' : '#b91c1c'

    return (
      <div style={{ maxWidth: 680, margin: '0 auto', padding: '32px 24px' }}>
        <div
          style={{
            borderRadius: 12,
            overflow: 'hidden',
            border: '2px solid rgba(59,130,246,0.4)',
            boxShadow: '0 12px 40px rgba(59,130,246,0.15)',
          }}
        >
          <div
            style={{
              background: 'linear-gradient(135deg, #0d1220 0%, #161e2e 100%)',
              padding: '32px 24px',
              textAlign: 'center',
              color: '#fff',
            }}
          >
            <div style={{ fontSize: 11, letterSpacing: '0.2em', textTransform: 'uppercase', color: '#3b82f6', marginBottom: 12 }}>
              AUDIT COMPLETE
            </div>
            <div style={{ fontSize: 72, fontWeight: 900, color: gradeColor, lineHeight: 1, marginBottom: 8 }}>
              {grade}
            </div>
            <div style={{ fontSize: 48, letterSpacing: 8, marginBottom: 12 }}>
              {[1, 2, 3].map(i => (
                <span key={i} style={{ color: i <= stars ? '#e8af34' : 'rgba(255,255,255,0.15)', filter: i <= stars ? 'drop-shadow(0 0 6px rgba(232,175,52,0.4))' : 'none' }}>
                  ★
                </span>
              ))}
            </div>
            <div style={{ fontSize: 28, fontWeight: 800, color: '#e8af34' }}>
              +{finalXp} pts
            </div>
            <div style={{ fontSize: 13, color: '#64748b', marginTop: 4 }}>
              out of {maxPossibleXp} possible
              {hintsUsed > 0 && (
                <span style={{ color: '#ef4444', marginLeft: 8 }}>
                  ({hintsUsed} hint{hintsUsed > 1 ? 's' : ''} used: −{hintsUsed * XP_HINT_PENALTY} pts)
                </span>
              )}
            </div>
          </div>

          <div style={{ background: 'var(--color-surface)', padding: '20px 24px' }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 12, color: 'var(--color-text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
              Step Breakdown
            </h3>
            <div style={{ display: 'grid', gap: 8 }}>
              {activeTraceSteps.map(s => {
                const sc = stepScores[s.id] || { annotation: 0, rejections: 0 }
                const stepTotal = sc.annotation + sc.rejections
                const stepMax = XP_ANNOTATION_EXCELLENT + (4 * XP_PER_REJECTION) + XP_ALL_REJECTED_BONUS
                const timer = stepTimers[s.id]
                return (
                  <div
                    key={s.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '10px 12px',
                      borderRadius: 8,
                      background: 'var(--color-surface-raised)',
                      border: '1px solid var(--color-border)',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span style={{
                        width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: 12, fontWeight: 700,
                        background: stepTotal >= stepMax * 0.8 ? 'rgba(74,222,128,0.15)' : 'var(--color-surface-hover)',
                        color: stepTotal >= stepMax * 0.8 ? '#3b82f6' : 'var(--color-text-muted)',
                        border: `1px solid ${stepTotal >= stepMax * 0.8 ? 'rgba(59,130,246,0.3)' : 'var(--color-border)'}`,
                      }}>
                        {s.step_number}
                      </span>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 600 }}>{s.tactic}</div>
                        <div style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>
                          {timer ? `${(timer / 1000).toFixed(0)}s` : '--'}
                          {' · '}
                          Annotation {sc.annotation > 0 ? `+${sc.annotation}` : '0'}
                          {' · '}
                          Rejections {sc.rejections > 0 ? `+${sc.rejections}` : '0'}
                        </div>
                      </div>
                    </div>
                    <span style={{ fontSize: 14, fontWeight: 700, color: stepTotal > 0 ? '#e8af34' : 'var(--color-text-muted)' }}>
                      +{stepTotal}
                    </span>
                  </div>
                )
              })}
            </div>

            <div style={{ marginTop: 20, display: 'flex', gap: 12, justifyContent: 'center' }}>
              <button
                type="button"
                className="btn btn-primary"
                style={{ minWidth: 180, padding: '12px 32px', fontSize: 15 }}
                onClick={() => router.push('?mode=review', { scroll: false })}
              >
                Continue to Review →
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!step) return null

  const annotationLen = currentAnnotation.trim().length
  const annotationPct = Math.min(100, (annotationLen / ANNOTATION_EXCELLENT_LEN) * 100)

  return (
    <div className="trace-mode-root" style={{ maxWidth: 960, margin: '0 auto' }}>
      {/* Header bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div>
          <div style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: '#3b82f6', fontWeight: 700 }}>
            EXPERT AUDITOR
          </div>
          <h2 style={{ fontSize: 22, fontWeight: 800, margin: '4px 0 0' }}>
            Step {step.step_number} of {step.total_steps}
          </h2>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          {stepXpFlash !== null && (
            <span
              style={{
                fontSize: 16,
                fontWeight: 800,
                color: '#3b82f6',
                animation: 'fadeIn 0.3s ease',
              }}
            >
              +{stepXpFlash}
            </span>
          )}
          <div style={{
            background: 'rgba(232,175,52,0.1)',
            border: '1px solid rgba(232,175,52,0.3)',
            borderRadius: 999,
            padding: '6px 16px',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}>
            <span style={{ fontSize: 13, fontWeight: 700, color: '#e8af34' }}>
              {totalXp} pts
            </span>
            {hintsUsed > 0 && (
              <span style={{ fontSize: 11, color: '#ef4444' }}>
                (−{hintsUsed * XP_HINT_PENALTY})
              </span>
            )}
          </div>
          <div style={{
            fontSize: 12,
            color: 'var(--color-text-muted)',
            textAlign: 'right',
          }}>
            This step: <span style={{ fontWeight: 700, color: annotationScore.color }}>+{currentStepXp}</span>
          </div>
        </div>
      </div>

      {/* Progress with step dots */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 20 }}>
        {activeTraceSteps.map((s, i) => {
          const done = i < stepIndex
          const active = i === stepIndex
          const sc = stepScores[s.id]
          const stepMax = XP_ANNOTATION_EXCELLENT + (4 * XP_PER_REJECTION) + XP_ALL_REJECTED_BONUS
          const quality = sc ? (sc.annotation + sc.rejections) / stepMax : 0
          return (
            <div key={s.id} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
              <div style={{
                height: 6,
                width: '100%',
                borderRadius: 999,
                background: done
                  ? quality >= 0.8 ? '#3b82f6' : quality >= 0.4 ? '#e8af34' : '#94a3b8'
                  : active ? 'linear-gradient(90deg, #3b82f6 0%, #3b82f6 100%)' : '#e9ecef',
                transition: 'background 300ms ease',
                boxShadow: active ? '0 0 8px rgba(59,130,246,0.3)' : 'none',
              }} />
            </div>
          )
        })}
      </div>

      {/* Main content: two-column desktop, single column mobile */}
      <div className="trace-main-grid">
        {/* Left: Proof state */}
        <div className="trace-col-left">
          {/* Tactic card */}
          <div style={{
            borderRadius: 10,
            overflow: 'hidden',
            border: '2px solid rgba(59,130,246,0.35)',
            boxShadow: '0 4px 16px rgba(59,130,246,0.08)',
          }}>
            <div style={{
              background: 'linear-gradient(180deg, #161e2e 0%, #0d1220 100%)',
              padding: '14px 16px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
              <span style={{ color: '#3b82f6', fontSize: 11, letterSpacing: '0.15em', fontWeight: 700, textTransform: 'uppercase' }}>
                TACTIC APPLIED
              </span>
              <span style={{
                fontSize: 11, padding: '3px 8px', borderRadius: 4,
                background: 'rgba(74,222,128,0.15)', border: '1px solid rgba(59,130,246,0.3)',
                color: '#3b82f6', fontWeight: 600, letterSpacing: '0.08em',
              }}>
                {step.dimension.toUpperCase().replace('_', ' ')}
              </span>
            </div>
            <div style={{ background: '#0d1220', padding: '16px' }}>
              <code style={{ fontSize: 18, fontWeight: 700, color: '#e2e8f0' }}>
                {step.tactic}
              </code>
            </div>
          </div>

          {/* Goal before/after */}
          <div style={{ borderRadius: 10, border: '1px solid var(--color-border)', overflow: 'hidden' }}>
            <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--color-border)', display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#b91c1c' }} />
              <span style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--color-text-muted)' }}>
                GOAL BEFORE
              </span>
            </div>
            <pre style={{ margin: 0, background: '#1a1a1a', color: '#e8e8e8', padding: 14, fontSize: 13, lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
{step.goal_before}
            </pre>
          </div>

          <div style={{ borderRadius: 10, border: '1px solid var(--color-border)', overflow: 'hidden' }}>
            <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--color-border)', display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#3b82f6' }} />
              <span style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--color-text-muted)' }}>
                GOAL AFTER
              </span>
            </div>
            <pre style={{ margin: 0, background: '#1a1a1a', color: '#e8e8e8', padding: 14, fontSize: 13, lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
{Array.isArray(step.goal_after) ? step.goal_after.join('\n') : step.goal_after}
            </pre>
          </div>

          {/* Context */}
          <div style={{
            fontSize: 13, color: 'var(--color-text-secondary)', padding: '12px 14px',
            background: 'var(--color-surface)', borderRadius: 8, border: '1px solid var(--color-border)',
          }}>
            <span style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>
              Context
            </span>
            <div style={{ marginTop: 6 }}>{step.context}</div>
          </div>
        </div>

        {/* Right: Challenge */}
        <div className="trace-col-right">
          {/* Annotation challenge */}
          <div style={{
            borderRadius: 10, border: '1px solid var(--color-border)',
            background: 'var(--color-surface)', padding: '16px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <span style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--color-text-muted)' }}>
                Your Reasoning
              </span>
              <span style={{ fontSize: 11, fontWeight: 700, color: annotationScore.color, padding: '2px 8px', borderRadius: 4, background: `${annotationScore.color}15`, border: `1px solid ${annotationScore.color}30` }}>
                {annotationLen > 0 ? annotationScore.tier : 'WAITING'} +{annotationScore.xp} pts
              </span>
            </div>
            <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--color-text)', margin: '0 0 10px', lineHeight: 1.5 }}>
              {step.annotation_prompt}
            </p>
            <textarea
              value={currentAnnotation}
              onChange={e => setAnnotations(prev => ({ ...prev, [step.id]: e.target.value }))}
              placeholder="Explain your reasoning..."
              style={{
                width: '100%',
                minHeight: 100,
                borderRadius: 8,
                border: `1px solid ${annotationLen >= ANNOTATION_EXCELLENT_LEN ? 'rgba(74,222,128,0.4)' : 'var(--color-border)'}`,
                padding: '10px 12px',
                fontSize: 13,
                lineHeight: 1.6,
                resize: 'vertical',
                transition: 'border-color 200ms ease',
              }}
            />
            {/* Quality bar */}
            <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ flex: 1, height: 4, borderRadius: 999, background: '#e9ecef', overflow: 'hidden' }}>
                <div style={{
                  height: '100%',
                  width: `${annotationPct}%`,
                  borderRadius: 999,
                  background: annotationLen >= ANNOTATION_EXCELLENT_LEN ? '#3b82f6' : annotationLen >= ANNOTATION_GREAT_LEN ? '#e8af34' : annotationLen >= ANNOTATION_GOOD_LEN ? '#94a3b8' : '#ddd',
                  transition: 'width 150ms ease, background 200ms ease',
                }} />
              </div>
              <span style={{ fontSize: 11, color: 'var(--color-text-muted)', whiteSpace: 'nowrap' }}>
                {annotationLen} chars
              </span>
            </div>
          </div>

          {/* Elimination zone */}
          <div style={{
            borderRadius: 10, border: '1px solid var(--color-border)',
            background: 'var(--color-surface)', padding: '16px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <span style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--color-text-muted)' }}>
                Eliminate Wrong Tactics
              </span>
              <span style={{ fontSize: 11, fontWeight: 700, color: currentRejected.length === step.alternatives.length ? '#3b82f6' : '#e8af34', padding: '2px 8px', borderRadius: 4, background: currentRejected.length === step.alternatives.length ? 'rgba(59,130,246,0.1)' : 'rgba(232,175,52,0.08)', border: `1px solid ${currentRejected.length === step.alternatives.length ? 'rgba(59,130,246,0.3)' : 'rgba(232,175,52,0.2)'}` }}>
                {currentRejected.length}/{step.alternatives.length} +{rejectionScore.xp} pts
              </span>
            </div>
            <div className="trace-alt-grid">
              {step.alternatives.map(alt => {
                const isRejected = currentRejected.includes(alt.tactic)
                return (
                  <button
                    key={`${step.id}_${alt.tactic}`}
                    type="button"
                    onClick={() => toggleRejected(step.id, alt.tactic)}
                    style={{
                      borderRadius: 8,
                      padding: '10px 12px',
                      textAlign: 'left',
                      cursor: 'pointer',
                      transition: 'all 200ms ease',
                      border: isRejected ? '1px solid rgba(185,28,28,0.3)' : '1px solid var(--color-border)',
                      background: isRejected ? 'rgba(185,28,28,0.04)' : 'transparent',
                      opacity: isRejected ? 0.55 : 1,
                    }}
                  >
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 8,
                      marginBottom: 4,
                    }}>
                      <span style={{
                        width: 20, height: 20, borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: 12, fontWeight: 700,
                        background: isRejected ? 'rgba(185,28,28,0.12)' : 'var(--color-surface-hover)',
                        color: isRejected ? '#b91c1c' : 'var(--color-text-muted)',
                        border: `1px solid ${isRejected ? 'rgba(185,28,28,0.3)' : 'var(--color-border)'}`,
                        flexShrink: 0,
                      }}>
                        {isRejected ? '✗' : '?'}
                      </span>
                      <code style={{
                        fontSize: 13,
                        fontWeight: 600,
                        textDecoration: isRejected ? 'line-through' : 'none',
                        color: isRejected ? 'var(--color-text-muted)' : 'var(--color-text)',
                      }}>
                        {alt.tactic}
                      </code>
                    </div>
                    {isRejected && (
                      <div style={{ fontSize: 12, color: 'var(--color-text-muted)', marginLeft: 28, lineHeight: 1.4 }}>
                        {alt.why_rejected}
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
          </div>

          {/* Hint button with confirm gate */}
          {!hintState.visible && !hintState.confirmPending && (
            <button
              type="button"
              onClick={() => setHintState(prev => ({ ...prev, confirmPending: true }))}
              style={{
                borderRadius: 10,
                border: '1px solid rgba(232,175,52,0.25)',
                background: 'rgba(232,175,52,0.04)',
                padding: '12px 14px',
                cursor: 'pointer',
                fontSize: 12,
                fontWeight: 600,
                color: '#e8af34',
                letterSpacing: '0.06em',
                textAlign: 'left',
              }}
            >
              Need a hint? (−{XP_HINT_PENALTY} pts)
            </button>
          )}

          {hintState.confirmPending && (
            <div style={{
              borderRadius: 10,
              border: '1px solid rgba(239, 68, 68, 0.25)',
              background: 'rgba(239, 68, 68, 0.04)',
              padding: '14px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
              <span style={{ fontSize: 13, color: 'var(--color-text)' }}>
                Use hint? This costs <strong style={{ color: '#ef4444' }}>−{XP_HINT_PENALTY} pts</strong>
              </span>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  type="button"
                  onClick={() => setHintState(prev => ({ ...prev, confirmPending: false }))}
                  className="btn btn-secondary"
                  style={{ padding: '6px 14px', fontSize: 12 }}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={requestHint}
                  style={{
                    padding: '6px 14px',
                    fontSize: 12,
                    fontWeight: 700,
                    borderRadius: 6,
                    border: '1px solid rgba(239, 68, 68, 0.3)',
                    background: 'rgba(239, 68, 68, 0.08)',
                    color: '#ef4444',
                    cursor: 'pointer',
                  }}
                >
                  Confirm (−{XP_HINT_PENALTY} pts)
                </button>
              </div>
            </div>
          )}

          {hintState.loading && (
            <div style={{
              borderRadius: 10,
              border: '1px solid rgba(59,130,246,0.25)',
              background: 'rgba(59,130,246,0.04)',
              padding: '14px',
              fontSize: 13,
              color: 'var(--color-text-muted)',
              textAlign: 'center',
            }}>
              Checking proof state with AXLE...
            </div>
          )}

          {hintState.visible && hintState.goalState && (
            <div style={{
              borderRadius: 10,
              border: '1px solid rgba(59,130,246,0.3)',
              overflow: 'hidden',
            }}>
              <div style={{
                padding: '10px 14px',
                background: 'rgba(59,130,246,0.06)',
                borderBottom: '1px solid rgba(59,130,246,0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
                <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#3b82f6' }}>
                  GOAL STATE (HINT)
                </span>
                <span style={{ fontSize: 11, color: '#ef4444', fontWeight: 600 }}>−{XP_HINT_PENALTY} pts</span>
              </div>
              <pre style={{
                margin: 0,
                background: '#0d1220',
                color: '#e2e8f0',
                padding: 14,
                fontSize: 13,
                lineHeight: 1.6,
                whiteSpace: 'pre-wrap',
                fontFamily: 'var(--font-mono)',
              }}>
{hintState.goalState}
              </pre>
              <div style={{
                padding: '10px 14px',
                background: 'rgba(232,175,52,0.04)',
                borderTop: '1px solid rgba(59,130,246,0.15)',
                fontSize: 12,
                color: 'var(--color-text-muted)',
                lineHeight: 1.5,
              }}>
                {step.explanation_if_skipped}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Navigation — sticky bottom bar on mobile */}
      <div className="trace-step-nav">
        <button
          type="button"
          className="btn btn-secondary trace-nav-prev"
          onClick={goPrevious}
          disabled={stepIndex === 0}
          style={{ opacity: stepIndex === 0 ? 0.4 : 1 }}
        >
          ← Previous
        </button>
        <div className="trace-step-nav-hint" style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>
          {annotationLen < ANNOTATION_GOOD_LEN && (
            <span>Write at least {ANNOTATION_GOOD_LEN - annotationLen} more chars for points</span>
          )}
        </div>
        <button
          type="button"
          className="btn btn-primary"
          style={{ minWidth: 140, padding: '10px 24px' }}
          onClick={goNext}
        >
          {stepIndex >= activeTraceSteps.length - 1 ? 'Finish Audit' : 'Lock In →'}
        </button>
      </div>
    </div>
  )
}
