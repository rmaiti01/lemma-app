'use client'

interface StarRatingProps {
  stars: number
  maxStars?: number
  size?: 'sm' | 'md' | 'lg'
  animate?: boolean
}

const sizes = { sm: 16, md: 24, lg: 36 }

export default function StarRating({
  stars,
  maxStars = 3,
  size = 'md',
  animate = false,
}: StarRatingProps) {
  const px = sizes[size]

  return (
    <span className="star-rating" style={{ display: 'inline-flex', gap: size === 'lg' ? 6 : 3 }}>
      {Array.from({ length: maxStars }, (_, i) => {
        const filled = i < stars
        return (
          <svg
            key={i}
            width={px}
            height={px}
            viewBox="0 0 24 24"
            fill={filled ? '#3b82f6' : 'none'}
            stroke={filled ? '#3b82f6' : '#c0c0bc'}
            strokeWidth={filled ? 0 : 1.5}
            strokeLinecap="round"
            strokeLinejoin="round"
            className={animate && filled ? 'star-bounce' : undefined}
            style={
              animate && filled
                ? { animationDelay: `${i * 300}ms`, opacity: 0 }
                : undefined
            }
          >
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
          </svg>
        )
      })}

      <style jsx>{`
        @keyframes star-pop {
          0% { opacity: 0; transform: scale(0); }
          60% { opacity: 1; transform: scale(1.3); }
          100% { opacity: 1; transform: scale(1); }
        }
        .star-bounce {
          animation: star-pop 400ms ease-out forwards;
        }
      `}</style>
    </span>
  )
}
