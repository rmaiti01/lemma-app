'use client'

import { useRouter } from 'next/navigation'
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { flush, log } from '@/lib/logger'
import { emitPacket, withProofPacketDefaults } from '@/lib/proof-packets'
import { getOrCreateStudioSessionId } from '@/lib/studio-session-id'
import type { W1Level } from '@/lib/world1-data'

type MCQQuestion = {
  id: string
  question: string
  options: string[]
  correctIndex: number
  correctExplanation: string
  wrongExplanations: Partial<Record<number, string>>
}

interface MCQModeProps {
  level: W1Level
  onComplete?: () => void
  /** Register async save before navigating away (Exit / tab close uses event log flush separately) */
  bindExitSave?: (fn: (() => Promise<void>) | null) => void
}

function getQuestions(level: W1Level): MCQQuestion[] {
  if (level.id === 'w1_l1') {
    return [
      {
        id: 'q1',
        question: 'Which single tactic closes the base case goal `0 + 0 = 0`?',
        options: ['rfl', 'simp [Nat.add_zero]', 'simp [Nat.zero_add]', 'omega'],
        correctIndex: 0,
        correctExplanation:
          'rfl closes the base case: 0 + 0 is definitionally 0 under Nat.add.',
        wrongExplanations: {
          1: 'simp [Nat.add_zero] is about n + 0, not the 0 + n base — rfl is the intended minimal base.',
          2: 'simp [Nat.zero_add] would solve the whole theorem in one shot — not the structured proof.',
          3: 'omega is unnecessary for this definitional equality.',
        },
      },
      {
        id: 'q2',
        question: 'Which tactic closes the inductive step `0 + Nat.succ k = Nat.succ k` using ih : 0 + k = k?',
        options: ['simp [Nat.succ_add, ih]', 'exact ih', 'ring', 'rfl'],
        correctIndex: 0,
        correctExplanation:
          'simp [Nat.succ_add, ih] unfolds the successor case and applies the induction hypothesis.',
        wrongExplanations: {
          1: 'exact ih does not match the goal until succ_add has been applied to expose 0 + k.',
          2: 'ring is not the right tool for this Nat.add structure.',
          3: 'rfl fails — the goal is not reflexive without succ_add and ih.',
        },
      },
    ]
  }

  return [
    {
      id: 'q1',
      question: `Which tactic is most appropriate to progress ${level.theorem}?`,
      options: ['simp', 'ring', 'omega', 'by_cases h'],
      correctIndex: 0,
      correctExplanation: 'Nice pick — simp is the most direct first step for this goal.',
      wrongExplanations: {
        1: 'That tactic is too heavy for this local goal state.',
        2: 'This choice is usually for arithmetic side-conditions, not this core step.',
        3: 'Case splits are useful later, but not as the first move here.',
      },
    },
  ]
}

export default function MCQMode({ level, onComplete, bindExitSave }: MCQModeProps) {
  const router = useRouter()
  const sessionRef = useRef('')

  useLayoutEffect(() => {
    sessionRef.current = getOrCreateStudioSessionId()
  }, [])

  useEffect(() => {
    if (!bindExitSave) return
    bindExitSave(async () => {
      log({
        level_id: level.id,
        mode: 'mcq',
        step_id: 'partial-exit',
        event: 'mcq_partial_exit',
        value: { partial: true },
        duration_ms: 0,
        confidence: null,
        annotation: null,
      })
      await flush(level.id)
    })
    return () => bindExitSave(null)
  }, [bindExitSave, level.id])
  const questions = useMemo(() => getQuestions(level), [level])
  const [questionIndex, setQuestionIndex] = useState(0)
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null)
  const [status, setStatus] = useState<'idle' | 'correct' | 'wrong'>('idle')
  const [attemptsThisQuestion, setAttemptsThisQuestion] = useState(0)
  const [results, setResults] = useState<Array<{ correct: boolean; retries: number } | null>>(
    Array(questions.length).fill(null)
  )
  const [showCompletion, setShowCompletion] = useState(false)
  const [xpCount, setXpCount] = useState(0)

  const current = questions[questionIndex]
  const completedCount = results.filter(Boolean).length
  const progressPercent = Math.round((completedCount / questions.length) * 100)
  const totalRetries = results.reduce((sum, item) => sum + (item?.retries ?? 0), 0)
  const correctCount = results.reduce((sum, item) => sum + (item?.correct ? 1 : 0), 0)

  useEffect(() => {
    if (!showCompletion) return
    let n = 0
    const t = window.setInterval(() => {
      n += 1
      setXpCount(Math.min(10, n))
      if (n >= 10) window.clearInterval(t)
    }, 45)
    return () => window.clearInterval(t)
  }, [showCompletion])

  const submitOption = (optionIndex: number) => {
    if (!current || status !== 'idle') return
    setSelectedIndex(optionIndex)
    const correct = optionIndex === current.correctIndex

    log({
      level_id: level.id,
      mode: 'mcq',
      step_id: current.id,
      event: 'mcq_answered',
      value: {
        question_id: current.id,
        selected: current.options[optionIndex],
        correct,
        options_shown: current.options,
      },
      duration_ms: 0,
      confidence: null,
      annotation: null,
    })

    const optionLines = current.options
      .map((o, i) => `${String.fromCharCode(65 + i)}) ${o}`)
      .join('\n')
    const proofStateBefore = [level.informalProof.statement || level.theorem, current.question, optionLines]
      .filter(Boolean)
      .join('\n\n')
    const tacticsRejected = current.options
      .map((tactic, i) =>
        i === optionIndex
          ? null
          : {
              tactic,
              reason: current.wrongExplanations[i] ?? 'not selected',
              was_attempted: false,
            }
      )
      .filter(
        (x): x is { tactic: string; reason: string; was_attempted: boolean } => x != null
      )

    emitPacket(
      withProofPacketDefaults({
        session_id: sessionRef.current,
        user_id: null,
        level_id: level.id,
        world_id: 1,
        mode: 'mcq',
        proof_state_before: proofStateBefore,
        tactic_chosen: current.options[optionIndex],
        proof_state_after: null,
        tactic_success: correct,
        tactics_rejected: tacticsRejected,
        step_number: questionIndex + 1,
        total_steps: questions.length,
        dimension: 'tactic_selection',
        dataset_label: 'mcq_tactic_recognition',
      })
    )

    if (!correct) {
      setStatus('wrong')
      setAttemptsThisQuestion(prev => prev + 1)
      return
    }

    setStatus('correct')
  }

  const advance = () => {
    if (!current) return
    const correct = status === 'correct'
    const retries = correct ? attemptsThisQuestion : Math.max(2, attemptsThisQuestion)

    const nextResults = [...results]
    nextResults[questionIndex] = { correct, retries }
    setResults(nextResults)

    const nextIndex = questionIndex + 1
    if (nextIndex >= questions.length) {
      const finalScore = nextResults.reduce((sum, item) => sum + (item?.correct ? 1 : 0), 0)
      emitPacket(
        withProofPacketDefaults({
          session_id: sessionRef.current,
          user_id: null,
          level_id: level.id,
          world_id: 1,
          mode: 'mcq',
          proof_state_before: `mcq_complete:${level.id} correct=${finalScore}/${questions.length}`,
          tactic_chosen: 'mcq_session_complete',
          proof_state_after: null,
          tactic_success: finalScore === questions.length,
          step_number: questions.length,
          total_steps: questions.length,
          dimension: 'navigation',
          dataset_label: 'mcq_session_complete',
        })
      )
      log({
        level_id: level.id,
        mode: 'mcq',
        step_id: 'mcq-complete',
        event: 'level_submitted',
        value: { mode: 'mcq', level_id: level.id, score: finalScore },
        duration_ms: 0,
        confidence: null,
        annotation: null,
      })
      flush(level.id).catch(() => {})
      onComplete?.()
      setShowCompletion(true)
      return
    }

    emitPacket(
      withProofPacketDefaults({
        session_id: sessionRef.current,
        user_id: null,
        level_id: level.id,
        world_id: 1,
        mode: 'mcq',
        proof_state_before: `${current.id} → Q${nextIndex + 1}`,
        tactic_chosen: 'mcq_step_advance',
        proof_state_after: null,
        tactic_success: correct,
        step_number: nextIndex,
        total_steps: questions.length,
        dimension: 'navigation',
        dataset_label: 'mcq_step_advance',
      })
    )

    setQuestionIndex(nextIndex)
    setSelectedIndex(null)
    setStatus('idle')
    setAttemptsThisQuestion(0)
  }

  const resetTryAgain = () => {
    setSelectedIndex(null)
    setStatus('idle')
  }

  if (showCompletion) {
    const retryLabel = totalRetries === 1 ? '1 retry' : `${totalRetries} retries`
    const passedAll = correctCount === questions.length
    return (
      <div style={{ maxWidth: 760, margin: '0 auto', padding: '24px' }}>
        <div
          style={{
            border: '1px solid rgba(59,130,246,0.35)',
            borderRadius: 'var(--radius-lg)',
            background: 'var(--color-surface)',
            padding: '26px 22px',
            textAlign: 'center',
          }}
        >
          <h2 style={{ margin: '0 0 10px', fontSize: 34 }}>🎉 MCQ Complete!</h2>
          <p style={{ margin: '0 0 10px', color: 'var(--color-text-secondary)' }}>
            {correctCount}/{questions.length} correct
            {totalRetries > 0 ? ` (${retryLabel})` : ''}
          </p>
          <p style={{ margin: '0 0 18px', color: '#e8af34', fontWeight: 700 }}>
            +{xpCount} XP
          </p>
          {passedAll ? (
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => {
                onComplete?.()
                router.push('?mode=build', { scroll: false })
              }}
            >
              Continue →
            </button>
          ) : (
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => {
                setQuestionIndex(0)
                setSelectedIndex(null)
                setStatus('idle')
                setAttemptsThisQuestion(0)
                setResults(Array(questions.length).fill(null))
                setShowCompletion(false)
                setXpCount(0)
              }}
            >
              Try Again
            </button>
          )}
        </div>
      </div>
    )
  }

  return (
    <div style={{ maxWidth: 760, margin: '0 auto', padding: '24px' }}>
      <div
        style={{
          border: '1px solid var(--color-border)',
          borderRadius: 'var(--radius-lg)',
          background: 'var(--color-surface)',
          padding: '20px',
        }}
      >
        <div style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 6 }}>
            <span>Q{Math.min(questionIndex + 1, questions.length)} / {questions.length}</span>
            <span>{progressPercent}%</span>
          </div>
          <div style={{ height: 8, borderRadius: 999, background: 'var(--color-surface-raised)', overflow: 'hidden' }}>
            <div
              style={{
                height: '100%',
                width: `${progressPercent}%`,
                background: 'linear-gradient(90deg, #3b82f6 0%, #3b82f6 100%)',
                transition: 'width 220ms ease',
              }}
            />
          </div>
        </div>

        <p style={{ fontSize: 12, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--color-primary)' }}>
          MCQ · TACTIC RECOGNITION
        </p>
        <h2 style={{ marginTop: 6, marginBottom: 6 }}>{level.informalProof.statement || level.theorem}</h2>
        <p style={{ marginBottom: 14 }}>Question {Math.min(questionIndex + 1, questions.length)} of {questions.length}</p>

        {current && (
          <>
            <div style={{ marginBottom: 16, color: 'var(--color-text)' }}>{current.question}</div>
            <div style={{ display: 'grid', gap: 10 }}>
              {current.options.map((option, optionIndex) => {
                const isSelected = selectedIndex === optionIndex
                const isCorrectChoice = status === 'correct' && isSelected
                const isWrongChoice = status === 'wrong' && isSelected
                return (
                  <button
                    key={option}
                    type="button"
                    onClick={() => submitOption(optionIndex)}
                    disabled={status !== 'idle'}
                    style={{
                      textAlign: 'left',
                      padding: '10px 12px',
                      borderRadius: 'var(--radius-md)',
                      border: `2px solid ${
                        isCorrectChoice
                          ? '#10b981'
                          : isWrongChoice
                          ? '#ef4444'
                          : isSelected
                          ? '#3b82f6'
                          : 'var(--color-border)'
                      }`,
                      background: isCorrectChoice
                        ? 'rgba(16,185,129,0.14)'
                        : isWrongChoice
                        ? 'rgba(239,68,68,0.12)'
                        : isSelected
                        ? 'rgba(59,130,246,0.09)'
                        : 'var(--color-surface)',
                      color: 'var(--color-text)',
                      cursor: status === 'idle' ? 'pointer' : 'default',
                      transition: 'border-color 160ms ease, background 160ms ease',
                    }}
                  >
                    {String.fromCharCode(65 + optionIndex)}) {option}{' '}
                    {isCorrectChoice ? '✓' : isWrongChoice ? '✗' : ''}
                  </button>
                )
              })}
            </div>

            {status === 'correct' && selectedIndex !== null && (
              <div
                style={{
                  marginTop: 14,
                  border: '1px solid rgba(16,185,129,0.45)',
                  background: 'rgba(16,185,129,0.12)',
                  borderRadius: 'var(--radius-md)',
                  padding: '10px 12px',
                }}
              >
                <p style={{ margin: 0, color: '#10b981', fontWeight: 700 }}>
                  ✓ {current.correctExplanation}
                </p>
                <button type="button" className="btn btn-primary" style={{ marginTop: 10 }} onClick={advance}>
                  Next →
                </button>
              </div>
            )}

            {status === 'wrong' && selectedIndex !== null && (
              <div
                style={{
                  marginTop: 14,
                  border: '1px solid rgba(239,68,68,0.4)',
                  background: 'rgba(239,68,68,0.10)',
                  borderRadius: 'var(--radius-md)',
                  padding: '10px 12px',
                }}
              >
                <p style={{ margin: 0, color: '#991b1b', fontWeight: 700 }}>
                  ✗ {current.wrongExplanations[selectedIndex] || 'Not this one. Try the tactic that directly matches the goal state.'}
                </p>
                <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
                  {attemptsThisQuestion >= 2 ? (
                    <button type="button" className="btn btn-primary" onClick={advance}>
                      Next →
                    </button>
                  ) : (
                    <button type="button" className="btn btn-secondary" onClick={resetTryAgain}>
                      Try again
                    </button>
                  )}
                </div>
                {attemptsThisQuestion >= 2 && (
                  <p style={{ margin: '8px 0 0', fontSize: 12, color: 'var(--color-text-muted)' }}>
                    Progress continues after 2 tries for demo flow.
                  </p>
                )}
              </div>
            )}
          </>
        )}

        {!current && (
          <div style={{ marginTop: 14 }}>
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => router.push('?mode=build', { scroll: false })}
            >
              Try Build Mode → (+25 XP)
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
