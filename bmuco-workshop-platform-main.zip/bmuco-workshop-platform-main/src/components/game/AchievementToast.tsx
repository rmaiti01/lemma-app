'use client'

import toast from 'react-hot-toast'
import { Trophy } from 'lucide-react'
import type { TraceAchievementPayload } from '@/lib/trace-achievements'

export type { TraceAchievementPayload }

function AchievementBody({ item }: { item: TraceAchievementPayload }) {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: 12,
        padding: '4px 4px 4px 0',
        minWidth: 260,
        maxWidth: 360,
      }}
    >
      <div
        style={{
          flexShrink: 0,
          width: 40,
          height: 40,
          borderRadius: 10,
          background: 'linear-gradient(145deg, rgba(59,130,246,0.25), rgba(168,85,247,0.2))',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          border: '1px solid rgba(59,130,246,0.35)',
        }}
      >
        <Trophy size={22} color="#93c5fd" aria-hidden />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 700, fontSize: 15, letterSpacing: '-0.02em', marginBottom: 4 }}>
          {item.title}
        </div>
        <div style={{ fontSize: 13, color: '#8b949e', lineHeight: 1.45 }}>{item.description}</div>
      </div>
    </div>
  )
}

/** Queue dark-theme achievement toasts (react-hot-toast). */
export function showTraceAchievements(items: TraceAchievementPayload[]) {
  if (!items.length) return
  items.forEach((item, i) => {
    window.setTimeout(() => {
      toast.custom(
        t => (
          <div
            style={{
              opacity: t.visible ? 1 : 0,
              transform: t.visible ? 'translateY(0)' : 'translateY(-8px)',
              transition: 'opacity 180ms ease, transform 180ms ease',
              background: '#161b22',
              color: '#e6edf3',
              border: '1px solid #30363d',
              borderRadius: 12,
              padding: '14px 16px',
              boxShadow: '0 12px 40px rgba(0,0,0,0.45)',
            }}
          >
            <AchievementBody item={item} />
          </div>
        ),
        { id: item.id, duration: 4500 }
      )
    }, i * 350)
  })
}
