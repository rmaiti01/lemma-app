'use client'

import type { ChecklistItem } from '@/lib/game-types'

interface IssueChecklistProps {
  items: ChecklistItem[]
  selected: Set<string>
  onToggle: (id: string) => void
  confidences: Record<string, number>
  onConfidenceChange: (id: string, value: number) => void
  disabled?: boolean
}

const confidenceLabels = ['Wild guess', 'Unsure', 'Somewhat sure', 'Confident', 'Certain']

export default function IssueChecklist({
  items,
  selected,
  onToggle,
  confidences,
  onConfidenceChange,
  disabled,
}: IssueChecklistProps) {
  return (
    <div className="issue-checklist">
      {items.map(item => {
        const active = selected.has(item.id)
        const confidence = confidences[item.id] ?? 3
        return (
          <div key={item.id} className={`issue-card-wrapper ${active ? 'active' : ''}`}>
            <button
              type="button"
              className={`issue-card ${active ? 'active' : ''} ${disabled ? 'disabled' : ''}`}
              onClick={() => !disabled && onToggle(item.id)}
              disabled={disabled}
            >
              <span className="issue-indicator">{active ? '✓' : ''}</span>
              <span className="issue-label">{item.label}</span>
            </button>
            {active && !disabled && (
              <div className="confidence-row">
                <span className="confidence-label">Confidence:</span>
                <div className="confidence-dots">
                  {[1, 2, 3, 4, 5].map(val => (
                    <button
                      key={val}
                      type="button"
                      className={`confidence-dot ${val <= confidence ? 'filled' : ''}`}
                      onClick={() => onConfidenceChange(item.id, val)}
                      title={confidenceLabels[val - 1]}
                    />
                  ))}
                </div>
                <span className="confidence-text">{confidenceLabels[confidence - 1]}</span>
              </div>
            )}
          </div>
        )
      })}

      <style jsx>{`
        .issue-checklist {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .issue-card-wrapper {
          border-radius: var(--radius-md);
          overflow: hidden;
        }
        .issue-card-wrapper.active {
          border: 1.5px solid #3b82f6;
          background: rgba(59, 130, 246, 0.04);
        }
        .issue-card {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 16px;
          width: 100%;
          background: transparent;
          border: 1.5px solid var(--color-border);
          border-radius: var(--radius-md);
          color: var(--color-text);
          font-size: 14px;
          line-height: 1.4;
          text-align: left;
          cursor: pointer;
          transition: all 150ms ease;
        }
        .issue-card-wrapper.active .issue-card {
          border-color: transparent;
          border-radius: var(--radius-md) var(--radius-md) 0 0;
        }
        .issue-card:hover:not(.disabled) {
          border-color: #3b82f6;
          background: var(--color-surface-hover);
        }
        .issue-card.active {
          border-color: transparent;
        }
        .issue-card.disabled {
          cursor: default;
          opacity: 0.6;
        }
        .issue-indicator {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 22px;
          height: 22px;
          border-radius: 6px;
          border: 1.5px solid var(--color-border-light);
          font-size: 13px;
          font-weight: 700;
          color: #3b82f6;
          flex-shrink: 0;
          transition: all 150ms ease;
        }
        .issue-card.active .issue-indicator {
          border-color: #3b82f6;
          background: rgba(59, 130, 246, 0.15);
        }
        .issue-label {
          flex: 1;
        }
        .confidence-row {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 8px 16px 12px;
        }
        .confidence-label {
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: var(--color-text-muted);
          flex-shrink: 0;
        }
        .confidence-dots {
          display: flex;
          gap: 4px;
        }
        .confidence-dot {
          width: 14px;
          height: 14px;
          border-radius: 50%;
          border: 1.5px solid var(--color-border-light);
          background: transparent;
          cursor: pointer;
          transition: all 150ms;
          padding: 0;
        }
        .confidence-dot.filled {
          background: #3b82f6;
          border-color: #3b82f6;
        }
        .confidence-dot:hover {
          border-color: #3b82f6;
        }
        .confidence-text {
          font-size: 11px;
          color: var(--color-text-muted);
          min-width: 80px;
        }
      `}</style>
    </div>
  )
}
