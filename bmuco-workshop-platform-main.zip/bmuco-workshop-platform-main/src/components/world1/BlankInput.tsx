'use client'

export { default } from '@/components/game/BlankInput'
