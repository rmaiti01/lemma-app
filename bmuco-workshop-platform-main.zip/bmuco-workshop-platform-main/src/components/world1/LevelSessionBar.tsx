'use client'

import Link from 'next/link'

interface LevelSessionBarProps {
  worldId: string
  levelId: string
  /** e.g. "WORLD 1 — NATURAL NUMBERS" */
  worldLabel: string
  onExit: () => void | Promise<void>
  exiting?: boolean
}

export default function LevelSessionBar({
  worldId,
  levelId,
  worldLabel,
  onExit,
  exiting,
}: LevelSessionBarProps) {
  const worldHref = `/studio/world/${worldId}`
  const levelPickerHref = `/studio/worlds/${worldId}/levels/${levelId}`

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        flexWrap: 'wrap',
        padding: '10px 0 14px',
        borderBottom: '1px solid var(--color-border)',
        marginBottom: 16,
      }}
    >
      <button
        type="button"
        onClick={() => void onExit()}
        disabled={exiting}
        className="btn btn-secondary"
        style={{
          fontSize: 13,
          padding: '6px 12px',
          opacity: exiting ? 0.7 : 1,
          cursor: exiting ? 'wait' : 'pointer',
        }}
      >
        ← Exit
      </button>
      <div
        style={{
          fontSize: 13,
          color: 'var(--color-text-secondary)',
          display: 'flex',
          alignItems: 'center',
          gap: 6,
          flexWrap: 'wrap',
        }}
      >
        <Link
          href="/"
          style={{ fontWeight: 700, color: 'var(--color-primary)', textDecoration: 'none' }}
        >
          LEMMA
        </Link>
        <span aria-hidden="true" style={{ color: 'var(--color-text-muted)' }}>
          ›
        </span>
        <Link href={worldHref} style={{ color: 'var(--color-text)', textDecoration: 'none', fontWeight: 600 }}>
          {worldLabel}
        </Link>
        <span aria-hidden="true" style={{ color: 'var(--color-text-muted)' }}>
          ›
        </span>
        <Link
          href={levelPickerHref}
          style={{ color: 'var(--color-text-muted)', textDecoration: 'none', fontSize: 12 }}
        >
          Level select
        </Link>
      </div>
    </div>
  )
}
