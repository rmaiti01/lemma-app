'use client'

import { useState, useEffect } from 'react'
import type { W1Level } from '@/lib/world1-data'
import type { W1ScoreBreakdown } from '@/lib/world1-scoring'

interface ScoreScreenProps {
  level: W1Level
  score: W1ScoreBreakdown
  finalLeanAccepted: boolean | null
  verdict: 'works' | 'broken' | 'unsure' | null
  onNextLevel?: () => void
  onRetry?: () => void
}

export default function ScoreScreen({
  level,
  score,
  finalLeanAccepted,
  verdict,
  onNextLevel,
  onRetry,
}: ScoreScreenProps) {
  const [animatedScore, setAnimatedScore] = useState(0)

  useEffect(() => {
    const target = score.score
    if (target === 0) return
    const duration = 1500
    const start = performance.now()
    const tick = (now: number) => {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setAnimatedScore(Math.round(eased * target))
      if (progress < 1) requestAnimationFrame(tick)
    }
    requestAnimationFrame(tick)
  }, [score.score])

  const correctVerdict = level.type === 'A' ? 'works' : 'broken'
  const verdictCorrect = verdict === correctVerdict
  const isLastLevel = level.number === 8

  return (
    <div
      style={{
        maxWidth: 520,
        margin: '0 auto',
        padding: '48px 24px',
        textAlign: 'center',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 24,
      }}
    >
      {/* Stars */}
      <div style={{ fontSize: 48, letterSpacing: 8 }}>
        {[1, 2, 3].map(i => (
          <span
            key={i}
            style={{
              color: i <= score.stars ? 'var(--color-warning)' : 'var(--color-border)',
              filter: i <= score.stars ? 'drop-shadow(0 0 6px rgba(245, 197, 66, 0.4))' : 'none',
              transition: 'color 300ms, filter 300ms',
              transitionDelay: `${i * 200}ms`,
            }}
          >
            ★
          </span>
        ))}
      </div>

      {/* Score */}
      <div>
        <div
          style={{
            fontSize: 56,
            fontWeight: 800,
            color: 'var(--color-text)',
            fontFamily: 'var(--font-heading)',
          }}
        >
          {animatedScore}
        </div>
        <div style={{ fontSize: 13, color: 'var(--color-text-muted)', marginTop: 4 }}>points</div>
      </div>

      {/* Breakdown table */}
      <div
        style={{
          width: '100%',
          background: 'var(--color-surface)',
          border: '1px solid var(--color-border)',
          borderRadius: 'var(--radius-lg)',
          padding: 16,
          textAlign: 'left',
          boxShadow: 'var(--shadow-sm)',
        }}
      >
        <table style={{ width: '100%', fontSize: 13, borderCollapse: 'collapse' }}>
          <tbody>
            <Row label="Base (correct blanks)" value={`+${score.base}`} color="var(--color-success)" />
            {score.attemptPenalty > 0 && (
              <Row label="Failed attempts" value={`-${score.attemptPenalty}`} color="var(--color-error)" />
            )}
            {score.verdictBonus > 0 && (
              <Row label="Verdict filled" value={`+${score.verdictBonus}`} color="var(--color-success)" />
            )}
            {score.reasoningBonus > 0 && (
              <Row label="All reasoning filled" value={`+${score.reasoningBonus}`} color="var(--color-success)" />
            )}
            {score.correctVerdictBonus > 0 && (
              <Row label="Correct verdict" value={`+${score.correctVerdictBonus}`} color="var(--color-success)" />
            )}
            {score.hintPenalty > 0 && (
              <Row label="Hint tier 3 used" value={`-${score.hintPenalty}`} color="var(--color-error)" />
            )}
          </tbody>
        </table>
      </div>

      {/* Lean verification — keep dark badge style */}
      <div
        style={{
          fontSize: 15,
          fontWeight: 600,
          color: finalLeanAccepted ? 'var(--color-success)' : 'var(--color-error)',
        }}
      >
        {finalLeanAccepted ? '✓ Final proof accepted by Lean' : '✗ Final proof not accepted'}
      </div>

      {/* Verdict result */}
      {verdict && (
        <div style={{ fontSize: 14, color: verdictCorrect ? 'var(--color-success)' : 'var(--color-warning)' }}>
          {level.type === 'B' && verdictCorrect
            ? 'You caught the gap!'
            : level.type === 'A' && verdictCorrect
            ? 'Correct — this proof is valid!'
            : `Your verdict: "${verdict}" (correct answer: "${correctVerdict}")`}
        </div>
      )}

      {/* World complete */}
      {isLastLevel && (
        <div
          style={{
            fontSize: 22,
            fontWeight: 700,
            color: 'var(--color-warning)',
            marginTop: 8,
          }}
        >
          World 1 Complete!
        </div>
      )}

      {/* Actions */}
      <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
        <button
          onClick={onRetry}
          className="btn"
          style={{
            background: 'transparent',
            color: 'var(--color-text-secondary)',
            border: '1px solid var(--color-border)',
            padding: '10px 24px',
            fontSize: 14,
          }}
        >
          Retry
        </button>
        {!isLastLevel && onNextLevel && (
          <button onClick={onNextLevel} className="btn btn-primary" style={{ padding: '10px 24px', fontSize: 14 }}>
            Continue →
          </button>
        )}
      </div>
    </div>
  )
}

function Row({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <tr>
      <td style={{ padding: '4px 0', color: 'var(--color-text-secondary)' }}>{label}</td>
      <td
        style={{
          padding: '4px 0',
          textAlign: 'right',
          color,
          fontWeight: 600,
          fontFamily: 'var(--font-mono)',
        }}
      >
        {value}
      </td>
    </tr>
  )
}
