'use client'

interface TrapDisproveSnapshot {
  loading: boolean
  disproved: boolean | null
  counterexample: string | null
  mock: boolean
  error: string | null
}

interface ThoughtLogPanelProps {
  runningNotes: string
  onNotesChange: (value: string) => void
  verdict: 'works' | 'broken' | 'unsure' | null
  onVerdictChange: (value: 'works' | 'broken' | 'unsure') => void
  verdictReasoning: string
  onVerdictReasoningChange: (value: string) => void
  showVerdict: boolean
  levelType?: 'A' | 'B'
  trapDisprove?: TrapDisproveSnapshot | null
}

const VERDICT_OPTIONS: Array<{ value: 'works' | 'broken' | 'unsure'; label: string }> = [
  { value: 'works', label: 'Yes — valid' },
  { value: 'broken', label: 'No — has a gap' },
  { value: 'unsure', label: 'Unsure' },
]

export default function ThoughtLogPanel({
  runningNotes,
  onNotesChange,
  verdict,
  onVerdictChange,
  verdictReasoning,
  onVerdictReasoningChange,
  showVerdict,
  levelType = 'A',
  trapDisprove = null,
}: ThoughtLogPanelProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20, height: '100%' }}>
      {/* Scratchpad */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <div
          style={{
            fontSize: 11,
            fontWeight: 600,
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
            color: 'var(--color-primary)',
            marginBottom: 8,
          }}
        >
          Running Notes
        </div>
        <textarea
          value={runningNotes}
          onChange={e => onNotesChange(e.target.value)}
          placeholder="Use this as a scratchpad — what are you noticing? What's confusing?"
          rows={8}
          style={{
            flex: 1,
            fontFamily: 'var(--font-body)',
            fontSize: 14,
            background: 'var(--color-surface)',
            color: 'var(--color-text)',
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius-md)',
            padding: '10px 12px',
            resize: 'vertical',
            outline: 'none',
            lineHeight: 1.6,
            transition: 'border-color var(--transition-fast)',
          }}
          className="tlp-textarea"
        />
      </div>

      {/* Verdict */}
      {showVerdict && (
        <div
          style={{
            borderTop: '1px solid var(--color-border)',
            paddingTop: 16,
            display: 'flex',
            flexDirection: 'column',
            gap: 10,
          }}
        >
          <div
            style={{
              fontSize: 11,
              fontWeight: 600,
              textTransform: 'uppercase',
              letterSpacing: '0.08em',
              color: 'var(--color-primary)',
            }}
          >
            Does this informal proof actually work?
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {VERDICT_OPTIONS.map(opt => (
              <label
                key={opt.value}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  cursor: 'pointer',
                  padding: '6px 10px',
                  borderRadius: 'var(--radius-sm)',
                  background:
                    verdict === opt.value ? 'rgba(59, 130, 246, 0.06)' : 'transparent',
                  border: `1px solid ${
                    verdict === opt.value ? 'rgba(59, 130, 246, 0.3)' : 'transparent'
                  }`,
                  transition: 'all var(--transition-fast)',
                }}
              >
                <input
                  type="radio"
                  name="verdict"
                  checked={verdict === opt.value}
                  onChange={() => onVerdictChange(opt.value)}
                  style={{ accentColor: 'var(--color-primary)' }}
                />
                <span style={{ fontSize: 14, color: 'var(--color-text)' }}>{opt.label}</span>
              </label>
            ))}
          </div>

          <textarea
            value={verdictReasoning}
            onChange={e => onVerdictReasoningChange(e.target.value)}
            placeholder="Explain your verdict (optional)"
            rows={3}
            className="tlp-textarea"
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: 13,
              background: 'var(--color-surface)',
              color: 'var(--color-text)',
              border: '1px solid var(--color-border)',
              borderRadius: 'var(--radius-sm)',
              padding: '8px 10px',
              resize: 'vertical',
              outline: 'none',
            }}
          />

          {levelType === 'B' && verdict === 'broken' && trapDisprove && (
            <div
              style={{
                marginTop: 12,
                padding: '10px 12px',
                borderRadius: 'var(--radius-sm)',
                border: '1px solid rgba(59,130,246,0.25)',
                background: 'rgba(59,130,246,0.04)',
              }}
            >
              <div
                style={{
                  fontSize: 11,
                  fontWeight: 600,
                  textTransform: 'uppercase',
                  letterSpacing: '0.06em',
                  color: 'var(--color-primary)',
                  marginBottom: 6,
                }}
              >
                AXLE · disproving the claimed theorem
              </div>
              {trapDisprove.loading && (
                <div style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
                  Searching for a counterexample…
                </div>
              )}
              {trapDisprove.error && (
                <div style={{ fontSize: 13, color: '#ef4444' }}>{trapDisprove.error}</div>
              )}
              {trapDisprove.mock && !trapDisprove.loading && !trapDisprove.error && (
                <div style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
                  AXLE is offline — set <code>AXLE_API_KEY</code> to run real disproof checks on trap
                  levels.
                </div>
              )}
              {!trapDisprove.loading &&
                !trapDisprove.error &&
                !trapDisprove.mock &&
                trapDisprove.disproved === true && (
                  <div style={{ fontSize: 13, color: 'var(--color-text)' }}>
                    <strong style={{ color: '#10b981' }}>Counterexample found.</strong> The stated claim
                    is not provable as written:
                    <pre
                      style={{
                        marginTop: 8,
                        marginBottom: 0,
                        padding: 8,
                        fontSize: 11,
                        lineHeight: 1.5,
                        background: 'var(--color-surface)',
                        border: '1px solid var(--color-border)',
                        borderRadius: 4,
                        whiteSpace: 'pre-wrap',
                        wordBreak: 'break-word',
                        fontFamily: 'var(--font-mono)',
                      }}
                    >
                      {trapDisprove.counterexample ?? '(no details)'}
                    </pre>
                  </div>
                )}
              {!trapDisprove.loading &&
                !trapDisprove.error &&
                !trapDisprove.mock &&
                trapDisprove.disproved === false && (
                  <div style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
                    AXLE could not disprove the main theorem from this file (it may still be true, or
                    disproof needs more time).
                  </div>
                )}
            </div>
          )}
        </div>
      )}

      <style jsx>{`
        .tlp-textarea:focus {
          border-color: var(--color-primary) !important;
          box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.15);
        }
      `}</style>
    </div>
  )
}
