'use client'

import { useState, useMemo, useCallback } from 'react'
import type { LevelState } from '@/hooks/useLevelState'
import InformalProofPanel from './InformalProofPanel'
import LeanSkeletonPanel from './LeanSkeletonPanel'
import ThoughtLogPanel from './ThoughtLogPanel'
import ScoreScreen from './ScoreScreen'

interface LevelLayoutProps {
  state: LevelState
  onNextLevel?: () => void
  onRetry?: () => void
}

type MobileTab = 'proof' | 'lean' | 'notes'

export default function LevelLayout({ state, onNextLevel, onRetry }: LevelLayoutProps) {
  const [highlightedBlank, setHighlightedBlank] = useState<string | null>(null)
  const [mobileTab, setMobileTab] = useState<MobileTab>('proof')

  const allAttempted = useMemo(() => {
    return state.level.blanks.every(b => {
      const s = state.blanks[b.id]
      return s && (s.accepted !== null || s.attempts.length > 0)
    })
  }, [state.level.blanks, state.blanks])

  const handleHighlightHover = useCallback((blankRef: string | null) => {
    setHighlightedBlank(blankRef)
  }, [])

  // Score screen overlay
  if (state.phase === 'complete' && state.score) {
    return (
      <ScoreScreen
        level={state.level}
        score={state.score}
        finalLeanAccepted={state.finalLeanAccepted}
        verdict={state.verdict}
        onNextLevel={onNextLevel}
        onRetry={onRetry}
      />
    )
  }

  // Reading phase
  if (state.phase === 'reading') {
    return (
      <div style={{ maxWidth: 640, margin: '0 auto', textAlign: 'center', padding: '40px 20px' }}>
        <div
          style={{
            fontSize: 11,
            fontWeight: 600,
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
            color: 'var(--color-primary)',
            marginBottom: 8,
          }}
        >
          World 1 · Level {state.level.number}/8
        </div>
        <h2
          style={{
            fontSize: 28,
            fontWeight: 700,
            color: 'var(--color-text)',
            margin: '0 0 8px',
            fontFamily: 'var(--font-heading)',
          }}
        >
          {state.level.theorem}
        </h2>
        <p style={{ color: 'var(--color-text-secondary)', fontSize: 15, marginBottom: 24 }}>
          Read the informal proof carefully. When you&apos;re ready, you&apos;ll fill in the Lean 4 blanks.
        </p>

        {/* Theorem callout — green framed card matching site style */}
        <div
          style={{
            background: 'var(--color-surface)',
            border: '2px solid var(--color-primary)',
            borderRadius: 'var(--radius-lg)',
            overflow: 'hidden',
            marginBottom: 20,
            textAlign: 'left',
          }}
        >
          <div
            style={{
              background: 'var(--color-primary)',
              color: '#fff',
              fontFamily: 'var(--font-heading)',
              fontWeight: 700,
              fontSize: 11,
              textTransform: 'uppercase',
              letterSpacing: '0.1em',
              padding: '6px 16px',
            }}
          >
            Statement
          </div>
          <div style={{ padding: '14px 16px', fontSize: 16, fontWeight: 600, color: 'var(--color-text)' }}>
            {state.level.informalProof.statement}
          </div>
        </div>

        <div
          style={{
            textAlign: 'left',
            background: 'var(--color-surface)',
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius-lg)',
            padding: '16px 20px',
            marginBottom: 32,
            lineHeight: 1.8,
            fontSize: 15,
            color: 'var(--color-text)',
            boxShadow: 'var(--shadow-sm)',
          }}
        >
          {state.level.informalProof.text}
        </div>

        <button
          onClick={state.advanceFromReading}
          className="btn btn-primary"
          style={{ minWidth: 240, padding: '12px 32px', fontSize: 16 }}
        >
          I&apos;m Ready — Start Filling Blanks
        </button>
      </div>
    )
  }

  // Three panels (filling/reflecting)
  const leftPanel = (
    <InformalProofPanel
      informalProof={state.level.informalProof}
      hintsToggleOn={state.hintsToggleOn}
      onToggleHints={state.toggleHintsOverlay}
      onHighlightHover={handleHighlightHover}
    />
  )

  const centrePanel = (
    <LeanSkeletonPanel
      level={state.level}
      blanks={state.blanks}
      onInputChange={state.updateBlankInput}
      onReasoningChange={state.updateBlankReasoning}
      onCheck={state.checkBlank}
      onRevealHint={state.revealHint}
      highlightedBlank={highlightedBlank}
      repairHint={state.repairHint}
      onRepairRequest={state.requestRepair}
      onRepairDismiss={state.clearRepairHint}
    />
  )

  const rightPanel = (
    <ThoughtLogPanel
      runningNotes={state.runningNotes}
      onNotesChange={state.updateRunningNotes}
      verdict={state.verdict}
      onVerdictChange={state.setVerdict}
      verdictReasoning={state.verdictReasoning}
      onVerdictReasoningChange={state.setVerdictReasoning}
      showVerdict={allAttempted}
      levelType={state.level.type}
      trapDisprove={state.trapDisprove}
    />
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Header */}
      <div
        className="ll-build-header"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '12px 20px',
          borderBottom: '1px solid var(--color-border)',
          background: 'var(--color-surface)',
          flexShrink: 0,
        }}
      >
        <div className="ll-build-breadcrumb" style={{ fontSize: 13, color: 'var(--color-text-secondary)' }}>
          World 1 · Level {state.level.number}/8
        </div>
        <div
          className="ll-build-theorem"
          style={{
            fontWeight: 700,
            fontSize: 16,
            color: 'var(--color-text)',
            fontFamily: 'var(--font-heading)',
          }}
        >
          {state.level.theorem}
        </div>
        <div className="ll-build-actions" style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={state.submitLevel}
            disabled={state.submitting}
            className="btn btn-primary ll-build-submit"
            style={{
              padding: '8px 20px',
              fontSize: 13,
              opacity: state.submitting ? 0.6 : 1,
              cursor: state.submitting ? 'wait' : 'pointer',
            }}
          >
            {state.submitting ? 'Verifying...' : 'Submit'}
          </button>
        </div>
      </div>

      {/* AXLE verification in-progress banner */}
      {state.submitting && (
        <div
          style={{
            padding: '12px 20px',
            background: 'rgba(59,130,246,0.08)',
            borderBottom: '1px solid rgba(59,130,246,0.25)',
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            flexShrink: 0,
          }}
        >
          <span className="verify-spinner" />
          <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--color-primary)' }}>
            Verifying proof with AXLE — this can take up to 30 s…
          </span>
        </div>
      )}

      {/* Inline verification feedback */}
      {state.finalLeanAccepted === false && state.verifyErrorMessage && (
        <div
          style={{
            padding: '10px 20px',
            background: 'rgba(239, 68, 68, 0.08)',
            borderBottom: '1px solid rgba(239, 68, 68, 0.25)',
            color: 'var(--color-error, #ef4444)',
            fontSize: 13,
            fontFamily: 'var(--font-mono)',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            flexShrink: 0,
          }}
        >
          <span style={{ fontWeight: 700 }}>✗ Verification failed:</span>
          <span>{state.verifyErrorMessage}</span>
        </div>
      )}
      {state.finalLeanAccepted === true && state.phase !== 'complete' && (
        <div
          style={{
            padding: '10px 20px',
            background: 'rgba(34, 197, 94, 0.08)',
            borderBottom: '1px solid rgba(34, 197, 94, 0.25)',
            color: 'var(--color-success, #22c55e)',
            fontSize: 13,
            fontWeight: 600,
            flexShrink: 0,
          }}
        >
          {state.verifiedByLiveAxle
            ? '✓ Proof verified by AXLE'
            : '✓ Answers match expected tactics (AXLE offline — live check skipped)'}
        </div>
      )}

      {/* Desktop: three panels */}
      <div className="ll-panels" style={{ flex: 1, minHeight: 0 }}>
        <div className="ll-panel ll-left">{leftPanel}</div>
        <div className="ll-panel ll-centre">{centrePanel}</div>
        <div className="ll-panel ll-right">{rightPanel}</div>
      </div>

      {/* Mobile: tab bar + single panel */}
      <div className="ll-mobile-content">
        {mobileTab === 'proof' && leftPanel}
        {mobileTab === 'lean' && centrePanel}
        {mobileTab === 'notes' && rightPanel}
      </div>
      <div className="ll-mobile-tabs">
        {(['proof', 'lean', 'notes'] as MobileTab[]).map(tab => (
          <button
            key={tab}
            onClick={() => setMobileTab(tab)}
            style={{
              flex: 1,
              padding: '10px 0',
              background: mobileTab === tab ? 'var(--color-surface)' : 'transparent',
              color: mobileTab === tab ? 'var(--color-primary)' : 'var(--color-text-muted)',
              border: 'none',
              borderTop: mobileTab === tab ? '2px solid var(--color-primary)' : '2px solid transparent',
              fontSize: 13,
              fontWeight: 600,
              cursor: 'pointer',
              textTransform: 'capitalize',
            }}
          >
            {tab === 'proof' ? 'Proof' : tab === 'lean' ? 'Lean' : 'Notes'}
          </button>
        ))}
      </div>

      <style jsx>{`
        .verify-spinner {
          display: inline-block;
          width: 14px;
          height: 14px;
          border: 2px solid rgba(59, 130, 246, 0.25);
          border-top-color: var(--color-primary);
          border-radius: 50%;
          animation: ll-spin 0.7s linear infinite;
          flex-shrink: 0;
        }
        @keyframes ll-spin {
          to { transform: rotate(360deg); }
        }
        .ll-panels {
          display: flex;
          overflow: hidden;
        }
        .ll-panel {
          flex: 1;
          overflow-y: auto;
          padding: 20px;
        }
        .ll-left {
          background: var(--color-surface);
          border-right: 1px solid var(--color-border);
        }
        .ll-centre {
          background: var(--color-surface-raised);
        }
        .ll-right {
          background: var(--color-surface);
          border-left: 1px solid var(--color-border);
        }
        .ll-mobile-content {
          display: none;
        }
        .ll-mobile-tabs {
          display: none;
        }
        @media (max-width: 1023px) {
          .ll-panels {
            display: none;
          }
          .ll-mobile-content {
            display: block;
            flex: 1;
            overflow-y: auto;
            padding: 16px;
            background: var(--color-bg);
          }
          .ll-mobile-tabs {
            display: flex;
            border-top: 1px solid var(--color-border);
            background: var(--color-surface);
            flex-shrink: 0;
          }
        }
      `}</style>
    </div>
  )
}
