'use client'

import type { InformalProof } from '@/lib/world1-data'

interface InformalProofPanelProps {
  informalProof: InformalProof
  hintsToggleOn: boolean
  onToggleHints: () => void
  onHighlightHover?: (blankRef: string | null) => void
}

export default function InformalProofPanel({
  informalProof,
  hintsToggleOn,
  onToggleHints,
  onHighlightHover,
}: InformalProofPanelProps) {
  const renderText = () => {
    if (!hintsToggleOn) {
      return (
        <p className="build-informal-proof" style={{ margin: 0, lineHeight: 1.8, fontSize: 15, color: 'var(--color-text)' }}>
          {informalProof.text}
        </p>
      )
    }

    let remaining = informalProof.text
    const parts: React.ReactNode[] = []
    let key = 0

    const sorted = [...informalProof.highlightedSentences].sort(
      (a, b) => remaining.indexOf(a.text) - remaining.indexOf(b.text)
    )

    for (const hs of sorted) {
      const idx = remaining.indexOf(hs.text)
      if (idx === -1) continue

      if (idx > 0) {
        parts.push(<span key={key++}>{remaining.slice(0, idx)}</span>)
      }

      parts.push(
        <span
          key={key++}
          onMouseEnter={() => onHighlightHover?.(hs.blankRef)}
          onMouseLeave={() => onHighlightHover?.(null)}
          style={{
            textDecoration: 'underline',
            textDecorationColor: 'var(--color-warning)',
            textDecorationThickness: 2,
            textUnderlineOffset: 3,
            cursor: 'pointer',
            transition: 'background var(--transition-fast)',
            borderRadius: 2,
            padding: '0 2px',
          }}
          className="ipp-highlight"
        >
          {hs.text}
        </span>
      )

      remaining = remaining.slice(idx + hs.text.length)
    }

    if (remaining) {
      parts.push(<span key={key++}>{remaining}</span>)
    }

    return (
      <p className="build-informal-proof" style={{ margin: 0, lineHeight: 1.8, fontSize: 15, color: 'var(--color-text)' }}>
        {parts}
      </p>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, height: '100%' }}>
      {/* Theorem statement callout */}
      <div
        style={{
          background: 'var(--color-surface)',
          border: '2px solid var(--color-primary)',
          borderRadius: 'var(--radius-lg)',
          overflow: 'hidden',
        }}
      >
        <div
          className="build-statement-label"
          style={{
            background: 'var(--color-primary)',
            color: '#fff',
            fontFamily: 'var(--font-heading)',
            fontWeight: 700,
            fontSize: 11,
            textTransform: 'uppercase',
            letterSpacing: '0.1em',
            padding: '6px 16px',
          }}
        >
          Statement
        </div>
        <div
          className="build-statement-body"
          style={{
            padding: '14px 16px',
            fontSize: 16,
            fontWeight: 600,
            color: 'var(--color-text)',
            lineHeight: 1.5,
          }}
        >
          {informalProof.statement}
        </div>
      </div>

      {/* Proof text */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div
          style={{
            fontSize: 11,
            fontWeight: 600,
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
            color: 'var(--color-primary)',
            marginBottom: 8,
          }}
        >
          Informal Proof
        </div>
        {renderText()}
      </div>

      {/* Toggle */}
      <button
        onClick={onToggleHints}
        style={{
          alignSelf: 'flex-start',
          background: hintsToggleOn ? 'rgba(245, 197, 66, 0.08)' : 'transparent',
          border: `1px solid ${hintsToggleOn ? 'rgba(245, 197, 66, 0.4)' : 'var(--color-border)'}`,
          color: hintsToggleOn ? 'var(--color-warning)' : 'var(--color-text-secondary)',
          fontSize: 12,
          fontWeight: 500,
          padding: '5px 12px',
          borderRadius: 'var(--radius-sm)',
          cursor: 'pointer',
          transition: 'all var(--transition-fast)',
        }}
      >
        {hintsToggleOn ? 'Hide' : 'Show'} correspondence hints
      </button>

      <style jsx>{`
        .ipp-highlight:hover {
          background: rgba(245, 197, 66, 0.12);
        }
      `}</style>
    </div>
  )
}
