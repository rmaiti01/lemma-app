'use client'

import type { W1Level } from '@/lib/world1-data'
import type { BlankState } from '@/hooks/useLevelState'
import BlankInput from './BlankInput'

interface LeanSkeletonPanelProps {
  level: W1Level
  blanks: Record<string, BlankState>
  onInputChange: (blankId: string, value: string) => void
  onReasoningChange: (blankId: string, value: string) => void
  onCheck: (blankId: string) => void
  onRevealHint: (blankId: string) => void
  highlightedBlank?: string | null
  repairHint?: { blankId: string; loading: boolean; content: string | null; error: string | null } | null
  onRepairRequest?: (blankId: string) => void
  onRepairDismiss?: () => void
}

export default function LeanSkeletonPanel({
  level,
  blanks,
  onInputChange,
  onReasoningChange,
  onCheck,
  onRevealHint,
  highlightedBlank,
  repairHint,
  onRepairRequest,
  onRepairDismiss,
}: LeanSkeletonPanelProps) {
  const renderSkeleton = () => {
    const parts: React.ReactNode[] = []
    let remaining = level.leanSkeleton
    let key = 0

    for (const blank of level.blanks) {
      const placeholder = `[BLANK_${blank.id.replace('b', '')}]`
      const idx = remaining.indexOf(placeholder)
      if (idx === -1) continue

      if (idx > 0) {
        parts.push(
          <span key={key++} style={{ color: '#c9d1d9' }}>
            {remaining.slice(0, idx)}
          </span>
        )
      }

      const state = blanks[blank.id]
      if (state) {
        parts.push(
          <BlankInput
            key={`blank-${blank.id}`}
            blank={blank}
            state={state}
            onInputChange={v => onInputChange(blank.id, v)}
            onReasoningChange={v => onReasoningChange(blank.id, v)}
            onCheck={() => onCheck(blank.id)}
            onRevealHint={() => onRevealHint(blank.id)}
            pulseHighlight={highlightedBlank === blank.id}
            offerRepair={
              state.attempts.length >= 3 && state.accepted !== true && !state.checking
            }
            onRepairRequest={
              onRepairRequest ? () => onRepairRequest(blank.id) : undefined
            }
            repairLoading={repairHint?.blankId === blank.id && repairHint.loading}
            repairLean={repairHint?.blankId === blank.id ? repairHint.content : null}
            repairError={repairHint?.blankId === blank.id ? repairHint.error : null}
            onRepairDismiss={onRepairDismiss}
          />
        )
      }

      remaining = remaining.slice(idx + placeholder.length)
    }

    if (remaining) {
      parts.push(
        <span key={key++} style={{ color: '#c9d1d9' }}>
          {remaining}
        </span>
      )
    }

    return parts
  }

  return (
    <div
      style={{
        background: '#0d1117',
        borderRadius: 'var(--radius-lg)',
        padding: 20,
        height: '100%',
        overflowY: 'auto',
        fontFamily: 'var(--font-mono)',
        fontSize: 14,
        lineHeight: 1.7,
      }}
    >
      <div
        style={{
          fontSize: 11,
          fontWeight: 600,
          textTransform: 'uppercase',
          letterSpacing: '0.08em',
          color: '#3b82f6',
          marginBottom: 12,
          fontFamily: 'var(--font-heading)',
        }}
      >
        Lean 4 Skeleton
      </div>
      <pre style={{ margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
        {renderSkeleton()}
      </pre>
    </div>
  )
}
