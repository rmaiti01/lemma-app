'use client'

import { useState } from 'react'
import { ChevronRight, ChevronDown, CheckCircle, Circle, AlertTriangle, Eye, EyeOff, Info } from 'lucide-react'
import AxlePanel from './exercise/AxlePanel'

/*
 * InlineExercise — the "Begin Your First Proof" experience.
 * Renders directly on the landing page, no auth required.
 * For the demo, we use the AI review exercise "Sum of two even numbers"
 * because it lets someone with ZERO Lean knowledge spot real issues
 * in AI-generated code by just reading carefully.
 */

const AI_CODE = `-- AI-generated Lean 4 code
theorem even_add_even (m n : ℕ) (hm : ∃ k, m = 2 * k) (hn : ∃ k, n = 2 * k) :
    ∃ k, m + n = 2 * k := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  use a + b
  omega`

const REFERENCE_CODE = `-- Library-quality version (Mathlib standard)
theorem Even.add {m n : ℤ} (hm : Even m) (hn : Even n) : Even (m + n) := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  exact ⟨a + b, by rw [ha, hb]; ring⟩`

const KNOWN_ISSUES = [
  {
    id: 'predicate',
    title: 'Uses raw ∃ instead of Even predicate',
    severity: 'high' as const,
    explanation: 'Mathlib defines `Even n` as `∃ k, n = k + k`. Using a raw existential `∃ k, m = 2 * k` means this proof can\'t interact with any other theorem about `Even` in Mathlib — it\'s isolated from the entire ecosystem.',
  },
  {
    id: 'generality',
    title: 'Hardcoded to ℕ instead of general type',
    severity: 'high' as const,
    explanation: 'The Mathlib version works over any AddMonoid — not just ℕ or ℤ. By restricting to ℕ, the AI\'s proof is much less useful. Mathlib reviewers will reject this for insufficient generality.',
  },
  {
    id: 'naming',
    title: 'Wrong naming convention (even_add_even vs Even.add)',
    severity: 'medium' as const,
    explanation: 'Mathlib uses dot notation: `Even.add` is in the `Even` namespace, so you can write `hm.add hn`. The AI\'s name `even_add_even` is verbose and doesn\'t enable dot notation.',
  },
  {
    id: 'convention',
    title: 'Uses 2 * k instead of k + k',
    severity: 'medium' as const,
    explanation: 'Mathlib defines `Even n` as `∃ k, n = k + k` (not `2 * k`). This matters because `k + k` works in any `AddMonoid`, while `2 * k` requires a `Monoid` with multiplication.',
  },
  {
    id: 'tactic',
    title: 'Uses omega instead of ring for arithmetic',
    severity: 'low' as const,
    explanation: '`omega` works here but `ring` is the standard tactic for algebraic identities in Mathlib. Reviewers prefer `ring` because it tells you what kind of reasoning is happening.',
  },
]

const severityColor = {
  high: 'var(--color-error)',
  medium: 'var(--color-warning)',
  low: 'var(--color-text-muted)',
}

const severityBg = {
  high: 'rgba(239, 68, 68, 0.08)',
  medium: 'rgba(245, 158, 11, 0.08)',
  low: 'rgba(255, 255, 255, 0.03)',
}

export default function InlineExercise() {
  const [step, setStep] = useState<'review' | 'submitted'>('review')
  const [identified, setIdentified] = useState<Record<string, boolean>>({})
  const [notes, setNotes] = useState('')
  const [showReference, setShowReference] = useState(false)
  const [showHints, setShowHints] = useState(false)
  const [expandedIssue, setExpandedIssue] = useState<string | null>(null)

  const identifiedCount = Object.values(identified).filter(Boolean).length
  const totalIssues = KNOWN_ISSUES.length

  const handleSubmit = () => {
    setStep('submitted')
  }

  return (
    <div className="inline-exercise">
      {/* Header */}
      <div className="ie-header">
        <div className="ie-badge">Week 0 · No Lean knowledge needed</div>
        <h2>Can you spot what&apos;s wrong with this AI-generated proof?</h2>
        <p>
          Below is a proof written by an AI autoformaliser. It compiles and is mathematically correct.
          But it would be <strong>immediately rejected</strong> from Mathlib. Can you figure out why?
        </p>
      </div>

      {/* The theorem */}
      <div className="ie-section">
        <h3>The Theorem</h3>
        <div className="ie-math-card">
          <p><strong>If m and n are even, then m + n is even.</strong></p>
          <p className="ie-proof-text">
            Since m is even, ∃a: m = 2a. Since n is even, ∃b: n = 2b.
            Then m + n = 2a + 2b = 2(a + b), so m + n is even.
          </p>
        </div>
      </div>

      {/* AI code */}
      <div className="ie-section">
        <h3>AI-Generated Lean 4 Code</h3>
        <div className="ie-code-block">
          <pre><code>{AI_CODE}</code></pre>
        </div>
        <AxlePanel code={AI_CODE} />
      </div>

      {step === 'review' && (
        <>
          {/* Hints toggle */}
          <div className="ie-section">
            <button
              className="ie-hint-toggle"
              onClick={() => setShowHints(!showHints)}
            >
              <Info size={16} />
              {showHints ? 'Hide hints' : 'Need hints? Click here'}
              {showHints ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
            </button>

            {showHints && (
              <div className="ie-hints">
                <p>Think about these questions:</p>
                <ul>
                  <li>Does the code use Mathlib&apos;s built-in definitions, or re-invent them?</li>
                  <li>Would this work for integers? For elements of any ring?</li>
                  <li>Does the naming follow Mathlib&apos;s dot notation convention?</li>
                  <li>Is the proof style idiomatic? (check the tactic choices)</li>
                </ul>
              </div>
            )}
          </div>

          {/* Issue checklist */}
          <div className="ie-section">
            <h3>What issues do you see?</h3>
            <p className="ie-section-sub">Check each issue you identify. Don&apos;t worry if you miss some — that&apos;s what learning is for.</p>

            <div className="ie-checklist">
              {KNOWN_ISSUES.map(issue => (
                <label
                  key={issue.id}
                  className={`ie-checklist-item ${identified[issue.id] ? 'checked' : ''}`}
                >
                  {identified[issue.id] ? (
                    <CheckCircle size={18} color="var(--color-success)" />
                  ) : (
                    <Circle size={18} color="var(--color-text-muted)" />
                  )}
                  <input
                    type="checkbox"
                    checked={identified[issue.id] || false}
                    onChange={() => setIdentified(prev => ({ ...prev, [issue.id]: !prev[issue.id] }))}
                    className="sr-only"
                  />
                  <span>{issue.title}</span>
                  <span
                    className="ie-severity"
                    style={{ color: severityColor[issue.severity], background: severityBg[issue.severity] }}
                  >
                    {issue.severity}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className="ie-section">
            <h3>Your notes (optional)</h3>
            <textarea
              className="form-textarea"
              placeholder="Anything else you noticed? What would you change?"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              rows={3}
            />
          </div>

          {/* Submit */}
          <div className="ie-section">
            <button onClick={handleSubmit} className="btn btn-primary btn-lg" style={{ width: '100%' }}>
              Submit Review · See What You Found
            </button>
          </div>
        </>
      )}

      {step === 'submitted' && (
        <>
          {/* Score */}
          <div className="ie-section">
            <div className="ie-score-card">
              <div className="ie-score-number">
                {identifiedCount} / {totalIssues}
              </div>
              <div className="ie-score-label">
                {identifiedCount === totalIssues
                  ? 'Perfect — you found every issue!'
                  : identifiedCount >= 3
                  ? 'Great eye! Here\'s what you might have missed:'
                  : 'Good start. Review the full breakdown below:'}
              </div>
            </div>
          </div>

          {/* Full issue breakdown */}
          <div className="ie-section">
            <h3>Full Review</h3>
            <div className="ie-review-list">
              {KNOWN_ISSUES.map(issue => (
                <div
                  key={issue.id}
                  className={`ie-review-item ${identified[issue.id] ? 'found' : 'missed'}`}
                >
                  <button
                    className="ie-review-item-header"
                    onClick={() => setExpandedIssue(expandedIssue === issue.id ? null : issue.id)}
                  >
                    {identified[issue.id] ? (
                      <CheckCircle size={16} color="var(--color-success)" />
                    ) : (
                      <AlertTriangle size={16} color="var(--color-warning)" />
                    )}
                    <span className="ie-review-title">{issue.title}</span>
                    <span
                      className="ie-severity"
                      style={{ color: severityColor[issue.severity], background: severityBg[issue.severity] }}
                    >
                      {issue.severity}
                    </span>
                    {identified[issue.id] ? (
                      <span className="ie-found-badge">Found ✓</span>
                    ) : (
                      <span className="ie-missed-badge">Missed</span>
                    )}
                    {expandedIssue === issue.id ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                  </button>
                  {expandedIssue === issue.id && (
                    <div className="ie-review-explanation">
                      {issue.explanation}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Reference code */}
          <div className="ie-section">
            <button
              className="ie-hint-toggle"
              onClick={() => setShowReference(!showReference)}
            >
              {showReference ? <EyeOff size={16} /> : <Eye size={16} />}
              {showReference ? 'Hide library-quality version' : 'Show library-quality version'}
            </button>

            {showReference && (
              <div className="ie-code-block" style={{ marginTop: 12 }}>
                <pre><code>{REFERENCE_CODE}</code></pre>
              </div>
            )}
          </div>

          {/* Try again or continue */}
          <div className="ie-section" style={{ textAlign: 'center' }}>
            <p style={{ marginBottom: 16, opacity: 0.7 }}>
              This is one exercise from Week 0. Sign in to unlock the full 10-week curriculum
              and save your process traces.
            </p>
            <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
              <button
                onClick={() => { setStep('review'); setIdentified({}); setNotes(''); setShowReference(false); setExpandedIssue(null) }}
                className="btn btn-secondary"
              >
                Try Again
              </button>
              <a href="/studio/auth/sign-up" className="btn btn-primary">
                Sign Up to Continue →
              </a>
            </div>
          </div>
        </>
      )}

      <style jsx>{`
        .inline-exercise {
          max-width: 720px;
          margin: 0 auto;
          padding: 0 24px 80px;
        }
        .ie-header {
          text-align: center;
          margin-bottom: 40px;
        }
        .ie-badge {
          font-size: var(--text-xs);
          color: var(--color-accent);
          text-transform: uppercase;
          letter-spacing: 0.08em;
          font-weight: 600;
          margin-bottom: 12px;
        }
        .ie-header h2 {
          font-size: var(--text-2xl);
          margin-bottom: 12px;
        }
        .ie-header p {
          font-size: var(--text-base);
          color: var(--color-text-secondary);
          max-width: 560px;
          margin: 0 auto;
          line-height: 1.6;
        }
        .ie-section {
          margin-bottom: 28px;
        }
        .ie-section h3 {
          font-family: var(--font-body);
          font-weight: 600;
          font-size: var(--text-sm);
          text-transform: uppercase;
          letter-spacing: 0.06em;
          color: var(--color-text-muted);
          margin-bottom: 12px;
        }
        .ie-section-sub {
          font-size: var(--text-sm);
          color: var(--color-text-secondary);
          margin-bottom: 16px;
        }
        .ie-math-card {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-lg);
          padding: 20px 24px;
        }
        .ie-math-card p:first-child {
          font-size: var(--text-lg);
          margin-bottom: 8px;
        }
        .ie-proof-text {
          font-size: var(--text-sm);
          color: var(--color-text-secondary);
          line-height: 1.6;
        }
        .ie-code-block {
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-lg);
          padding: 16px 20px;
          overflow-x: auto;
        }
        .ie-code-block pre {
          margin: 0;
          font-family: var(--font-mono);
          font-size: 13px;
          line-height: 1.6;
        }
        .ie-code-block code {
          color: var(--color-text);
        }
        .ie-hint-toggle {
          display: flex;
          align-items: center;
          gap: 8px;
          background: none;
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: 10px 16px;
          color: var(--color-text-secondary);
          font-size: var(--text-sm);
          cursor: pointer;
          width: 100%;
          transition: all var(--transition-fast);
        }
        .ie-hint-toggle:hover {
          border-color: var(--color-accent);
          color: var(--color-text);
        }
        .ie-hints {
          margin-top: 12px;
          padding: 16px;
          background: rgba(27, 65, 52, 0.08);
          border-radius: var(--radius-md);
          border: 1px solid rgba(27, 65, 52, 0.15);
        }
        .ie-hints p {
          font-size: var(--text-sm);
          color: var(--color-text-secondary);
          margin-bottom: 8px;
        }
        .ie-hints ul {
          list-style: none;
          padding: 0;
          margin: 0;
        }
        .ie-hints li {
          font-size: var(--text-sm);
          padding: 4px 0;
          color: var(--color-text-secondary);
        }
        .ie-hints li::before {
          content: '→ ';
          color: var(--color-accent);
        }
        .ie-checklist {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .ie-checklist-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 16px;
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          cursor: pointer;
          transition: all var(--transition-fast);
          font-size: var(--text-sm);
        }
        .ie-checklist-item:hover {
          border-color: var(--color-accent);
        }
        .ie-checklist-item.checked {
          background: rgba(52, 211, 153, 0.04);
          border-color: rgba(52, 211, 153, 0.2);
        }
        .ie-checklist-item span:first-of-type {
          flex: 1;
        }
        .ie-severity {
          font-size: 10px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          padding: 2px 8px;
          border-radius: 999px;
          flex-shrink: 0;
        }
        .ie-score-card {
          text-align: center;
          padding: 32px;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-lg);
        }
        .ie-score-number {
          font-family: var(--font-heading);
          font-size: 48px;
          color: var(--color-accent);
          margin-bottom: 8px;
        }
        .ie-score-label {
          font-size: var(--text-sm);
          color: var(--color-text-secondary);
        }
        .ie-review-list {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .ie-review-item {
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          overflow: hidden;
        }
        .ie-review-item.found {
          border-color: rgba(52, 211, 153, 0.2);
        }
        .ie-review-item.missed {
          border-color: rgba(245, 158, 11, 0.2);
        }
        .ie-review-item-header {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 12px 16px;
          background: none;
          border: none;
          color: var(--color-text);
          font-size: var(--text-sm);
          cursor: pointer;
          text-align: left;
        }
        .ie-review-title {
          flex: 1;
        }
        .ie-found-badge {
          font-size: 10px;
          font-weight: 600;
          color: var(--color-success);
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        .ie-missed-badge {
          font-size: 10px;
          font-weight: 600;
          color: var(--color-warning);
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        .ie-review-explanation {
          padding: 12px 16px 16px 42px;
          font-size: var(--text-sm);
          color: var(--color-text-secondary);
          line-height: 1.6;
          border-top: 1px solid var(--color-border);
          background: rgba(255, 255, 255, 0.02);
        }
      `}</style>
    </div>
  )
}
