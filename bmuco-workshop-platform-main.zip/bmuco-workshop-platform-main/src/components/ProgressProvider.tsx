'use client'

import { createClient } from '@/lib/supabase/client'
import { getOrCreateStudioSessionId } from '@/lib/studio-session-id'
import React, { createContext, useCallback, useContext, useEffect, useMemo } from 'react'
import useSWR from 'swr'

export type StudioProgressPayload = {
  progress: {
    user_id: string | null
    total_stars: number
    total_points: number
    current_streak: number
    longest_streak: number
    last_played_at: string | null
    lemma_session_id?: string | null
    created_at?: string | null
  }
  completions: unknown[]
}

type ProgressContextValue = {
  data: StudioProgressPayload | undefined
  error: Error | undefined
  isLoading: boolean
  mutate: () => void
}

const ProgressContext = createContext<ProgressContextValue | null>(null)

async function fetchProgress(): Promise<StudioProgressPayload> {
  const res = await fetch('/studio/api/progress', {
    credentials: 'include',
    cache: 'no-store',
  })
  if (!res.ok) {
    const t = await res.text()
    throw new Error(t || res.statusText)
  }
  return res.json() as Promise<StudioProgressPayload>
}

export function ProgressProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    getOrCreateStudioSessionId()
  }, [])

  const { data, error, isLoading, mutate } = useSWR('studio-progress', fetchProgress, {
    revalidateOnFocus: false,
    dedupingInterval: 10_000,
    shouldRetryOnError: false,
  })

  const stableMutate = useCallback(() => {
    void mutate()
  }, [mutate])

  useEffect(() => {
    const supabase = createClient()
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(() => {
      void mutate()
    })
    return () => subscription.unsubscribe()
  }, [mutate])

  const value = useMemo(
    () => ({
      data,
      error: error as Error | undefined,
      isLoading: Boolean(isLoading && !data),
      mutate: stableMutate,
    }),
    [data, error, isLoading, stableMutate]
  )

  return <ProgressContext.Provider value={value}>{children}</ProgressContext.Provider>
}

export function useProgress(): ProgressContextValue {
  const ctx = useContext(ProgressContext)
  if (!ctx) {
    return {
      data: undefined,
      error: undefined,
      isLoading: false,
      mutate: () => {},
    }
  }
  return ctx
}
