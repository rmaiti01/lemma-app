'use client'

import { Toaster } from 'react-hot-toast'

export default function GameToaster() {
  return (
    <Toaster
      position="top-center"
      toastOptions={{
        duration: 4500,
        style: {
          background: '#161b22',
          color: '#e6edf3',
          border: '1px solid #30363d',
          boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
        },
      }}
    />
  )
}
