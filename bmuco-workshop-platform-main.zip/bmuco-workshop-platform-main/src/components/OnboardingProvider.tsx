'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { clearOnboarded, isOnboarded, setOnboarded } from '@/lib/onboarding-storage'

type OnboardingContextValue = {
  openHowToPlay: () => void
}

type Cell = [number, number]
type Shape = Cell[]
type Piece = {
  shape: Shape
  col: number
  row: number
  rowFloat: number
  speed: number
  color: string
}

const CELL = 18
const HEADER_BG = '#0d1220'
const GRID_LINE = 'rgba(36, 52, 71, 0.4)'
const PIECE_COLORS = [
  'rgba(59, 130, 246, 0.5)',
  'rgba(37, 99, 235, 0.4)',
  'rgba(6, 182, 212, 0.32)',
  'rgba(59, 130, 246, 0.22)',
]
const SHAPES: Shape[] = [
  [[0, 0], [0, 1], [0, 2], [0, 3]], // I
  [[0, 0], [0, 1], [1, 0], [1, 1]], // O
  [[0, 0], [0, 1], [0, 2], [1, 1]], // T
  [[0, 1], [0, 2], [1, 0], [1, 1]], // S
  [[0, 0], [0, 1], [1, 1], [1, 2]], // Z
  [[0, 0], [1, 0], [2, 0], [2, 1]], // L
  [[0, 1], [1, 1], [2, 0], [2, 1]], // J
]

const OnboardingContext = createContext<OnboardingContextValue | null>(null)

function brightenAlpha(color: string): string {
  const match = color.match(
    /rgba\((\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([0-9]*\.?[0-9]+)\)/
  )
  if (!match) return color
  const r = match[1]
  const g = match[2]
  const b = match[3]
  const a = Math.min(1, Number(match[4]) + 0.2)
  return `rgba(${r}, ${g}, ${b}, ${a})`
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function randomShape(): Shape {
  return SHAPES[randomInt(0, SHAPES.length - 1)]
}

function randomColor(): string {
  return PIECE_COLORS[randomInt(0, PIECE_COLORS.length - 1)]
}

function createPiece(startRow: number, canvasCols: number): Piece {
  const maxCol = Math.max(0, canvasCols - 4)
  return {
    shape: randomShape(),
    col: randomInt(0, maxCol),
    row: startRow,
    rowFloat: startRow,
    speed: 0.015 + Math.random() * (0.04 - 0.015),
    color: randomColor(),
  }
}

export function useOnboarding(): OnboardingContextValue {
  const ctx = useContext(OnboardingContext)
  if (!ctx) {
    throw new Error('useOnboarding must be used within OnboardingProvider')
  }
  return ctx
}

export function OnboardingProvider({ children }: { children?: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)
  const [open, setOpen] = useState(false)
  const [isClosing, setIsClosing] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const frameRef = useRef<number | null>(null)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (!mounted) return
    if (pathname !== '/studio') {
      setOpen(false)
      setIsClosing(false)
      return
    }
    if (!isOnboarded()) {
      setOpen(true)
      setIsClosing(false)
    } else {
      setOpen(false)
      setIsClosing(false)
    }
  }, [mounted, pathname])

  const beginAndRoute = useCallback(
    (tier: 'arcade' | 'speed' | 'trace') => {
      const routes: Record<'arcade' | 'speed' | 'trace', string> = {
        arcade: '/studio/worlds/1/levels/1?mode=mcq',
        speed: '/studio/worlds/1/levels/1?mode=build',
        trace: '/studio/worlds/1/levels/1?mode=trace',
      }
      setOnboarded()
      setIsClosing(true)
      window.setTimeout(() => {
        setOpen(false)
        setIsClosing(false)
        router.push(routes[tier])
      }, 300)
    },
    [router]
  )

  const dismiss = useCallback(() => {
    beginAndRoute('arcade')
  }, [beginAndRoute])

  const openHowToPlay = useCallback(() => {
    clearOnboarded()
    setOpen(true)
    setIsClosing(false)
    if (pathname !== '/studio') router.push('/studio')
  }, [pathname, router])

  useEffect(() => {
    if (!open || pathname !== '/studio') return
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let running = true
    let canvasCols = 0
    let canvasRows = 0
    let pieces: Piece[] = []

    const drawGrid = (width: number, height: number) => {
      ctx.strokeStyle = GRID_LINE
      ctx.lineWidth = 1

      for (let y = 0; y <= canvasRows; y += 1) {
        const py = y * CELL + 0.5
        ctx.beginPath()
        ctx.moveTo(0, py)
        ctx.lineTo(width, py)
        ctx.stroke()
      }

      for (let x = 0; x <= canvasCols; x += 1) {
        const px = x * CELL + 0.5
        ctx.beginPath()
        ctx.moveTo(px, 0)
        ctx.lineTo(px, height)
        ctx.stroke()
      }
    }

    const drawPiece = (piece: Piece) => {
      for (const [cellRow, cellCol] of piece.shape) {
        const x = (piece.col + cellCol) * CELL + 1
        const y = (piece.row + cellRow) * CELL + 1
        const w = CELL - 2
        const h = CELL - 2

        ctx.fillStyle = piece.color
        ctx.fillRect(x, y, w, h)

        ctx.beginPath()
        ctx.strokeStyle = brightenAlpha(piece.color)
        ctx.lineWidth = 1
        ctx.moveTo(x + 0.5, y + 0.5)
        ctx.lineTo(x + w - 0.5, y + 0.5)
        ctx.moveTo(x + 0.5, y + 0.5)
        ctx.lineTo(x + 0.5, y + h - 0.5)
        ctx.stroke()
      }
    }

    const drawFrame = (update: boolean) => {
      const width = canvas.width
      const height = canvas.height

      ctx.fillStyle = HEADER_BG
      ctx.fillRect(0, 0, width, height)
      drawGrid(width, height)

      if (update) {
        pieces = pieces.map(piece => {
          const nextFloat = piece.rowFloat + piece.speed
          return { ...piece, rowFloat: nextFloat, row: Math.floor(nextFloat) }
        })

        pieces = pieces.map(piece =>
          piece.row > canvasRows + 2 ? createPiece(-4, canvasCols) : piece
        )
      }

      for (const piece of pieces) drawPiece(piece)
    }

    const resize = () => {
      const parent = canvas.parentElement
      if (!parent) return
      const width = Math.max(1, Math.floor(parent.clientWidth))
      const height = Math.max(1, Math.floor(parent.clientHeight))
      canvas.width = width
      canvas.height = height
      canvasCols = Math.ceil(width / CELL)
      canvasRows = Math.ceil(height / CELL)
      pieces = [-4, -8, -12, -16, -20, -24].map(row => createPiece(row, canvasCols))
      drawFrame(false)
    }

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const loop = () => {
      if (!running) return
      drawFrame(true)
      frameRef.current = requestAnimationFrame(loop)
    }

    if (frameRef.current !== null) {
      cancelAnimationFrame(frameRef.current)
      frameRef.current = null
    }

    resize()
    if (!reduced) {
      frameRef.current = requestAnimationFrame(loop)
    }

    window.addEventListener('resize', resize)
    return () => {
      running = false
      window.removeEventListener('resize', resize)
      if (frameRef.current !== null) {
        cancelAnimationFrame(frameRef.current)
        frameRef.current = null
      }
    }
  }, [open, pathname])

  return (
    <OnboardingContext.Provider value={{ openHowToPlay }}>
      {children}
      {mounted && pathname === '/studio' && open && (
        <div
          className={`entry-overlay${isClosing ? ' is-closing' : ''}`}
          onClick={e => {
            if (e.target === e.currentTarget) dismiss()
          }}
          role="presentation"
        >
          <div
            className="entry-card"
            role="dialog"
            aria-modal="true"
            aria-labelledby="entry-title"
            onClick={e => e.stopPropagation()}
          >
            <div className="entry-header-zone">
              <canvas ref={canvasRef} className="entry-canvas" aria-hidden="true" />
              <div className="entry-header-content">
                <div className="entry-topbar">
                  <span className="entry-topbar-title">■ LEMMA</span>
                  <button type="button" className="entry-newgame-btn" onClick={() => beginAndRoute('arcade')}>
                    NEW GAME
                  </button>
                </div>
                <div className="entry-hero-copy">
                  <p className="label-tag">◆ WORLD 1 — NATURAL NUMBERS</p>
                  <h1 id="entry-title" className="hero-heading">
                    Finished Natural Number Game?
                  </h1>
                  <p className="hero-body">
                    Stack proof-reading skills like blocks...
                  </p>
                </div>
              </div>
            </div>

            <div className="entry-modes-zone">
              <p className="section-label entry-modes-label">THREE WAYS TO PLAY</p>
              <button
                type="button"
                className="entry-mode-card arcade"
                onClick={() => beginAndRoute('arcade')}
              >
                <span className="card-mode-label">► ARCADE RUN</span>
                <p className="card-title">Start from the basics</p>
                <p className="card-desc">
                  MCQ first to learn the moves, then fill in real Lean proofs. Best if you finished NNG
                  recently.
                </p>
              </button>
              <button
                type="button"
                className="entry-mode-card speed"
                onClick={() => beginAndRoute('speed')}
              >
                <span className="card-mode-label speed-label">&gt;&gt; SPEED LANE</span>
                <p className="card-title">I know my Lean basics</p>
                <p className="card-desc">
                  Skip the multiple choice. Jump straight to filling in proof skeletons and justifying your
                  decisions.
                </p>
              </button>
              <button
                type="button"
                className="entry-mode-card speed"
                onClick={() => beginAndRoute('trace')}
              >
                <span className="card-mode-label expert-label">&gt;&gt; EXPERT MODE</span>
                <p className="card-title">I want to annotate proofs</p>
                <p className="card-desc">
                  Go straight to Trace mode. Inspect each tactic step, reject the wrong ones, explain your
                  reasoning. This is where the real data gets made.
                </p>
              </button>
            </div>

            <div className="entry-footer">
              <button type="button" className="entry-footer-link" onClick={dismiss}>
                Already played before? Continue →
              </button>
            </div>
          </div>
        </div>
      )}
    </OnboardingContext.Provider>
  )
}

export default OnboardingProvider
