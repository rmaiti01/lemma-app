import { type NextRequest } from 'next/server'
import { updateSession } from '@/lib/supabase/middleware'

export async function middleware(request: NextRequest) {
  return await updateSession(request)
}

export const config = {
  matcher: [
    // Only protect dashboard routes; do not redirect on landing page or auth flows.
    '/studio/dashboard/:path*',
  ],
}
