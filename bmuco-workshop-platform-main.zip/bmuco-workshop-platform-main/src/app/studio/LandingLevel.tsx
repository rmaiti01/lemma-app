'use client'

import LevelPlayer from '@/components/game/LevelPlayer'
import type { GameLevel } from '@/lib/game-types'
import { useRouter } from 'next/navigation'

export default function LandingLevel({ level }: { level: GameLevel }) {
  const router = useRouter()

  return (
    <LevelPlayer
      level={level}
      onNextLevel={() => router.push('/studio/play/1')}
      nextLevelLabel="Next Level"
    />
  )
}
