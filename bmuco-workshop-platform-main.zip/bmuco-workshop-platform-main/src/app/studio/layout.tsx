import { ProgressProvider } from '@/components/ProgressProvider'

export default function StudioLayout({ children }: { children: React.ReactNode }) {
  return <ProgressProvider>{children}</ProgressProvider>
}
