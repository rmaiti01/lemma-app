'use client'

import type { CSSProperties } from 'react'
import Link from 'next/link'
import type { W1Level } from '@/lib/world1-data'

interface World1LobbyProps {
  levels: W1Level[]
  starsMap: Record<string, number>
}

export default function World1Lobby({ levels, starsMap }: World1LobbyProps) {
  const playableLevels = levels.filter(level => !level.locked)
  const firstIncomplete = playableLevels.find(level => (starsMap[level.id] ?? 0) < 3)

  return (
    <div style={{ maxWidth: 720, margin: '0 auto', padding: '48px 20px' }}>

      {/* ← Home breadcrumb */}
      <div style={{ marginBottom: 24, display: 'flex', gap: 16 }}>
        <Link
          href="/studio"
          style={{
            fontSize: 13,
            color: 'var(--color-text-muted)',
            textDecoration: 'none',
            display: 'inline-flex',
            alignItems: 'center',
            gap: 4,
          }}
        >
          ← Home
        </Link>
        <span style={{ color: 'var(--color-border)', fontSize: 13 }}>/</span>
        <span style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>World 1</span>
      </div>

      {/* Header */}
      <div style={{ marginBottom: 32 }}>
        <div
          style={{
            fontSize: 11,
            fontWeight: 600,
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
            color: 'var(--color-primary)',
            marginBottom: 6,
          }}
        >
          Lemma
        </div>
        <h1
          style={{
            fontSize: 32,
            fontWeight: 800,
            color: 'var(--color-text)',
            margin: '0 0 12px',
            fontFamily: 'var(--font-heading)',
          }}
        >
          World 1: The Meta-Proof Trap
        </h1>
        <p
          style={{
            fontSize: 15,
            color: 'var(--color-text-secondary)',
            lineHeight: 1.7,
            margin: '0 0 16px',
          }}
        >
          In this world, you&apos;ll encounter proofs that look right but might not be. Your job is
          to fill in the formal Lean steps — and to decide whether the informal proof
          you&apos;re reading is actually valid. Not all of them are.
        </p>
        <div
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 6,
            background: 'rgba(59, 130, 246, 0.06)',
            border: '1px solid rgba(59, 130, 246, 0.25)',
            borderRadius: 'var(--radius-sm)',
            padding: '4px 12px',
            fontSize: 12,
            fontWeight: 600,
            color: 'var(--color-primary)',
          }}
        >
          Requires: Natural Number Game
        </div>
      </div>

      {/* Level grid */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))',
          gap: 12,
          marginBottom: 32,
        }}
      >
        {levels.map(level => {
          const stars = starsMap[level.id] ?? 0
          const baseStyle: CSSProperties = {
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 8,
            padding: '20px 12px',
            background: level.locked ? 'var(--color-surface-raised)' : 'var(--color-surface)',
            border: level.locked
              ? '1px solid rgba(148, 163, 184, 0.35)'
              : `1px solid ${level.isTrap ? 'rgba(239, 68, 68, 0.3)' : 'var(--color-border)'}`,
            borderRadius: 'var(--radius-lg)',
            textDecoration: 'none',
            transition: 'border-color var(--transition-fast), transform var(--transition-fast), box-shadow var(--transition-fast)',
            boxShadow: 'var(--shadow-sm)',
            cursor: level.locked ? 'default' : 'pointer',
            opacity: level.locked ? 0.85 : 1,
          }

          const content = (
            <>
              <div style={{ fontSize: 24, fontWeight: 800, color: 'var(--color-text)' }}>
                {level.locked ? '🔒' : level.isTrap ? '?' : level.number}
              </div>
              <div
                style={{
                  fontSize: 13,
                  fontWeight: 600,
                  color: 'var(--color-text-secondary)',
                  fontFamily: 'var(--font-mono)',
                }}
              >
                {level.theorem}
              </div>
              {level.locked ? (
                <div
                  style={{
                    fontSize: 9,
                    color: 'var(--color-text-muted)',
                    fontWeight: 600,
                    textTransform: 'uppercase',
                    letterSpacing: '0.08em',
                  }}
                >
                  Locked
                </div>
              ) : (
                <div style={{ fontSize: 18, letterSpacing: 2 }}>
                  {[1, 2, 3].map(i => (
                    <span key={i} style={{ color: i <= stars ? 'var(--color-warning)' : 'var(--color-border)' }}>
                      ★
                    </span>
                  ))}
                </div>
              )}
              {level.type === 'B' && !level.locked && (
                <div
                  style={{
                    fontSize: 9,
                    color: 'var(--color-error)',
                    fontWeight: 600,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}
                >
                  {level.isTrap ? 'TRAP' : 'SUSPECT'}
                </div>
              )}
            </>
          )

          return level.locked ? (
            <div key={level.id} style={baseStyle} className="w1l-tile w1l-tile-locked">
              {content}
            </div>
          ) : (
            <Link key={level.id} href={`/studio/worlds/1/levels/${level.id}?mode=mcq`} style={baseStyle} className="w1l-tile">
              {content}
            </Link>
          )
        })}
      </div>

      {/* Start button */}
      {firstIncomplete && (
        <div style={{ textAlign: 'center' }}>
          <Link
            href={`/studio/worlds/1/levels/${firstIncomplete.id}?mode=mcq`}
            className="btn btn-primary"
            style={{
              display: 'inline-block',
              padding: '12px 32px',
              fontSize: 16,
              textDecoration: 'none',
            }}
          >
            {Object.keys(starsMap).length === 0
              ? 'Start World 1'
              : `Continue — Level ${firstIncomplete.number}`}
          </Link>
        </div>
      )}

      <style jsx>{`
        :global(.w1l-tile:hover) {
          border-color: var(--color-primary) !important;
          transform: translateY(-2px);
          box-shadow: var(--shadow-md) !important;
        }
        :global(.w1l-tile-locked:hover) {
          transform: none;
          box-shadow: var(--shadow-sm) !important;
          border-color: rgba(148, 163, 184, 0.35) !important;
        }
      `}</style>
    </div>
  )
}