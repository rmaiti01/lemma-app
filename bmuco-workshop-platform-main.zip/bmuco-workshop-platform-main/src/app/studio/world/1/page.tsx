import { WORLD_1_LEVELS } from '@/lib/world1-data'
import { createClient } from '@/lib/supabase/server'
import World1Lobby from './World1Lobby'

export const metadata = {
  title: 'World 1: The Meta-Proof Trap | Lemma',
}

export default async function World1Page() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Fetch best stars per level for this user
  let starsMap: Record<string, number> = {}
  if (user) {
    const { data } = await supabase
      .from('world1_attempts')
      .select('level_id, stars')
      .eq('user_id', user.id)
      .not('stars', 'is', null)

    if (data) {
      for (const row of data) {
        const current = starsMap[row.level_id] ?? 0
        if ((row.stars ?? 0) > current) starsMap[row.level_id] = row.stars
      }
    }
  }

  return <World1Lobby levels={WORLD_1_LEVELS} starsMap={starsMap} />
}
