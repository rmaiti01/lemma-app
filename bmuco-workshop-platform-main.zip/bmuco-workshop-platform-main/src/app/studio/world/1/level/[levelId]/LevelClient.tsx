'use client'

import { useCallback } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { useLevelState } from '@/hooks/useLevelState'
import { WORLD_1_LEVELS } from '@/lib/world1-data'
import LevelLayout from '@/components/world1/LevelLayout'

interface LevelClientProps {
  levelId: string
  userId: string | null
}

export default function LevelClient({ levelId, userId }: LevelClientProps) {
  const state = useLevelState(levelId, userId)
  const router = useRouter()

  const handleNextLevel = useCallback(() => {
    if (!state) return
    const currentIndex = WORLD_1_LEVELS.findIndex(l => l.id === state.level.id)
    const nextLevel = WORLD_1_LEVELS.slice(currentIndex + 1).find(level => !level.locked)
    if (nextLevel) {
      router.push(`/studio/worlds/1/levels/${nextLevel.id}?mode=mcq`)
    } else {
      router.push('/studio/world/1')
    }
  }, [state, router])

  const handleRetry = useCallback(() => {
    router.refresh()
  }, [router])

  if (!state) {
    return (
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          height: '80vh',
          color: 'var(--color-text-muted)',
          fontSize: 16,
        }}
      >
        Level not found.
      </div>
    )
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Navigation bar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 16,
          padding: '10px 20px',
          borderBottom: '1px solid var(--color-border)',
          background: 'var(--color-surface)',
          flexShrink: 0,
        }}
      >
        <Link
          href="/studio"
          style={{
            fontSize: 13,
            color: 'var(--color-text-muted)',
            textDecoration: 'none',
            display: 'inline-flex',
            alignItems: 'center',
            gap: 4,
          }}
        >
          ← Home
        </Link>
        <span style={{ color: 'var(--color-border)', fontSize: 13 }}>/</span>
        <Link
          href="/studio/world/1"
          style={{
            fontSize: 13,
            color: 'var(--color-text-muted)',
            textDecoration: 'none',
          }}
        >
          World 1
        </Link>
        <span style={{ color: 'var(--color-border)', fontSize: 13 }}>/</span>
        <span style={{ fontSize: 13, color: 'var(--color-text)' }}>
          Level {state.level.number}
        </span>
      </div>

      {/* Level content */}
      <div style={{ flex: 1, overflow: 'hidden' }}>
        <LevelLayout state={state} onNextLevel={handleNextLevel} onRetry={handleRetry} />
      </div>
    </div>
  )
}