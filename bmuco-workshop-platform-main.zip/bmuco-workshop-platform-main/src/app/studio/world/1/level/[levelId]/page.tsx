import { getW1Level } from '@/lib/world1-data'
import { notFound, redirect } from 'next/navigation'

interface Props {
  params: { levelId: string }
}

export async function generateMetadata({ params }: Props) {
  const level = getW1Level(params.levelId)
  return {
    title: level
      ? `Level ${level.number}: ${level.theorem} | Lemma`
      : 'Level Not Found',
  }
}

export default async function LevelPage({ params }: Props) {
  const level = getW1Level(params.levelId)
  if (!level || level.locked) notFound()
  redirect(`/studio/worlds/1/levels/${level.id}?mode=mcq`)
}
