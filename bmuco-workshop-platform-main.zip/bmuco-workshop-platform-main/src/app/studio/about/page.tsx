import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import { ArrowRight } from 'lucide-react'
import Link from 'next/link'

export default function AboutPage() {
  return (
    <div className="page-content">
      <Navbar />
      <main style={{ paddingTop: '60px' }}>
        <div className="container" style={{ maxWidth: 800, paddingTop: 80, paddingBottom: 80 }}>
          <span className="hero-badge" style={{ marginBottom: 24, display: 'inline-flex' }}>About Lemma</span>
          <h1 style={{ marginBottom: 24 }}>Bridging the gap between the Natural Number Game and Mathlib.</h1>
          <p style={{ fontSize: 'var(--text-lg)', marginBottom: 64 }}>
            You finished the Natural Number Game. You know what induction is. But Mathlib-quality
            contributions require a completely different skill set: naming conventions, generality,
            library integration, proof architecture, and style compliance. Lemma trains
            exactly those skills.
          </p>

          {/* The Quality Gap */}
          <section style={{ marginBottom: 64 }}>
            <h2 style={{ marginBottom: 16 }}>The quality gap</h2>
            <p style={{ marginBottom: 24 }}>
              Most proofs that compile are still far from library-ready. Mathlib PR reviewers evaluate
              five dimensions that most newcomers never learn: style compliance, correct generality,
              library integration, API completeness, and documentation.
            </p>
            <p>
              Lemma turns proof review into a game. Each level presents a Lean 4 proof that
              compiles — but contains real issues that would get it rejected from Mathlib. Your job
              is to find them.
            </p>
          </section>

          {/* Why This Approach */}
          <section style={{ marginBottom: 64 }}>
            <h2 style={{ marginBottom: 16 }}>Learning by reviewing</h2>
            <p style={{ marginBottom: 24 }}>
              Research shows that reviewing flawed proofs builds deeper understanding than writing
              proofs from scratch. When you identify why a proof is too long, uses the wrong
              predicate, or reinvents an existing lemma, you internalise the standards that make
              Mathlib contributions successful.
            </p>
            <p>
              The game is structured into 7 worlds, each focusing on a different review skill —
              from spotting surface-level red flags to conducting full Mathlib-standard reviews.
            </p>
          </section>

          {/* The 5-Layer Methodology */}
          <section style={{ marginBottom: 64 }}>
            <h2 style={{ marginBottom: 16 }}>The 5-layer review methodology</h2>
            <p style={{ marginBottom: 32 }}>
              Every proof review exercise is decomposed into five structured layers. Each layer
              captures a distinct skill that Mathlib contributors need.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {[
                { n: 0, title: 'Inventory', desc: 'Identify the mathematical objects, properties, hypotheses, and conclusion. Search Mathlib for existing relevant results.' },
                { n: 1, title: 'Type Skeleton', desc: 'Choose the right level of generality. Reason about type class constraints and universe levels.' },
                { n: 2, title: 'Statement', desc: 'Write the formal statement. Choose the correct Mathlib-style name. Justify naming decisions.' },
                { n: 3, title: 'Proof', desc: 'Write the proof in Lean 4. Verify compilation via AXLE. Record tactic choices and alternatives considered.' },
                { n: 4, title: 'Culture Check', desc: 'Check Mathlib coverage, style compliance, API completeness. Flag generality and documentation issues.' },
              ].map(layer => (
                <div key={layer.n} className="card" style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
                  <div style={{
                    width: 36, height: 36, borderRadius: '50%', background: 'var(--color-surface-hover)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                    fontSize: 'var(--text-sm)', fontWeight: 700
                  }}>
                    {layer.n}
                  </div>
                  <div>
                    <h4 style={{ marginBottom: 4 }}>{layer.title}</h4>
                    <p style={{ fontSize: 'var(--text-sm)' }}>{layer.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* CTA */}
          <section style={{ textAlign: 'center', padding: '48px 0' }}>
            <h2 style={{ marginBottom: 16 }}>Ready to level up?</h2>
            <p style={{ maxWidth: 500, margin: '0 auto 32px' }}>
              Every proof you review builds the skills you need to make your first
              Mathlib contribution. Start playing now.
            </p>
            <Link href="/studio/worlds" className="btn btn-primary btn-lg">
              Start Playing
              <ArrowRight size={18} />
            </Link>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  )
}
