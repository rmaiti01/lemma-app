import { syncAnonymousPlayerProgress } from '@/lib/anonymous-progress'
import { createAdminClient } from '@/lib/supabase/admin'
import { createClient } from '@/lib/supabase/server'
import { computeTraceAchievements } from '@/lib/trace-achievements'
import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const supabase = createClient()
    const isPartial = body.is_partial === true

    // 1. Insert trace (works for anonymous + authed)
    const traceRow: Record<string, unknown> = {
      session_id: body.session_id || null,
      user_id: body.user_id || null,
      world_id: body.world_id != null ? Number(body.world_id) : null,
      level_number: body.level_number != null ? Number(body.level_number) : null,
      proof_shown: body.proof_shown ?? null,
      issues_identified: body.issues_identified ?? [],
      issues_missed: body.issues_missed ?? [],
      false_positives: body.false_positives ?? [],
      stars_earned: body.stars_earned ?? 0,
      points_earned: body.points_earned ?? 0,
      time_seconds: body.time_seconds ?? null,
      player_skill: body.player_skill || 'unknown',
    }

    const rawLevelId = body.level_id
    const levelIdNum =
      typeof rawLevelId === 'number' ? rawLevelId : parseInt(String(rawLevelId ?? ''), 10)
    if (Number.isFinite(levelIdNum) && levelIdNum > 0) {
      traceRow.level_id = levelIdNum
    }

    if (isPartial) traceRow.is_partial = true

    if (body.confidence_scores) traceRow.confidence_scores = body.confidence_scores
    if (body.hints_used != null) traceRow.hints_used = body.hints_used
    if (body.alternatives_rejected) traceRow.alternatives_rejected = body.alternatives_rejected
    if (body.reasoning_text) traceRow.reasoning_text = body.reasoning_text
    if (body.proof_state_before) traceRow.proof_state_before = body.proof_state_before
    if (body.proof_state_after) traceRow.proof_state_after = body.proof_state_after
    if (body.tactic_chosen) traceRow.tactic_chosen = body.tactic_chosen
    if (body.axle_verified != null) traceRow.axle_verified = body.axle_verified
    if (body.annotations) traceRow.annotations = body.annotations

    let traceErr = null
    const result = await supabase.from('game_traces').insert([traceRow])
    traceErr = result.error

    if (traceErr && traceRow.confidence_scores) {
      delete traceRow.confidence_scores
      const retry = await supabase.from('game_traces').insert([traceRow])
      traceErr = retry.error
    }

    if (traceErr && traceRow.is_partial) {
      delete traceRow.is_partial
      const retry = await supabase.from('game_traces').insert([traceRow])
      traceErr = retry.error
    }

    if (traceErr) {
      return NextResponse.json({ error: traceErr.message }, { status: 500 })
    }

    const {
      data: { user },
    } = await supabase.auth.getUser()

    const sessionIdForProgress =
      typeof body.session_id === 'string' ? body.session_id.trim() : ''
    if (!user && sessionIdForProgress && !isPartial) {
      const admin = createAdminClient()
      if (admin) {
        try {
          await syncAnonymousPlayerProgress(admin, sessionIdForProgress)
        } catch (e) {
          console.error('[traces] syncAnonymousPlayerProgress', e)
        }
      }
    }

    const achievements: ReturnType<typeof computeTraceAchievements> = []

    if (user && !isPartial) {
      const userId = user.id
      const stars = body.stars_earned ?? 0
      const points = body.points_earned ?? 0
      const completionLevelId =
        Number.isFinite(levelIdNum) && levelIdNum > 0 ? levelIdNum : null
      const worldIdBody = body.world_id != null ? Number(body.world_id) : null

      const { data: progressBefore } = await supabase
        .from('player_progress')
        .select('total_stars, total_points, current_streak, longest_streak, last_played_at')
        .eq('user_id', userId)
        .maybeSingle()

      const prevTotalPoints = progressBefore?.total_points ?? 0

      const { data: completionsBefore } = await supabase
        .from('level_completions')
        .select('level_id, stars, points')
        .eq('user_id', userId)

      const beforeRows = (completionsBefore || []) as {
        level_id: number
        stars: number
        points: number
      }[]

      let wroteCompletion = false
      let priorBestStars = 0

      if (completionLevelId != null) {
        const existing = beforeRows.find(c => c.level_id === completionLevelId)
        priorBestStars = existing?.stars ?? 0

        if (existing) {
          if (stars > existing.stars || (stars === existing.stars && points > existing.points)) {
            wroteCompletion = true
            await supabase
              .from('level_completions')
              .update({
                stars,
                points,
                issues_found: body.issues_identified,
                issues_missed: body.issues_missed,
                false_positives: body.false_positives,
                time_seconds: body.time_seconds,
                completed_at: new Date().toISOString(),
              })
              .eq('user_id', userId)
              .eq('level_id', completionLevelId)
          }
        } else {
          wroteCompletion = true
          await supabase.from('level_completions').insert([
            {
              user_id: userId,
              level_id: completionLevelId,
              stars,
              points,
              issues_found: body.issues_identified,
              issues_missed: body.issues_missed,
              false_positives: body.false_positives,
              time_seconds: body.time_seconds,
              is_first_completion: true,
            },
          ])
        }
      }

      const { data: allCompletions } = await supabase
        .from('level_completions')
        .select('level_id, stars, points')
        .eq('user_id', userId)

      const rows = (allCompletions || []) as { level_id: number; stars: number; points: number }[]
      const totalStars = rows.reduce((s, c) => s + c.stars, 0)
      const totalPoints = rows.reduce((s, c) => s + c.points, 0)

      const now = new Date()
      const today = now.toISOString().slice(0, 10)
      const lastPlayed = progressBefore?.last_played_at
        ? new Date(progressBefore.last_played_at).toISOString().slice(0, 10)
        : null

      let currentStreak = 1
      let streakIncrementedThisSubmit = false

      if (!progressBefore) {
        currentStreak = 1
        streakIncrementedThisSubmit = true
      } else if (lastPlayed === today) {
        currentStreak = progressBefore.current_streak
        streakIncrementedThisSubmit = false
      } else {
        const yesterday = new Date(now)
        yesterday.setDate(yesterday.getDate() - 1)
        const yesterdayStr = yesterday.toISOString().slice(0, 10)
        if (lastPlayed === yesterdayStr) {
          currentStreak = progressBefore.current_streak + 1
          streakIncrementedThisSubmit = true
        } else {
          currentStreak = 1
          streakIncrementedThisSubmit = true
        }
      }

      const longestStreak = Math.max(currentStreak, progressBefore?.longest_streak ?? 0)

      await supabase.from('player_progress').upsert(
        {
          user_id: userId,
          total_stars: totalStars,
          total_points: totalPoints,
          current_streak: currentStreak,
          longest_streak: longestStreak,
          last_played_at: now.toISOString(),
        },
        { onConflict: 'user_id' }
      )

      let worldJustCompleted = false
      if (
        worldIdBody != null &&
        Number.isFinite(worldIdBody) &&
        wroteCompletion &&
        completionLevelId != null
      ) {
        const { data: worldLevels } = await supabase
          .from('game_levels')
          .select('id')
          .eq('world_id', worldIdBody)

        const inWorld = new Set((worldLevels || []).map(l => l.id as number))
        if (inWorld.size > 0) {
          const priorInWorld = new Set(
            beforeRows.filter(c => inWorld.has(c.level_id) && c.stars >= 1).map(c => c.level_id)
          ).size

          let afterRows = beforeRows
          if (wroteCompletion) {
            const i = beforeRows.findIndex(c => c.level_id === completionLevelId)
            const copy = [...beforeRows]
            if (i >= 0) {
              copy[i] = { level_id: completionLevelId, stars, points }
            } else {
              copy.push({ level_id: completionLevelId, stars, points })
            }
            afterRows = copy
          }

          const afterInWorld = new Set(
            afterRows.filter(c => inWorld.has(c.level_id) && c.stars >= 1).map(c => c.level_id)
          ).size

          worldJustCompleted = priorInWorld < inWorld.size && afterInWorld === inWorld.size
        }
      }

      achievements.push(
        ...computeTraceAchievements({
          wroteCompletion,
          stars,
          priorBestStars,
          worldJustCompleted,
          streakIncrementedThisSubmit,
          newStreak: currentStreak,
          prevTotalPoints,
          newTotalPoints: totalPoints,
        })
      )
    }

    return NextResponse.json({ ok: true, achievements })
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
