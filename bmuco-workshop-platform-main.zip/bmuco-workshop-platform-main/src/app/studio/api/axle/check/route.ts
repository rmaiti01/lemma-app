export { POST } from '@/app/api/check/route'
