import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const supabase = createClient()

    const { error } = await supabase
      .from('applications')
      .insert([{
        email: body.email,
        full_name: body.full_name,
        university: body.university || null,
        degree_level: body.degree_level || null,
        mathematical_background: body.mathematical_background || null,
        lean_experience: body.lean_experience || 'none',
        motivation: body.motivation || null,
        weekly_hours_available: body.weekly_hours_available ? parseInt(body.weekly_hours_available) : null,
        how_heard: body.how_heard || null,
      }])

    if (error) {
      // If Supabase is not configured, still accept the form submission gracefully
      console.error('Supabase error:', error)
      return NextResponse.json({ success: true, note: 'Application received (database pending setup)' })
    }

    return NextResponse.json({ success: true })
  } catch (_err) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 })
  }
}
