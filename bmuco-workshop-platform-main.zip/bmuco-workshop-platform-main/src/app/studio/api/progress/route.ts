import { createAdminClient } from '@/lib/supabase/admin'
import { fetchAnonymousTraceTotals, syncAnonymousPlayerProgress } from '@/lib/anonymous-progress'
import { LEMMA_PROGRESS_SESSION_COOKIE } from '@/lib/progress-session'
import { createClient } from '@/lib/supabase/server'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

const CACHE_HEADERS = {
  'Cache-Control': 'private, s-maxage=0, stale-while-revalidate=30',
}

function json(data: unknown) {
  return NextResponse.json(data, { headers: CACHE_HEADERS })
}

export async function GET() {
  try {
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (user) {
      const [progressRes, completionsRes] = await Promise.all([
        supabase.from('player_progress').select('*').eq('user_id', user.id).maybeSingle(),
        supabase.from('level_completions').select('*').eq('user_id', user.id),
      ])

      const base = progressRes.data
      const progress = {
        user_id: user.id,
        total_stars: typeof base?.total_stars === 'number' ? base.total_stars : 0,
        total_points: typeof base?.total_points === 'number' ? base.total_points : 0,
        current_streak: typeof base?.current_streak === 'number' ? base.current_streak : 0,
        longest_streak: typeof base?.longest_streak === 'number' ? base.longest_streak : 0,
        last_played_at: base?.last_played_at ?? null,
        created_at: base?.created_at ?? null,
        lemma_session_id: (base as { lemma_session_id?: string | null } | null)?.lemma_session_id ?? null,
      }

      return json({
        progress,
        completions: completionsRes.data ?? [],
      })
    }

    const sid = cookies().get(LEMMA_PROGRESS_SESSION_COOKIE)?.value?.trim()
    if (!sid) {
      return json({
        progress: {
          user_id: null,
          total_stars: 0,
          total_points: 0,
          current_streak: 0,
          longest_streak: 0,
          last_played_at: null,
          lemma_session_id: null,
        },
        completions: [],
      })
    }

    const admin = createAdminClient()
    if (!admin) {
      return json({
        progress: {
          user_id: null,
          total_stars: 0,
          total_points: 0,
          current_streak: 0,
          longest_streak: 0,
          last_played_at: null,
          lemma_session_id: sid,
        },
        completions: [],
      })
    }

    const { data: row } = await admin
      .from('player_progress')
      .select('*')
      .eq('lemma_session_id', sid)
      .maybeSingle()

    let totalStars = typeof row?.total_stars === 'number' ? row.total_stars : 0
    let totalPoints = typeof row?.total_points === 'number' ? row.total_points : 0
    let lastPlayed = row?.last_played_at ?? null

    if (row == null) {
      try {
        const agg = await fetchAnonymousTraceTotals(admin, sid)
        totalStars = agg.totalStars
        totalPoints = agg.totalPoints
        if (agg.levelsTouched > 0) {
          await syncAnonymousPlayerProgress(admin, sid)
        }
      } catch {
        totalStars = 0
        totalPoints = 0
      }
    }

    return json({
      progress: {
        user_id: null,
        total_stars: totalStars,
        total_points: totalPoints,
        current_streak: typeof row?.current_streak === 'number' ? row.current_streak : 0,
        longest_streak: typeof row?.longest_streak === 'number' ? row.longest_streak : 0,
        last_played_at: lastPlayed,
        lemma_session_id: sid,
      },
      completions: [],
    })
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json(
      { error: message },
      { status: 500, headers: CACHE_HEADERS }
    )
  }
}
