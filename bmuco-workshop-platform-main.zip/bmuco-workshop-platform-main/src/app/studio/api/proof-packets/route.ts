import { createClient } from '@/lib/supabase/server'
import type { ProofPacket } from '@/lib/game-types'
import { NextResponse } from 'next/server'

const MODES: ProofPacket['mode'][] = ['mcq', 'build', 'trace', 'review']

function isMode(x: unknown): x is ProofPacket['mode'] {
  return typeof x === 'string' && (MODES as string[]).includes(x)
}

function sanitizeInsertRow(row: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(row)) {
    if (v === undefined) continue
    if (k === 'topic_tags' && Array.isArray(v) && v.length === 0) continue
    out[k] = v
  }
  return out
}

function coercePacket(raw: unknown, userId: string | null): Record<string, unknown> | null {
  if (raw === null || typeof raw !== 'object') return null
  const p = raw as Record<string, unknown>

  if (typeof p.session_id !== 'string' || !p.session_id) return null
  if (typeof p.level_id !== 'string' || !p.level_id) return null
  if (!isMode(p.mode)) return null
  if (typeof p.proof_state_before !== 'string') return null
  if (typeof p.tactic_success !== 'boolean') return null
  if (typeof p.step_number !== 'number' || !Number.isFinite(p.step_number)) return null

  const worldId = p.world_id
  const world_id =
    worldId == null
      ? null
      : typeof worldId === 'number' && Number.isFinite(worldId)
        ? Math.trunc(worldId)
        : typeof worldId === 'string' && worldId !== ''
          ? Math.trunc(Number(worldId))
          : null

  const tactics_rejected = Array.isArray(p.tactics_rejected) ? p.tactics_rejected : []
  const premises_used = Array.isArray(p.premises_used) ? p.premises_used : []
  const premises_available = Array.isArray(p.premises_available) ? p.premises_available : []
  const topic_tags = Array.isArray(p.topic_tags) ? p.topic_tags : []

  const confidence = p.confidence
  const confidenceVal =
    typeof confidence === 'number' && Number.isFinite(confidence)
      ? Math.trunc(confidence)
      : null

  const hints_used =
    typeof p.hints_used_this_step === 'number' && Number.isFinite(p.hints_used_this_step)
      ? Math.trunc(p.hints_used_this_step)
      : 0

  const total_steps = p.total_steps
  const total_steps_val =
    typeof total_steps === 'number' && Number.isFinite(total_steps)
      ? Math.trunc(total_steps)
      : null

  const difficulty = p.difficulty_rating
  const difficulty_val =
    typeof difficulty === 'number' && Number.isFinite(difficulty)
      ? Math.trunc(difficulty)
      : null

  const axle_ms = p.axle_duration_ms
  const axle_ms_val =
    typeof axle_ms === 'number' && Number.isFinite(axle_ms) ? Math.trunc(axle_ms) : null

  const time_ms = p.time_to_decision_ms
  const time_ms_val =
    typeof time_ms === 'number' && Number.isFinite(time_ms) ? Math.trunc(time_ms) : null

  return {
    session_id: p.session_id,
    user_id: userId,
    level_id: p.level_id,
    world_id,
    mode: p.mode,
    proof_state_before: p.proof_state_before,
    tactic_chosen: typeof p.tactic_chosen === 'string' ? p.tactic_chosen : null,
    proof_state_after: typeof p.proof_state_after === 'string' ? p.proof_state_after : null,
    tactic_success: p.tactic_success,
    tactics_rejected,
    premises_used,
    premises_available,
    confidence: confidenceVal,
    time_to_decision_ms: time_ms_val,
    hints_used_this_step: hints_used,
    hint_content: typeof p.hint_content === 'string' ? p.hint_content : null,
    user_reasoning: typeof p.user_reasoning === 'string' ? p.user_reasoning : null,
    expert_explanation: typeof p.expert_explanation === 'string' ? p.expert_explanation : null,
    axle_endpoint: typeof p.axle_endpoint === 'string' ? p.axle_endpoint : null,
    axle_response_ok: typeof p.axle_response_ok === 'boolean' ? p.axle_response_ok : null,
    axle_duration_ms: axle_ms_val,
    axle_error_message: typeof p.axle_error_message === 'string' ? p.axle_error_message : null,
    step_number: Math.trunc(p.step_number as number),
    total_steps: total_steps_val,
    difficulty_rating: difficulty_val,
    topic_tags,
    dimension: typeof p.dimension === 'string' ? p.dimension : null,
    dataset_label: typeof p.dataset_label === 'string' ? p.dataset_label : null,
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const rawPackets = body?.packets
    if (!Array.isArray(rawPackets) || rawPackets.length === 0) {
      return NextResponse.json({ error: 'Expected non-empty packets array' }, { status: 400 })
    }

    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()
    const userId = user?.id ?? null

    const rows: Record<string, unknown>[] = []
    for (const raw of rawPackets) {
      const row = coercePacket(raw, userId)
      if (!row) {
        return NextResponse.json({ error: 'Invalid packet in batch' }, { status: 400 })
      }
      rows.push(row)
    }

    const levelNums = Array.from(
      new Set(
        rows
          .map(r => parseInt(String(r.level_id), 10))
          .filter(n => Number.isFinite(n) && n > 0)
      )
    )

    let completedLevelIds = new Set<number>()
    if (userId && levelNums.length > 0) {
      const { data: doneRows } = await supabase
        .from('level_completions')
        .select('level_id')
        .eq('user_id', userId)
        .in('level_id', levelNums)

      completedLevelIds = new Set((doneRows || []).map(r => r.level_id as number))
    }

    for (const row of rows) {
      const lid = parseInt(String(row.level_id), 10)
      if (userId && Number.isFinite(lid) && lid > 0) {
        const prev = completedLevelIds.has(lid) ? 1 : 0
        row.is_first_attempt = prev === 0
        row.previous_attempts_count = prev
      } else {
        row.is_first_attempt = true
        row.previous_attempts_count = 0
      }
    }

    const sanitized = rows.map(sanitizeInsertRow)

    const { error } = await supabase.from('proof_packets').insert(sanitized)

    if (error) {
      console.error('[proof-packets] insert failed', {
        message: error.message,
        code: error.code,
        details: error.details,
        hint: error.hint,
      })
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ ok: true, inserted: sanitized.length })
  } catch (err: unknown) {
    console.error('[proof-packets] POST exception', err)
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
