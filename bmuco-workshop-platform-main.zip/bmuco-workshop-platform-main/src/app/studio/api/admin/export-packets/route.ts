import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

type ProofPacketRow = {
  id: number
  created_at: string
  session_id: string
  user_id: string | null
  level_id: string
  world_id: number | null
  mode: string
  proof_state_before: string
  tactic_chosen: string | null
  proof_state_after: string | null
  tactic_success: boolean
  tactics_rejected: unknown
  premises_used: unknown
  premises_available: unknown
  difficulty_rating: number | null
  topic_tags: string[] | null
  dimension: string | null
  dataset_label: string | null
  expert_explanation: string | null
  user_reasoning: string | null
  is_first_attempt?: boolean | null
  previous_attempts_count?: number | null
}

const MODES = ['mcq', 'build', 'trace', 'review'] as const

async function requireAdmin() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return { supabase: null as ReturnType<typeof createClient> | null, error: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) }
  }
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()
  if (profile?.role !== 'admin') {
    return {
      supabase: null as ReturnType<typeof createClient> | null,
      error: NextResponse.json({ error: 'Forbidden — admin role required' }, { status: 403 }),
    }
  }
  return { supabase, error: null as NextResponse | null }
}

function parseSearchParams(req: Request) {
  const url = new URL(req.url)
  const p = url.searchParams
  return {
    stats: p.get('stats') === '1' || p.get('stats') === 'true',
    format: (p.get('format') || '').toLowerCase(),
    start: p.get('start')?.trim() || null,
    end: p.get('end')?.trim() || null,
    mode: p.get('mode')?.trim() || null,
    worldId: p.get('world_id')?.trim() || null,
    levelId: p.get('level_id')?.trim() || null,
    firstAttemptsOnly: p.get('first_attempts') === '1' || p.get('first_attempts') === 'true',
  }
}

function applyFilters<T extends { gte: Function; lte: Function; eq: Function }>(query: T, filters: ReturnType<typeof parseSearchParams>): T {
  let q = query
  if (filters.start) q = q.gte('created_at', filters.start) as T
  if (filters.end) q = q.lte('created_at', filters.end) as T
  if (filters.mode && filters.mode !== 'all') q = q.eq('mode', filters.mode) as T
  if (filters.worldId && filters.worldId !== 'all') {
    const w = parseInt(filters.worldId, 10)
    if (Number.isFinite(w)) q = q.eq('world_id', w) as T
  }
  if (filters.levelId) q = q.eq('level_id', filters.levelId) as T
  if (filters.firstAttemptsOnly) q = q.eq('is_first_attempt', true) as T
  return q
}

function asStringArray(v: unknown): string[] {
  if (Array.isArray(v)) return v.filter((x): x is string => typeof x === 'string')
  if (typeof v === 'string') {
    try {
      const j = JSON.parse(v) as unknown
      return Array.isArray(j) ? j.filter((x): x is string => typeof x === 'string') : []
    } catch {
      return []
    }
  }
  return []
}

type RejectedTactic = { tactic?: string; reason?: string; was_attempted?: boolean }

function asRejectedList(v: unknown): RejectedTactic[] {
  if (!Array.isArray(v)) return []
  return v.filter((x): x is RejectedTactic => x != null && typeof x === 'object')
}

function chosenReason(row: ProofPacketRow): string {
  return (
    row.expert_explanation?.trim() ||
    row.dataset_label?.trim() ||
    row.user_reasoning?.trim() ||
    ''
  )
}

function toFormatALine(row: ProofPacketRow): string | null {
  if (!row.tactic_success || !row.tactic_chosen?.trim()) return null
  const obj = {
    proof_state: row.proof_state_before,
    tactic: row.tactic_chosen,
    premises: asStringArray(row.premises_used),
    difficulty: row.difficulty_rating ?? null,
    topic: row.topic_tags ?? [],
  }
  return JSON.stringify(obj)
}

function toFormatBLines(row: ProofPacketRow): string[] {
  const chosen = row.tactic_chosen?.trim()
  if (!chosen) return []
  const rejected = asRejectedList(row.tactics_rejected).filter(r => r.tactic && r.tactic !== chosen)
  if (rejected.length === 0) return []
  const cr = chosenReason(row)
  const dim = row.dimension ?? ''
  return rejected.map(r =>
    JSON.stringify({
      proof_state: row.proof_state_before,
      chosen,
      rejected: r.tactic,
      chosen_reason: cr,
      rejected_reason: typeof r.reason === 'string' ? r.reason : '',
      dimension: dim,
    })
  )
}

function toFormatCLine(row: ProofPacketRow): string | null {
  const rel = asStringArray(row.premises_used)
  if (rel.length === 0) return null
  const obj = {
    proof_state: row.proof_state_before,
    relevant_premises: rel,
    all_premises_in_scope: asStringArray(row.premises_available),
    difficulty: row.difficulty_rating ?? null,
  }
  return JSON.stringify(obj)
}

async function fetchAllPackets(
  supabase: ReturnType<typeof createClient>,
  filters: ReturnType<typeof parseSearchParams>
): Promise<{ rows: ProofPacketRow[]; error: string | null }> {
  const pageSize = 1000
  const rows: ProofPacketRow[] = []
  let from = 0
  for (;;) {
    let q = supabase.from('proof_packets').select('*').order('id', { ascending: true })
    q = applyFilters(q, filters)
    const { data, error } = await q.range(from, from + pageSize - 1)
    if (error) return { rows: [], error: error.message }
    const batch = (data || []) as ProofPacketRow[]
    rows.push(...batch)
    if (batch.length < pageSize) break
    from += pageSize
    if (from > 500_000) break
  }
  return { rows, error: null }
}

export async function GET(req: Request) {
  const { supabase, error: authErr } = await requireAdmin()
  if (authErr || !supabase) return authErr!

  const filters = parseSearchParams(req)

  if (filters.stats) {
    let base = supabase.from('proof_packets').select('*', { count: 'exact', head: true })
    base = applyFilters(base, filters)
    const { count: total, error: e0 } = await base
    if (e0) return NextResponse.json({ error: e0.message }, { status: 500 })

    const by_mode: Record<string, number> = {}
    for (const m of MODES) {
      if (filters.mode && filters.mode !== 'all' && filters.mode !== m) {
        by_mode[m] = 0
        continue
      }
      let q = supabase.from('proof_packets').select('*', { count: 'exact', head: true }).eq('mode', m)
      const f = { ...filters, mode: null as string | null }
      q = applyFilters(q, f)
      const { count } = await q
      by_mode[m] = count ?? 0
    }

    const by_dimension: Record<string, number> = {}
    let dimQ = supabase.from('proof_packets').select('dimension')
    dimQ = applyFilters(dimQ, filters)
    const { data: dimRows, error: eDim } = await dimQ.limit(50_000)
    if (eDim) return NextResponse.json({ error: eDim.message }, { status: 500 })
    for (const r of dimRows || []) {
      const d = (r as { dimension: string | null }).dimension
      const key = d && d.trim() ? d.trim() : '(null)'
      by_dimension[key] = (by_dimension[key] ?? 0) + 1
    }

    return NextResponse.json({
      total: total ?? 0,
      by_mode,
      by_dimension,
    })
  }

  const fmt = filters.format
  if (!fmt || !['a', 'b', 'c', 'raw'].includes(fmt)) {
    return NextResponse.json({ error: 'Missing or invalid format (use a, b, c, raw, or stats=1)' }, { status: 400 })
  }

  const { rows, error: fetchErr } = await fetchAllPackets(supabase, filters)
  if (fetchErr) return NextResponse.json({ error: fetchErr }, { status: 500 })

  const date = new Date().toISOString().split('T')[0]

  if (fmt === 'raw') {
    return new NextResponse(JSON.stringify(rows, null, 2), {
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="proof-packets-raw-${date}.json"`,
      },
    })
  }

  const lines: string[] = []
  if (fmt === 'a') {
    for (const row of rows) {
      const line = toFormatALine(row)
      if (line) lines.push(line)
    }
  } else if (fmt === 'b') {
    for (const row of rows) {
      lines.push(...toFormatBLines(row))
    }
  } else if (fmt === 'c') {
    for (const row of rows) {
      const line = toFormatCLine(row)
      if (line) lines.push(line)
    }
  }

  const body = lines.join('\n') + (lines.length ? '\n' : '')
  const ext = 'jsonl'
  const label = fmt === 'a' ? 'tactic' : fmt === 'b' ? 'dpo' : 'premise'

  return new NextResponse(body, {
    headers: {
      'Content-Type': 'application/x-ndjson; charset=utf-8',
      'Content-Disposition': `attachment; filename="proof-packets-${label}-${date}.${ext}"`,
    },
  })
}
