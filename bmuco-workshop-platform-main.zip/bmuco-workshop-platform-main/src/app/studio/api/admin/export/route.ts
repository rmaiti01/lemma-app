import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function GET() {
  const supabase = createClient()

  // Verify admin role
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (profile?.role !== 'admin') {
    return NextResponse.json({ error: 'Forbidden — admin role required' }, { status: 403 })
  }

  // Fetch all traces with exercise data
  const { data: traces, error: tracesError } = await supabase
    .from('exercise_traces')
    .select('*')
    .in('status', ['submitted', 'reviewed'])
    .order('submitted_at', { ascending: true })

  if (tracesError) {
    return NextResponse.json({ error: tracesError.message }, { status: 500 })
  }

  // Fetch all exercises
  const { data: exercises } = await supabase
    .from('exercises')
    .select('*')

  const exerciseMap = new Map((exercises || []).map(e => [e.id, e]))

  // Fetch feedback
  const { data: feedbackList } = await supabase
    .from('exercise_feedback')
    .select('*')

  const feedbackMap = new Map((feedbackList || []).map(f => [f.trace_id, f]))

  // Transform into training data format
  const trainingData = (traces || []).map(trace => {
    const exercise = exerciseMap.get(trace.exercise_id)
    const feedback = feedbackMap.get(trace.id)

    return {
      theorem: {
        nl_statement: exercise?.nl_statement || '',
        nl_proof: exercise?.nl_proof || '',
        title: exercise?.title || '',
        difficulty: exercise?.difficulty || 0,
        week: exercise?.week || 0,
        category: exercise?.category || '',
      },
      human_process: {
        layer0_inventory: {
          objects: trace.layer0_objects || [],
          properties: trace.layer0_properties || [],
          hypotheses: trace.layer0_hypotheses || '',
          conclusion: trace.layer0_conclusion || '',
          search_log: trace.layer0_search_log || [],
        },
        layer1_type_reasoning: trace.layer1_generality_reasoning || '',
        layer1_type_choice: trace.layer1_type_choice || '',
        layer1_skeleton_code: trace.layer1_skeleton_code || '',
        layer2_naming_reasoning: trace.layer2_naming_reasoning || '',
        layer2_proposed_name: trace.layer2_proposed_name || '',
        layer3_witness_reasoning: trace.layer3_witness_reasoning || '',
        layer3_tactic_choices: trace.layer3_tactic_choices || [],
        layer4_culture_check: {
          exists_in_mathlib: trace.layer4_exists_in_mathlib,
          mathlib_name: trace.layer4_mathlib_name || '',
          generality_check: trace.layer4_generality_check || '',
          api_completeness: trace.layer4_api_completeness || '',
        },
      },
      code: {
        student_lean_code: trace.layer3_full_lean_code || '',
        student_statement: trace.layer2_full_statement || '',
        student_proof: trace.layer3_proof_code || '',
        reference_lean_code: exercise?.reference_lean_code || '',
        compiles: trace.layer3_compiles || false,
      },
      ai_review: exercise?.category === 'ai_review' ? {
        ai_code: exercise.ai_lean_code || '',
        ai_failure_modes: exercise.ai_failure_modes || [],
        identified_issues: trace.ai_review_identified_issues || [],
        corrected_code: trace.ai_review_corrected_code || '',
        correction_reasoning: trace.ai_review_reasoning || '',
      } : null,
      mentor_feedback: feedback ? {
        overall_score: feedback.overall_score,
        overall_feedback: feedback.overall_feedback,
        ready_for_pr: feedback.ready_for_pr,
        layer_scores: {
          layer0: feedback.layer0_score,
          layer1: feedback.layer1_score,
          layer2: feedback.layer2_score,
          layer3: feedback.layer3_score,
          layer4: feedback.layer4_score,
        },
      } : null,
      metadata: {
        time_spent_minutes: trace.time_spent_minutes || 0,
        difficulty: exercise?.difficulty || 0,
        started_at: trace.started_at,
        submitted_at: trace.submitted_at,
        status: trace.status,
      },
    }
  })

  return new NextResponse(JSON.stringify(trainingData, null, 2), {
    headers: {
      'Content-Type': 'application/json',
      'Content-Disposition': `attachment; filename="lemma-traces-${new Date().toISOString().split('T')[0]}.json"`,
    },
  })
}
