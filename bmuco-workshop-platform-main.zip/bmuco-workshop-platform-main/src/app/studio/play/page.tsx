import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import WorldMap from '@/components/game/WorldMap'
import PlayerStats from '@/components/game/PlayerStats'
import {
  getAllWorlds,
  getPlayerProgress,
  getLevelCompletions,
  getWorld1Levels,
  getUserLeaderboardRank,
} from '@/lib/game-data'
import { createClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'

export default async function PlayPage() {
  let user = null
  let worlds: Awaited<ReturnType<typeof getAllWorlds>> = []
  let completions: Awaited<ReturnType<typeof getLevelCompletions>> = []
  let progress: Awaited<ReturnType<typeof getPlayerProgress>> = null
  let rank: number | null = null
  let levelCounts: Record<number, number> = {}

  try {
    const supabase = createClient()
    const { data } = await supabase.auth.getUser()
    user = data?.user ?? null

    worlds = await getAllWorlds()
    const levels = await getWorld1Levels()
    levelCounts[1] = levels.length

    if (user) {
      progress = await getPlayerProgress(user.id)
      completions = await getLevelCompletions(user.id)
      rank = await getUserLeaderboardRank(user.id)
    }
  } catch {
    // DB not set up yet
  }

  return (
    <div className="page-content">
      <Navbar />

      <section style={{ maxWidth: 720, margin: '0 auto', padding: '40px 24px 64px' }}>
        <div style={{ marginBottom: 32 }}>
          <h1 style={{ fontSize: 32, fontWeight: 700, marginBottom: 8 }}>
            Worlds
          </h1>
          <p style={{ fontSize: 14, color: 'var(--color-text-secondary)' }}>
            Finished the Natural Number Game? Now learn to review proofs like a Mathlib contributor.
            Progress through 7 worlds of increasing difficulty.
          </p>
        </div>

        {user && (
          <div style={{ marginBottom: 24 }}>
            <PlayerStats progress={progress} rank={rank} />
          </div>
        )}

        {worlds.length > 0 ? (
          <WorldMap worlds={worlds} completions={completions} levelCounts={levelCounts} />
        ) : (
          <div style={{
            textAlign: 'center',
            padding: 48,
            background: 'var(--color-surface)',
            borderRadius: 'var(--radius-lg)',
            border: '1px solid var(--color-border)',
            color: 'var(--color-text-secondary)',
          }}>
            Game data not loaded yet. Run the migration and seed script.
          </div>
        )}
      </section>

      <Footer />
    </div>
  )
}
