'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import LevelPlayer from '@/components/game/LevelPlayer'
import World2MCQMode from '@/components/game/World2MCQMode'
import type { GameLevel } from '@/lib/game-types'
import { WORLD_1_LEVELS } from '@/lib/world1-data'

const FIRST_FILL_IN_LEVEL_ID = WORLD_1_LEVELS[0]?.id ?? 'w1_l1'

type W2Mode = 'select' | 'mcq' | 'review'

interface WorldPlayClientProps {
  worldId: number
  levels: GameLevel[]
  userId: string | null
  completedLevelIds?: number[]
  initialLevelIndex?: number
  challengeBy?: string | null
}

const MODE_CARDS: Array<{
  id: W2Mode
  label: string
  title: string
  desc: string
  icon: string
  xp: number
  locked?: boolean
  lockMsg?: string
  prereq?: W2Mode
}> = [
  {
    id: 'mcq',
    label: 'MCQ',
    title: 'Issue Recognition',
    desc: 'For each claim, decide: real issue or decoy?',
    icon: '?',
    xp: 10,
  },
  {
    id: 'review',
    label: 'REVIEW',
    title: 'Spot the Issues',
    desc: "Find what's wrong with these Mathlib-violating proofs.",
    icon: '!',
    xp: 25,
    prereq: 'mcq',
  },
]

export default function WorldPlayClient({
  worldId,
  levels,
  userId,
  completedLevelIds = [],
  initialLevelIndex = 0,
  challengeBy = null,
}: WorldPlayClientProps) {
  const router = useRouter()
  const safeInitial =
    initialLevelIndex >= 0 && initialLevelIndex < levels.length ? initialLevelIndex : 0
  const [currentIndex, setCurrentIndex] = useState(safeInitial)
  const [localCompleted, setLocalCompleted] = useState<Set<number>>(new Set(completedLevelIds))
  const [mode, setMode] = useState<W2Mode>('select')
  const [mcqDone, setMcqDone] = useState(false)
  const level = levels[currentIndex]
  const isLast = currentIndex >= levels.length - 1

  useEffect(() => {
    const next =
      initialLevelIndex >= 0 && initialLevelIndex < levels.length ? initialLevelIndex : 0
    setCurrentIndex(next)
  }, [initialLevelIndex, levels.length, worldId])

  // Reset mode when switching levels
  useEffect(() => {
    setMode('select')
    setMcqDone(false)
  }, [currentIndex])

  /** World 1 bridge (MCQ smell-test → fill-in-the-blank) */
  const bridgeMcqToFillIn = () => {
    router.push(`/studio/worlds/1/levels/${FIRST_FILL_IN_LEVEL_ID}?mode=build`)
  }

  const handleNextLevel = () => {
    setLocalCompleted(prev => new Set(prev).add(level.id))
    if (worldId === 1) {
      const afterSmellTestRun = level.level_number === 6 || isLast
      if (afterSmellTestRun) {
        bridgeMcqToFillIn()
        return
      }
    }
    if (!isLast) {
      setCurrentIndex(prev => prev + 1)
    }
  }

  const showNextButton = !isLast || (worldId === 1 && isLast)
  const nextLevelLabel =
    worldId === 1 && (level.level_number === 6 || isLast)
      ? 'Continue to fill-in proofs →'
      : isLast
        ? undefined
        : levels[currentIndex + 1]?.is_boss
          ? 'Boss Level'
          : `Level ${levels[currentIndex + 1]?.level_number}`

  // World 1 — no mode selector, just LevelPlayer as before
  if (worldId === 1) {
    return (
      <div>
        {challengeBy != null && challengeBy !== '' && (
          <ChallengeBar challengeBy={challengeBy} />
        )}
        <LevelSelector
          levels={levels}
          currentIndex={currentIndex}
          localCompleted={localCompleted}
          onSelect={setCurrentIndex}
        />
        <LevelPlayer
          key={level.id}
          level={level}
          isBoss={level.is_boss}
          userId={userId}
          onNextLevel={showNextButton ? handleNextLevel : undefined}
          nextLevelLabel={showNextButton ? nextLevelLabel : undefined}
        />
      </div>
    )
  }

  // World 2+ — mode selector
  const isReviewUnlocked = mcqDone

  return (
    <div>
      {challengeBy != null && challengeBy !== '' && (
        <ChallengeBar challengeBy={challengeBy} />
      )}

      <LevelSelector
        levels={levels}
        currentIndex={currentIndex}
        localCompleted={localCompleted}
        onSelect={setCurrentIndex}
      />

      {/* Mode selector */}
      {mode === 'select' && (
        <div className="w2-mode-grid">
          {MODE_CARDS.map(card => {
            const locked = card.prereq === 'mcq' && !mcqDone
            return (
              <button
                key={card.id}
                type="button"
                className="w2-mode-card"
                disabled={locked}
                onClick={() => !locked && setMode(card.id)}
                style={{
                  borderRadius: 8,
                  border: `1px solid ${locked ? 'rgba(148,163,184,0.35)' : 'var(--color-border)'}`,
                  background: locked ? 'var(--color-surface-raised)' : 'var(--color-surface)',
                  opacity: locked ? 0.62 : 1,
                  cursor: locked ? 'not-allowed' : 'pointer',
                  padding: '20px 18px',
                  textAlign: 'left',
                  transition: 'all 150ms',
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <span style={{ fontSize: 13, fontWeight: 700, letterSpacing: '0.06em', color: locked ? 'var(--color-text-muted)' : 'var(--color-text)' }}>
                    {locked ? '🔒' : card.icon} {card.label}
                  </span>
                  <span style={{
                    fontSize: 11,
                    fontWeight: 600,
                    padding: '2px 8px',
                    borderRadius: 4,
                    background: card.id === 'review' ? 'rgba(232,175,52,0.14)' : 'rgba(232,175,52,0.08)',
                    color: 'var(--color-text-muted)',
                  }}>
                    +{card.xp} XP
                  </span>
                </div>
                <div style={{ fontSize: 15, fontWeight: 600, color: locked ? 'var(--color-text-muted)' : 'var(--color-text)', marginBottom: 4 }}>
                  {card.title}
                </div>
                <div style={{ fontSize: 13, color: 'var(--color-text-secondary)', lineHeight: 1.5 }}>
                  {card.desc}
                </div>
                {locked && (
                  <div style={{ fontSize: 11, color: 'var(--color-text-muted)', marginTop: 8 }}>
                    Complete MCQ first to unlock
                  </div>
                )}
              </button>
            )
          })}

          <style jsx>{`
            .w2-mode-grid {
              display: grid;
              grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
              gap: 12px;
              margin-bottom: 24px;
            }
            .w2-mode-card:hover:not(:disabled) {
              border-color: var(--color-primary) !important;
            }
            @media (max-width: 520px) {
              .w2-mode-grid {
                grid-template-columns: 1fr;
              }
            }
          `}</style>
        </div>
      )}

      {/* Back button when in a mode */}
      {mode !== 'select' && (
        <button
          onClick={() => setMode('select')}
          style={{
            background: 'none',
            border: 'none',
            color: 'var(--color-text-muted)',
            fontSize: 13,
            cursor: 'pointer',
            marginBottom: 16,
            padding: '4px 0',
          }}
        >
          &larr; Back to mode select
        </button>
      )}

      {/* MCQ mode */}
      {mode === 'mcq' && (
        <World2MCQMode
          key={`mcq-${level.id}`}
          level={level}
          userId={userId}
          onComplete={() => {
            setMcqDone(true)
            setMode('select')
          }}
        />
      )}

      {/* Review mode */}
      {mode === 'review' && (
        <LevelPlayer
          key={`review-${level.id}`}
          level={level}
          isBoss={level.is_boss}
          userId={userId}
          onNextLevel={showNextButton ? handleNextLevel : undefined}
          nextLevelLabel={showNextButton ? nextLevelLabel : undefined}
        />
      )}
    </div>
  )
}

/** Level pill selector */
function LevelSelector({
  levels,
  currentIndex,
  localCompleted,
  onSelect,
}: {
  levels: GameLevel[]
  currentIndex: number
  localCompleted: Set<number>
  onSelect: (i: number) => void
}) {
  return (
    <div style={{ display: 'flex', gap: 6, marginBottom: 32, flexWrap: 'wrap' }}>
      {levels.map((l, i) => {
        const done = localCompleted.has(l.id)
        return (
          <button
            key={l.id}
            onClick={() => onSelect(i)}
            style={{
              padding: '8px 16px',
              fontSize: 13,
              fontWeight: i === currentIndex ? 600 : 500,
              border: '1px solid',
              borderColor: i === currentIndex ? '#3b82f6' : done ? 'rgba(59, 130, 246, 0.4)' : 'var(--color-border)',
              borderRadius: 6,
              background: i === currentIndex ? 'rgba(59, 130, 246, 0.08)' : done ? 'rgba(59, 130, 246, 0.04)' : 'var(--color-surface)',
              color: i === currentIndex ? '#3b82f6' : done ? '#3b82f6' : 'var(--color-text-secondary)',
              cursor: 'pointer',
              transition: 'all 150ms',
              display: 'inline-flex',
              alignItems: 'center',
              gap: 4,
            }}
          >
            {done && <span style={{ fontSize: 11 }}>&#x2713;</span>}
            {l.is_boss ? 'Boss' : `${l.level_number}`}
          </button>
        )
      })}
    </div>
  )
}

/** Challenge banner */
function ChallengeBar({ challengeBy }: { challengeBy: string }) {
  return (
    <div
      role="status"
      style={{
        marginBottom: 20,
        padding: '14px 18px',
        borderRadius: 'var(--radius-md)',
        background: 'rgba(59, 130, 246, 0.08)',
        border: '1px solid rgba(59, 130, 246, 0.28)',
        fontSize: 14,
        color: 'var(--color-text-secondary)',
        lineHeight: 1.5,
      }}
    >
      <strong style={{ color: 'var(--color-text)' }}>{challengeBy}</strong> challenged you to beat
      their score on this level. Good luck!
    </div>
  )
}
