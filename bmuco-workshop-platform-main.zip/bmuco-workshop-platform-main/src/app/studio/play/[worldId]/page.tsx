import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import WorldPlayClient from './WorldPlayClient'
import { getWorldLevels, getAllWorlds, getLevelCompletions } from '@/lib/game-data'
import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'

export const dynamic = 'force-dynamic'

export default async function WorldPlayPage({
  params,
  searchParams,
}: {
  params: { worldId: string }
  searchParams?: { challenge?: string; level?: string; by?: string }
}) {
  const worldId = parseInt(params.worldId, 10)
  let user = null
  let levels: Awaited<ReturnType<typeof getWorldLevels>> = []
  let worlds: Awaited<ReturnType<typeof getAllWorlds>> = []
  let world = null
  let completedLevelIds: number[] = []

  try {
    const supabase = createClient()
    const { data } = await supabase.auth.getUser()
    user = data?.user ?? null

    levels = await getWorldLevels(worldId)
    worlds = await getAllWorlds()
    world = worlds.find(w => w.id === worldId) ?? null
    if (user) {
      const completions = await getLevelCompletions(user.id)
      completedLevelIds = completions.map(c => c.level_id)
    }
  } catch {
    // DB not set up
  }

  const challengeOn = searchParams?.challenge === 'true'
  const levelParam = searchParams?.level != null ? parseInt(String(searchParams.level), 10) : NaN
  const challengeByRaw = searchParams?.by?.trim()
  const challengeBy = challengeOn
    ? (() => {
        if (!challengeByRaw) return 'Someone'
        try {
          return decodeURIComponent(challengeByRaw)
        } catch {
          return challengeByRaw
        }
      })()
    : null

  let initialLevelIndex = 0
  if (Number.isFinite(levelParam) && levelParam > 0) {
    const idx = levels.findIndex(l => l.level_number === levelParam)
    if (idx >= 0) initialLevelIndex = idx
  }

  if (!world || levels.length === 0) {
    const hasWorldNoLevels = world != null && levels.length === 0
    return (
      <div className="page-content">
        <Navbar />
        <section style={{ maxWidth: 720, margin: '0 auto', padding: '80px 24px', textAlign: 'center' }}>
          <h1 style={{ fontSize: 28, marginBottom: 16 }}>
            {hasWorldNoLevels ? 'Levels not loaded' : 'World not found'}
          </h1>
          <p style={{ color: 'var(--color-text-secondary)', marginBottom: 24, lineHeight: 1.6 }}>
            {hasWorldNoLevels
              ? 'This world exists in the database but has no game_levels rows. Apply the latest Supabase migrations (World 2 is seeded in 011 / 013) or run: npx tsx src/scripts/seed-worlds.ts'
              : 'This world doesn&apos;t exist yet, or the database isn&apos;t reachable.'}
          </p>
          <Link href="/studio/worlds" className="btn btn-primary">Back to Worlds</Link>
        </section>
        <Footer />
      </div>
    )
  }

  return (
    <div className="page-content">
      <Navbar />
      <section style={{ maxWidth: 760, margin: '0 auto', padding: '40px 24px 64px' }}>
        <div style={{ marginBottom: 8 }}>
          <Link href="/studio/worlds" style={{ fontSize: 13, color: 'var(--color-text-muted)', textDecoration: 'none' }}>
            &larr; All Worlds
          </Link>
        </div>
        <div style={{ marginBottom: 32 }}>
          <span style={{ fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', color: '#3b82f6' }}>
            World {world.id}
          </span>
          <h1 style={{ fontSize: 32, fontWeight: 700, marginTop: 4, marginBottom: 8 }}>
            {world.name}
          </h1>
          <p style={{ fontSize: 14, color: 'var(--color-text-secondary)' }}>
            {world.description}
          </p>
        </div>

        <WorldPlayClient
          worldId={worldId}
          levels={levels}
          userId={user?.id ?? null}
          completedLevelIds={completedLevelIds}
          initialLevelIndex={initialLevelIndex}
          challengeBy={challengeBy}
        />
      </section>
      <Footer />
    </div>
  )
}
