import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import Link from 'next/link'

export const dynamic = 'force-dynamic'

export default function HomePage() {
  return (
    <div className="page-content">
      <Navbar />

      {/* Hero */}
      <section
        className="hero hero--mathy"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 48,
          textAlign: 'center',
          paddingBottom: 32,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ maxWidth: 620 }}>
          <h1 style={{ fontSize: 40, margin: '0 auto' }}>
            Can you spot what&apos;s wrong with this proof in Lean?
          </h1>
          <p className="hero-sub" style={{ maxWidth: 520, margin: '16px auto 0' }}>
            Proofs that compile aren&apos;t always correct. Sharpen your proof review skills
            and level up from the Natural Number Game to Mathlib-ready contributions.
          </p>
          <div style={{ marginTop: 28, display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/studio/worlds" className="btn btn-primary btn-lg">
              Play Now &rarr;
            </Link>
          </div>
        </div>
        <div className="hero-symbol" aria-hidden="true">
          &#x2200;
        </div>
      </section>

      {/* How it works */}
      <section style={{ maxWidth: 860, margin: '0 auto', padding: '0 24px 56px' }}>
        <h2 style={{ fontSize: 26, textAlign: 'center', marginBottom: 32 }}>
          Four modes. One mission: proof literacy.
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 20 }}>
          {[
            { icon: '?', title: 'MCQ', desc: 'Recognise the right tactic from four choices. Build intuition before you type.' },
            { icon: '[ ]', title: 'Build', desc: 'Fill in missing tactics in a real Lean skeleton. Every blank is checked by Axiom.' },
            { icon: '\u{1f52c}', title: 'Trace', desc: 'Walk through a completed proof step-by-step. Annotate every decision.' },
            { icon: '!', title: 'Review', desc: 'Spot redundancies and errors in a bloated proof. Think like a Mathlib reviewer.' },
          ].map(m => (
            <div
              key={m.title}
              style={{
                background: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-lg)',
                padding: '20px 18px',
                textAlign: 'center',
              }}
            >
              <div style={{ fontSize: 28, marginBottom: 8 }}>{m.icon}</div>
              <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 6 }}>{m.title}</h3>
              <p style={{ fontSize: 13, color: 'var(--color-text-secondary)', margin: 0, lineHeight: 1.5 }}>
                {m.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Journey section */}
      <section className="feature-section" style={{ textAlign: 'center' }}>
        <div className="container">
          <h2 style={{ fontSize: 28 }}>7 worlds. 50+ levels. One mission.</h2>
          <p style={{ maxWidth: 520, margin: '12px auto 16px', color: 'var(--color-text-secondary)' }}>
            Progress from spotting surface-level red flags to conducting full Mathlib-standard reviews.
            Bridge the gap between the Natural Number Game and real library contributions.
          </p>
          <p style={{ maxWidth: 520, margin: '0 auto 32px', color: 'var(--color-text-secondary)', fontSize: 14 }}>
            Every proof you review generates research-grade annotation data. You&apos;re not just
            learning &mdash; you&apos;re helping build the next generation of formal verification tools.
          </p>
          <Link href="/studio/worlds" className="btn btn-primary btn-lg">
            Explore All Worlds &rarr;
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  )
}
