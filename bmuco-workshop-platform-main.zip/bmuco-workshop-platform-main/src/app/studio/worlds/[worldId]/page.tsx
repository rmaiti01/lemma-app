import { redirect } from 'next/navigation'

/**
 * /studio/worlds/1 is handled by the static worlds/1 route (redirects to fill-in lobby).
 * Other worlds: World 2 MCQ play lives at /studio/play/[worldId].
 */
export default function StudioWorldsWorldIdPage({
  params,
}: {
  params: { worldId: string }
}) {
  const id = params.worldId
  if (id === '1') redirect('/studio/world/1')
  if (id === '2') redirect('/studio/play/2')

  redirect('/studio/worlds')
}
