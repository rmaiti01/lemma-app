import { notFound, redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { getW1Level, getW1LevelByNumber } from '@/lib/world1-data'
import ModeLevelClient from './ModeLevelClient'

interface Props {
  params: {
    worldId: string
    levelId: string
  }
  searchParams?: {
    mode?: string
  }
}

export default async function WorldLevelModePage({ params, searchParams }: Props) {
  if (params.worldId !== '1') notFound()
  const numericLevel = Number(params.levelId)
  const levelFromId = getW1Level(params.levelId)
  const levelFromNumber = Number.isFinite(numericLevel)
    ? getW1LevelByNumber(numericLevel)
    : undefined
  const level = levelFromId || levelFromNumber
  if (!level || level.locked) notFound()
  const mode = searchParams?.mode
  const validMode = mode === 'mcq' || mode === 'build' || mode === 'review' || mode === 'trace'
  if (!validMode) redirect(`/studio/worlds/${params.worldId}/levels/${level.id}?mode=mcq`)

  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  return <ModeLevelClient worldId={params.worldId} level={level} userId={user?.id ?? null} />
}
