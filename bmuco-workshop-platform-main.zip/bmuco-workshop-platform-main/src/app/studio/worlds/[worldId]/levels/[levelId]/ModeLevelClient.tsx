'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { BMUCO_LOG } from '@/lib/logger'
import type { W1Level } from '@/lib/world1-data'
import MCQMode from '@/components/game/MCQMode'
import ReviewMode from '@/components/game/ReviewMode'
import TraceMode from '@/components/game/TraceMode'
import { useLevelState } from '@/hooks/useLevelState'
import LevelLayout from '@/components/world1/LevelLayout'
import LevelSessionBar from '@/components/world1/LevelSessionBar'
import { flush } from '@/lib/logger'

type ModeId = 'mcq' | 'build' | 'review' | 'trace'

interface ModeLevelClientProps {
  worldId: string
  level: W1Level
  userId: string | null
}

const CARD_STYLES: Record<ModeId, { label: string; title: string; desc: string; icon: string; prereq?: ModeId }> = {
  mcq: {
    label: 'MCQ',
    title: 'Tactic Recognition',
    desc: 'Pick the right move. No typing required.',
    icon: '?',
  },
  build: {
    label: 'BUILD',
    title: 'Fill in the Proof',
    desc: 'Type the missing tactics into the skeleton.',
    icon: '[ ]',
    prereq: 'mcq',
  },
  trace: {
    label: 'TRACE',
    title: 'Expert Auditor',
    desc: 'Justify every decision. Earns the most XP.',
    icon: '🔬',
    prereq: 'build',
  },
  review: {
    label: 'REVIEW',
    title: 'Spot the Issues',
    desc: "Find what's wrong with this bloated proof.",
    icon: '!',
    prereq: 'build',
  },
}

const CARD_XP: Record<ModeId, number> = {
  mcq: 10,
  build: 25,
  review: 20,
  trace: 50,
}

const WORLD_LABEL: Record<string, string> = {
  '1': 'WORLD 1 — NATURAL NUMBERS',
}

function BuildMode({
  levelId,
  userId,
  bindExitSave,
}: {
  levelId: string
  userId: string | null
  bindExitSave: (fn: (() => Promise<void>) | null) => void
}) {
  const state = useLevelState(levelId, userId)
  const router = useRouter()

  const savePartialExit = state?.savePartialExit
  useEffect(() => {
    if (!savePartialExit) {
      bindExitSave(null)
      return
    }
    bindExitSave(() => savePartialExit())
    return () => bindExitSave(null)
  }, [savePartialExit, bindExitSave])

  if (!state) return null
  return (
    <LevelLayout
      state={state}
      onNextLevel={() => router.push('?mode=trace', { scroll: false })}
    />
  )
}

export default function ModeLevelClient({ worldId, level, userId }: ModeLevelClientProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const mode = (searchParams.get('mode') ?? 'mcq') as ModeId
  const [completedModes, setCompletedModes] = useState<string[]>([])
  const [exiting, setExiting] = useState(false)
  const exitSaveRef = useRef<(() => Promise<void>) | null>(null)

  const bindExitSave = useCallback((fn: (() => Promise<void>) | null) => {
    exitSaveRef.current = fn
  }, [])

  const prereq: Record<string, string> = {
    build: 'mcq',
    review: 'build',
    trace: 'build',
  }
  const isUnlocked = (modeId: string) =>
    !prereq[modeId] || completedModes.includes(prereq[modeId])

  const gotoMode = (target: ModeId) => {
    if (!isUnlocked(target)) return
    router.push(`?mode=${target}`, { scroll: false })
  }

  const levelSelectHref = `/studio/worlds/${worldId}/levels/${level.id}`
  const worldLabel = WORLD_LABEL[worldId] ?? `WORLD ${worldId}`

  const handleExit = async () => {
    setExiting(true)
    try {
      const saver = exitSaveRef.current
      if (saver) await saver()
      await flush(level.id)
    } finally {
      router.push(levelSelectHref)
      setExiting(false)
    }
  }

  useEffect(() => {
    if (mode !== 'mcq' && mode !== 'build' && mode !== 'review' && mode !== 'trace') {
      router.replace('?mode=mcq')
    }
  }, [mode, router])

  useEffect(() => {
    const syncCompletedModes = () => {
      const done = BMUCO_LOG
        .filter(entry => entry.level_id === level.id && entry.event === 'level_submitted')
        .map(entry => {
          const value = entry.value as { mode?: string } | null
          return value?.mode || ''
        })
        .filter(Boolean)
      setCompletedModes(Array.from(new Set(done)))
    }

    syncCompletedModes()
    const timer = window.setInterval(syncCompletedModes, 1000)
    return () => window.clearInterval(timer)
  }, [level.id])

  useEffect(() => {
    const onBeforeUnload = () => {
      void flush(level.id, { keepalive: true })
    }
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => window.removeEventListener('beforeunload', onBeforeUnload)
  }, [level.id])

  const renderShell = (modeContent: JSX.Element) => (
    <div className="page-content" style={{ padding: '24px' }}>
      <div style={{ maxWidth: 980, margin: '0 auto' }}>
        <LevelSessionBar
          worldId={worldId}
          levelId={level.id}
          worldLabel={worldLabel}
          onExit={handleExit}
          exiting={exiting}
        />
        <h1 style={{ fontSize: 28, marginBottom: 6 }}>{level.theorem}</h1>
        <p style={{ marginBottom: 16 }}>{level.informalProof.statement || 'Level mode selection'}</p>

        <div className="mode-select-grid">
          {(['mcq', 'build', 'trace', 'review'] as ModeId[]).map(id => {
            const card = CARD_STYLES[id]
            const unlocked = isUnlocked(id)
            return (
              <button
                key={id}
                type="button"
                className="mode-select-card"
                onClick={() => gotoMode(id)}
                title={unlocked ? `${card.title}` : `Complete ${prereq[id] === 'mcq' ? 'MCQ' : 'Build'} first to unlock`}
                style={{
                  borderRadius: 8,
                  border: `1px solid ${unlocked ? 'var(--color-border)' : 'rgba(148,163,184,0.35)'}`,
                  background: mode === id ? 'rgba(59,130,246,0.08)' : unlocked ? 'var(--color-surface)' : 'var(--color-surface-raised)',
                  opacity: unlocked ? 1 : 0.62,
                  cursor: unlocked ? 'pointer' : 'not-allowed',
                }}
              >
                <div className="mode-select-head-desktop">
                  <div className="mode-select-label-row">
                    {unlocked ? card.icon : '🔒'} {card.label}
                  </div>
                  <span
                    className="mode-select-xp-badge"
                    style={{
                      background: id === 'trace' ? 'rgba(232,175,52,0.14)' : 'rgba(232,175,52,0.08)',
                    }}
                  >
                    +{CARD_XP[id]} XP
                  </span>
                </div>
                <div className="mode-select-card-subtitle">{card.title}</div>
                <div className="mode-select-card-desc">{card.desc}</div>
                {!unlocked && (
                  <div className="mode-select-locked-hint">
                    Complete {prereq[id] === 'mcq' ? 'MCQ' : 'Build'} first to unlock
                  </div>
                )}
              </button>
            )
          })}
        </div>

        {modeContent}
      </div>
    </div>
  )

  if (mode === 'mcq')
    return renderShell(<MCQMode level={level} bindExitSave={bindExitSave} />)
  if (mode === 'build')
    return renderShell(<BuildMode levelId={level.id} userId={userId} bindExitSave={bindExitSave} />)
  if (mode === 'review')
    return renderShell(<ReviewMode level={level} worldId={worldId} bindExitSave={bindExitSave} />)
  if (mode === 'trace')
    return renderShell(<TraceMode levelId={level.id} bindExitSave={bindExitSave} />)

  router.replace('?mode=mcq')
  return null
}
