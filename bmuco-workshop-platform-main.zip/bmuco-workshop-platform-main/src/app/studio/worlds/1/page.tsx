import { redirect } from 'next/navigation'

/** Canonical world 1 route lives at /studio/world/1; this URL is used by onboarding CTAs. */
export default function WorldsWorld1RedirectPage() {
  redirect('/studio/world/1')
}
