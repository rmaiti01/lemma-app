"use client"

import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import Link from 'next/link'
import { Lock } from 'lucide-react'

const worlds: Array<{
  id: number
  name: string
  description: string
  levels: number
  unlocked: boolean
  /** Review worlds use /studio/play/[id]; World 1 meta-trap uses /studio/world/1 */
  href?: string
}> = [
  {
    id: 1,
    name: 'The Meta-Proof Trap',
    description:
      'Fill in Lean proof steps and decide if informal proofs are valid. Not all of them are.',
    levels: 8,
    unlocked: true,
    href: '/studio/world/1',
  },
  {
    id: 2,
    name: 'Style Police',
    description:
      'Proofs that compile but violate Mathlib conventions. Naming, generality, tactic choice — spot what a reviewer would reject.',
    levels: 6,
    unlocked: true,
    href: '/studio/worlds/2',
  },
  {
    id: 3,
    name: 'The Specification Game',
    description:
      'Write formal specifications that match informal requirements — and catch the mismatches.',
    levels: 8,
    unlocked: false,
  },
  {
    id: 4,
    name: 'Induction Lab',
    description:
      'Prove properties by induction, from simple base cases to nested structural recursion.',
    levels: 8,
    unlocked: false,
  },
  {
    id: 5,
    name: 'Library Archaeology',
    description:
      'Navigate Mathlib to find lemmas, understand naming conventions, and chain library results.',
    levels: 8,
    unlocked: false,
  },
  {
    id: 6,
    name: 'Proof Refactoring',
    description:
      'Take working but messy proofs and refactor them to Mathlib contribution standards.',
    levels: 8,
    unlocked: false,
  },
  {
    id: 7,
    name: 'The Contribution',
    description: 'Combine everything to write a real Mathlib-quality proof from scratch.',
    levels: 6,
    unlocked: false,
  },
]

export default function WorldsPage() {
  return (
    <div className="page-content">
      <Navbar />

      <section style={{ maxWidth: 720, margin: '0 auto', padding: '40px 24px 64px' }}>
        <div style={{ marginBottom: 32 }}>
          <div
            style={{
              fontSize: 11,
              fontWeight: 600,
              textTransform: 'uppercase',
              letterSpacing: '0.08em',
              color: 'var(--color-primary)',
              marginBottom: 6,
            }}
          >
            Lemma
          </div>
          <h1 style={{ fontSize: 32, fontWeight: 700, marginBottom: 8 }}>Worlds</h1>
          <p style={{ fontSize: 14, color: 'var(--color-text-secondary)', lineHeight: 1.7 }}>
            Progress from spotting surface-level red flags to conducting full Mathlib-standard reviews.
            7 worlds, 50+ levels, one mission.
          </p>
        </div>

        <div className="worlds-mathy-list" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {worlds.map(world => {
            const inner = (
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 20,
                  padding: '20px 24px',
                  background: world.unlocked ? 'var(--color-surface)' : 'var(--color-surface-raised)',
                  border: `1px solid ${world.unlocked ? 'var(--color-primary)' : 'var(--color-border)'}`,
                  borderRadius: 'var(--radius-lg)',
                  opacity: world.unlocked ? 1 : 0.65,
                  transition: 'border-color var(--transition-fast), transform var(--transition-fast), box-shadow var(--transition-fast)',
                  cursor: world.unlocked ? 'pointer' : 'default',
                  textDecoration: 'none',
                  color: 'inherit',
                }}
                className={world.unlocked ? 'world-card-unlocked' : undefined}
              >
                {/* World number */}
                <div
                  style={{
                    width: 48,
                    height: 48,
                    borderRadius: 'var(--radius-lg)',
                    background: world.unlocked
                      ? 'rgba(59, 130, 246, 0.1)'
                      : 'var(--color-surface-hover)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                    fontSize: 20,
                    fontWeight: 800,
                    color: world.unlocked ? 'var(--color-primary)' : 'var(--color-text-muted)',
                  }}
                >
                  {world.unlocked ? world.id : <Lock size={20} />}
                </div>

                {/* Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                    <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--color-text)' }}>
                      World {world.id}: {world.name}
                    </span>
                    {!world.unlocked && (
                      <span
                        style={{
                          fontSize: 10,
                          fontWeight: 600,
                          textTransform: 'uppercase',
                          letterSpacing: '0.05em',
                          color: 'var(--color-text-muted)',
                          background: 'var(--color-surface-hover)',
                          padding: '2px 8px',
                          borderRadius: 'var(--radius-sm)',
                        }}
                      >
                        Coming Soon
                      </span>
                    )}
                  </div>
                  <p
                    style={{
                      fontSize: 13,
                      color: 'var(--color-text-secondary)',
                      lineHeight: 1.5,
                      margin: 0,
                    }}
                  >
                    {world.description}
                  </p>
                </div>

                {/* Level count */}
                <div
                  style={{
                    fontSize: 12,
                    fontWeight: 600,
                    color: 'var(--color-text-muted)',
                    fontFamily: 'var(--font-mono)',
                    flexShrink: 0,
                  }}
                >
                  {world.levels} levels
                </div>
              </div>
            )

            if (world.unlocked && world.href) {
              return (
                <Link key={world.id} href={world.href} style={{ textDecoration: 'none', color: 'inherit' }}>
                  {inner}
                </Link>
              )
            }
            return <div key={world.id}>{inner}</div>
          })}
        </div>
      </section>

      <Footer />

      <style jsx>{`
        :global(.world-card-unlocked:hover) {
          border-color: var(--color-primary) !important;
          transform: translateY(-2px);
          box-shadow: var(--shadow-md) !important;
        }
      `}</style>
    </div>
  )
}
