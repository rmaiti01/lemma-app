import { redirect } from 'next/navigation'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import { createClient } from '@/lib/supabase/server'
import SettingsForm from './SettingsForm'

export default async function StudioSettingsPage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect('/studio/auth/sign-in?next=/studio/settings')
  }

  const { data: profile } = await supabase.from('profiles').select('username').eq('id', user.id).single()

  return (
    <div className="page-content">
      <Navbar />
      <section style={{ maxWidth: 720, margin: '0 auto', padding: '48px 24px 80px' }}>
        <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 32, fontWeight: 700, marginBottom: 8 }}>
          Profile
        </h1>
        <p style={{ fontSize: 14, color: 'var(--color-text-secondary)', marginBottom: 32 }}>
          Settings for your Lemma account.
        </p>
        <SettingsForm initialUsername={profile?.username ?? ''} />
      </section>
      <Footer />
    </div>
  )
}
