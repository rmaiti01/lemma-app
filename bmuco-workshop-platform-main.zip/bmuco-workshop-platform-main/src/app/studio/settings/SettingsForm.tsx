'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function SettingsForm({ initialUsername }: { initialUsername: string }) {
  const [username, setUsername] = useState(initialUsername)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const router = useRouter()

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    setMessage(null)
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      setMessage('Not signed in.')
      setSaving(false)
      return
    }
    const trimmed = username.trim()
    const { error } = await supabase.from('profiles').update({ username: trimmed || null }).eq('id', user.id)
    if (error) {
      setMessage(error.message)
    } else {
      setMessage('Saved.')
      router.refresh()
    }
    setSaving(false)
  }

  return (
    <form onSubmit={handleSave} style={{ maxWidth: 480, display: 'grid', gap: 16 }}>
      <div>
        <label className="form-label" htmlFor="username">
          Leaderboard display name
        </label>
        <input
          id="username"
          className="form-input"
          placeholder="Choose a display name (shown on leaderboard)"
          value={username}
          onChange={e => setUsername(e.target.value)}
          maxLength={64}
          autoComplete="nickname"
        />
        <p style={{ fontSize: 12, color: 'var(--color-text-muted)', marginTop: 8 }}>
          Until you set a name, the leaderboard shows &quot;Anonymous&quot;. We never show your email there.
        </p>
      </div>
      {message && (
        <p style={{ fontSize: 14, color: message.startsWith('Saved') ? 'var(--color-success)' : 'var(--color-error)' }}>
          {message}
        </p>
      )}
      <div style={{ display: 'flex', gap: 12 }}>
        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? 'Saving…' : 'Save'}
        </button>
        <Link href="/studio/play" className="btn btn-secondary" style={{ textDecoration: 'none', display: 'inline-flex', alignItems: 'center' }}>
          Back to play
        </Link>
      </div>
    </form>
  )
}
