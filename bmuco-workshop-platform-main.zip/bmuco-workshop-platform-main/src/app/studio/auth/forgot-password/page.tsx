'use client'

import { useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import { absoluteUrl } from '@/lib/site-url'
import { Mail, CheckCircle } from 'lucide-react'

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    const supabase = createClient()
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: absoluteUrl('/studio/auth/reset-password'),
    })

    if (error) {
      setError(error.message)
      setLoading(false)
      return
    }

    setSent(true)
    setLoading(false)
  }

  if (sent) {
    return (
      <div className="auth-container">
        <div className="auth-card" style={{ textAlign: 'center' }}>
          <CheckCircle size={48} color="#3b82f6" style={{ margin: '0 auto 16px' }} />
          <h2 style={{ fontSize: 'var(--text-xl)', marginBottom: 8 }}>Check your email</h2>
          <p style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-secondary)', marginBottom: 24 }}>
            We sent a password reset link to <strong>{email}</strong>.
          </p>
          <Link href="/studio/auth/sign-in" className="btn btn-secondary" style={{ width: '100%' }}>
            Back to Sign In
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-logo">
          <Link href="/studio" style={{ textDecoration: 'none', color: 'inherit' }}>Lemma</Link>
        </div>

        <h2 style={{ textAlign: 'center', fontSize: 'var(--text-xl)', marginBottom: '4px' }}>Reset your password</h2>
        <p style={{ textAlign: 'center', fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)', marginBottom: '32px' }}>
          Enter your email and we&apos;ll send you a reset link
        </p>

        <form onSubmit={handleReset} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div className="form-group">
            <label className="form-label" htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              className="form-input"
              placeholder="you@example.com"
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
          </div>

          {error && <p className="form-error">{error}</p>}

          <button type="submit" className="btn btn-primary" disabled={loading} style={{ width: '100%' }}>
            {loading ? 'Sending...' : 'Send Reset Link'}
            {!loading && <Mail size={16} />}
          </button>
        </form>

        <p style={{ textAlign: 'center', marginTop: '24px', fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)' }}>
          Remember your password? <Link href="/studio/auth/sign-in" style={{ color: 'var(--color-text)', fontWeight: 500 }}>Sign In</Link>
        </p>
      </div>
    </div>
  )
}
