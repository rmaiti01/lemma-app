import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'
import { sanitizeNextPath } from '@/lib/site-url'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const code = searchParams.get('code')
  const next = sanitizeNextPath(searchParams.get('next'), '/studio')
  const origin = new URL(request.url).origin

  if (code) {
    const supabase = createClient()
    const { error } = await supabase.auth.exchangeCodeForSession(code)
    if (!error) {
      // Create or update their profile, and check if it's rmaiti01
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const username = user.user_metadata?.user_name || user.user_metadata?.preferred_username || ''
        const isRmaiti = username.toLowerCase() === 'rmaiti01'

        // If it's a new login or we need to enforce admin status, update the profile
        const { data: existingProfile } = await supabase.from('profiles').select('role').eq('id', user.id).single()

        await supabase.from('profiles').upsert({
          id: user.id,
          email: user.email,
          full_name: user.user_metadata?.full_name || username || user.email?.split('@')[0],
          // Keep existing role if they have one, unless they are rmaiti01 (force admin)
          role: isRmaiti ? 'admin' : (existingProfile?.role || 'student'),
          updated_at: new Date().toISOString()
        }, { onConflict: 'id' })
      }

      return NextResponse.redirect(`${origin}${next}`)
    }
  }

  return NextResponse.redirect(`${origin}/studio/auth/sign-in?error=auth_callback_error`)
}
