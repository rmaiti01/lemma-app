import Link from 'next/link'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import { getLeaderboardTop, getWeeklyLeaderboardTop } from '@/lib/game-data'
import type { LeaderboardEntry } from '@/lib/game-types'
import './leaderboard.css'

export default async function LeaderboardPage({
  searchParams,
}: {
  searchParams?: { period?: string }
}) {
  const period = searchParams?.period === 'week' ? 'week' : 'all'
  let entries: LeaderboardEntry[] = []

  try {
    entries =
      period === 'week' ? await getWeeklyLeaderboardTop(20) : await getLeaderboardTop(20)
  } catch {
    // DB not set up
  }

  return (
    <div className="page-content">
      <Navbar />

      <section style={{ maxWidth: 720, margin: '0 auto', padding: '40px 24px 64px' }}>
        <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 32, fontWeight: 700, marginBottom: 8 }}>
          Leaderboard
        </h1>
        <p style={{ fontSize: 14, color: 'var(--color-text-secondary)', marginBottom: 20 }}>
          Top reviewers ranked by stars earned.
        </p>

        <div
          style={{
            display: 'inline-flex',
            gap: 4,
            padding: 4,
            marginBottom: 28,
            background: 'var(--color-surface)',
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius-md)',
          }}
        >
          <Link
            href="/studio/leaderboard"
            className="lb-period-tab"
            data-active={period === 'all'}
            style={{
              padding: '8px 16px',
              borderRadius: 6,
              fontSize: 13,
              fontWeight: 600,
              textDecoration: 'none',
              color: period === 'all' ? 'var(--color-text)' : 'var(--color-text-muted)',
              background: period === 'all' ? 'rgba(59, 130, 246, 0.12)' : 'transparent',
            }}
          >
            All time
          </Link>
          <Link
            href="/studio/leaderboard?period=week"
            className="lb-period-tab"
            data-active={period === 'week'}
            style={{
              padding: '8px 16px',
              borderRadius: 6,
              fontSize: 13,
              fontWeight: 600,
              textDecoration: 'none',
              color: period === 'week' ? 'var(--color-text)' : 'var(--color-text-muted)',
              background: period === 'week' ? 'rgba(59, 130, 246, 0.12)' : 'transparent',
            }}
          >
            This week
          </Link>
        </div>

        {entries.length > 0 ? (
          <div className="lb-table-wrap">
            <table className="lb-table">
              <thead>
                <tr>
                  <th style={{ width: 60 }}>#</th>
                  <th>Player</th>
                  <th style={{ width: 80, textAlign: 'right' }}>Stars</th>
                  <th style={{ width: 80, textAlign: 'right' }}>Points</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((entry, i) => (
                  <tr key={entry.user_id}>
                    <td className="lb-rank">{entry.rank ?? i + 1}</td>
                    <td className="lb-player">
                      {entry.avatar_url && (
                        <img
                          src={entry.avatar_url}
                          alt=""
                          width={28}
                          height={28}
                          style={{ borderRadius: '50%' }}
                        />
                      )}
                      <span>{entry.github_username?.trim() ? entry.github_username : 'Anonymous'}</span>
                    </td>
                    <td style={{ textAlign: 'right', fontWeight: 600 }}>{entry.total_stars}</td>
                    <td style={{ textAlign: 'right', color: 'var(--color-text-secondary)' }}>{entry.total_points}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div
            style={{
              textAlign: 'center',
              padding: 48,
              background: 'var(--color-surface)',
              borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--color-border)',
              color: 'var(--color-text-secondary)',
            }}
          >
            No players on the leaderboard yet. Be the first!
          </div>
        )}
      </section>

      <Footer />
    </div>
  )
}
