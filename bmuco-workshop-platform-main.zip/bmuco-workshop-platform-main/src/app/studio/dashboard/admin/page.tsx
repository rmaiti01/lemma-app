'use client'

import { Users, FileText, GitPullRequest, ArrowUpRight, BookOpen, Database } from 'lucide-react'
import Link from 'next/link'

export default function AdminDashboard() {
  // In production, metrics fetched from Supabase aggregate queries
  const metrics = {
    totalStudents: 0, activeCohorts: 0, prsSubmitted: 0,
    prsMerged: 0, processTraces: 0, l2Students: 0,
    pendingApplications: 0,
  }

  return (
    <div>
      <div className="dashboard-header">
        <h1>Admin Dashboard</h1>
        <p>Cohort overview and programme management</p>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-4" style={{ marginBottom: '32px' }}>
        <div className="stat-card">
          <span className="stat-card-label">Total Students</span>
          <span className="stat-card-value">{metrics.totalStudents}</span>
        </div>
        <div className="stat-card">
          <span className="stat-card-label">PRs Submitted</span>
          <span className="stat-card-value">{metrics.prsSubmitted}</span>
        </div>
        <div className="stat-card">
          <span className="stat-card-label">PRs Merged</span>
          <span className="stat-card-value">{metrics.prsMerged}</span>
        </div>
        <div className="stat-card">
          <span className="stat-card-label">L2 Track</span>
          <span className="stat-card-value">{metrics.l2Students}</span>
        </div>
      </div>

      <div className="grid grid-2" style={{ marginBottom: '32px' }}>
        <div className="stat-card">
          <span className="stat-card-label">Process Traces Collected</span>
          <span className="stat-card-value">{metrics.processTraces}</span>
        </div>
        <div className="stat-card">
          <span className="stat-card-label">Pending Applications</span>
          <span className="stat-card-value">{metrics.pendingApplications}</span>
          {metrics.pendingApplications > 0 && (
            <Link href="/studio/dashboard/admin/applications" style={{ fontSize: 'var(--text-xs)', marginTop: '4px' }}>
              Review →
            </Link>
          )}
        </div>
      </div>

      {/* Quick Links */}
      <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, marginBottom: '16px' }}>Management</h3>
      <div className="grid grid-3">
        {[
          { icon: FileText, label: 'Applications', href: '/studio/dashboard/admin/applications', desc: 'Review student applications' },
          { icon: Users, label: 'User Management', href: '/studio/dashboard/admin/users', desc: 'Manage roles and assignments' },
          { icon: BookOpen, label: 'Cohorts', href: '/studio/dashboard/admin/cohorts', desc: 'Create and manage cohorts' },
          { icon: ArrowUpRight, label: 'L2 Pipeline', href: '/studio/dashboard/admin/l2-pipeline', desc: 'Track post-program graduates' },
          { icon: GitPullRequest, label: 'Export Data', href: '/studio/dashboard/admin/export', desc: 'Export process traces' },
          { icon: Database, label: 'Session export', href: '/studio/dashboard/admin/export-packets', desc: 'Structured gameplay session exports' },
        ].map((item, i) => {
          const Icon = item.icon
          return (
            <Link key={i} href={item.href} className="card card-hover" style={{ textDecoration: 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Icon size={20} color="var(--color-accent)" />
                <div>
                  <div style={{ fontWeight: 600, fontSize: 'var(--text-sm)', color: 'var(--color-text)' }}>{item.label}</div>
                  <div style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)' }}>{item.desc}</div>
                </div>
              </div>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
