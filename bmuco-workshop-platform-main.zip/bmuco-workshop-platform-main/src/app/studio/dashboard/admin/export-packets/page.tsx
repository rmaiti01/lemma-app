'use client'

import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, Database, Download, RefreshCw } from 'lucide-react'

type Stats = {
  total: number
  by_mode: Record<string, number>
  by_dimension: Record<string, number>
}

const MODE_OPTIONS = [
  { value: 'all', label: 'All modes' },
  { value: 'mcq', label: 'MCQ' },
  { value: 'build', label: 'Build' },
  { value: 'trace', label: 'Trace' },
  { value: 'review', label: 'Review' },
]

const WORLD_OPTIONS = [
  { value: 'all', label: 'All worlds' },
  { value: '1', label: 'World 1' },
  { value: '2', label: 'World 2' },
  { value: '3', label: 'World 3' },
]

const FORMAT_OPTIONS = [
  { value: 'a', label: 'A — Tactic prediction (JSONL)' },
  { value: 'b', label: 'B — DPO preference pairs (JSONL)' },
  { value: 'c', label: 'C — Premise retrieval (JSONL)' },
  { value: 'raw', label: 'Raw — Full rows (JSON)' },
]

function defaultEndDate(): string {
  return new Date().toISOString().slice(0, 10)
}

function defaultStartDate(): string {
  const d = new Date()
  d.setDate(d.getDate() - 30)
  return d.toISOString().slice(0, 10)
}

function buildQueryParams(opts: {
  start: string
  end: string
  mode: string
  worldId: string
  levelId: string
  stats?: boolean
  format?: string
  firstAttemptsOnly?: boolean
}): string {
  const p = new URLSearchParams()
  if (opts.stats) p.set('stats', '1')
  if (opts.format) p.set('format', opts.format)
  if (opts.start) p.set('start', `${opts.start}T00:00:00.000Z`)
  if (opts.end) p.set('end', `${opts.end}T23:59:59.999Z`)
  if (opts.mode && opts.mode !== 'all') p.set('mode', opts.mode)
  if (opts.worldId && opts.worldId !== 'all') p.set('world_id', opts.worldId)
  if (opts.levelId.trim()) p.set('level_id', opts.levelId.trim())
  if (opts.firstAttemptsOnly) p.set('first_attempts', '1')
  return p.toString()
}

export default function ExportPacketsPage() {
  const [start, setStart] = useState(defaultStartDate)
  const [end, setEnd] = useState(defaultEndDate)
  const [mode, setMode] = useState('all')
  const [worldId, setWorldId] = useState('all')
  const [levelId, setLevelId] = useState('')
  const [format, setFormat] = useState<'a' | 'b' | 'c' | 'raw'>('a')
  const [firstAttemptsOnly, setFirstAttemptsOnly] = useState(false)

  const [stats, setStats] = useState<Stats | null>(null)
  const [statsLoading, setStatsLoading] = useState(false)
  const [statsError, setStatsError] = useState<string | null>(null)

  const [downloadLoading, setDownloadLoading] = useState(false)
  const [downloadError, setDownloadError] = useState<string | null>(null)

  const loadStats = useCallback(async () => {
    setStatsLoading(true)
    setStatsError(null)
    try {
      const qs = buildQueryParams({
        start,
        end,
        mode,
        worldId,
        levelId,
        stats: true,
        firstAttemptsOnly,
      })
      const res = await fetch(`/studio/api/admin/export-packets?${qs}`, { credentials: 'include' })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        setStatsError(typeof data?.error === 'string' ? data.error : 'Failed to load stats')
        setStats(null)
        return
      }
      setStats(data as Stats)
    } catch {
      setStatsError('Network error')
      setStats(null)
    } finally {
      setStatsLoading(false)
    }
  }, [start, end, mode, worldId, levelId, firstAttemptsOnly])

  useEffect(() => {
    void loadStats()
  }, [loadStats])

  const handleDownload = async () => {
    setDownloadLoading(true)
    setDownloadError(null)
    try {
      const qs = buildQueryParams({
        start,
        end,
        mode,
        worldId,
        levelId,
        format,
        firstAttemptsOnly,
      })
      const res = await fetch(`/studio/api/admin/export-packets?${qs}`, { credentials: 'include' })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        setDownloadError(typeof data?.error === 'string' ? data.error : `HTTP ${res.status}`)
        return
      }
      const blob = await res.blob()
      const cd = res.headers.get('Content-Disposition')
      const match = cd?.match(/filename="([^"]+)"/)
      const filename = match?.[1] ?? `proof-packets-${format}-${new Date().toISOString().slice(0, 10)}.jsonl`
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = filename
      a.click()
      URL.revokeObjectURL(url)
    } catch {
      setDownloadError('Download failed')
    } finally {
      setDownloadLoading(false)
    }
  }

  return (
    <div>
      <div className="dashboard-header">
        <Link
          href="/studio/dashboard/admin"
          className="sidebar-link"
          style={{ display: 'inline-flex', alignItems: 'center', gap: 6, marginBottom: 12, width: 'auto' }}
        >
          <ArrowLeft size={16} />
          Admin
        </Link>
        <h1 style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Database size={28} color="var(--color-accent)" />
          Research export — session records
        </h1>
        <p>Filter and download structured session exports for internal research workflows.</p>
      </div>

      <div className="grid grid-2" style={{ gap: 24, alignItems: 'start' }}>
        <div className="card" style={{ maxWidth: 560 }}>
          <h3 style={{ fontWeight: 600, marginBottom: 16 }}>Filters</h3>

          <div className="form-group" style={{ marginBottom: 16 }}>
            <label className="form-label">Date range (UTC)</label>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <input
                type="date"
                className="form-select"
                value={start}
                onChange={e => setStart(e.target.value)}
                style={{ flex: 1, minWidth: 140 }}
              />
              <span style={{ alignSelf: 'center', color: 'var(--color-text-muted)' }}>→</span>
              <input
                type="date"
                className="form-select"
                value={end}
                onChange={e => setEnd(e.target.value)}
                style={{ flex: 1, minWidth: 140 }}
              />
            </div>
          </div>

          <div className="form-group" style={{ marginBottom: 16 }}>
            <label className="form-label">Mode</label>
            <select className="form-select" value={mode} onChange={e => setMode(e.target.value)}>
              {MODE_OPTIONS.map(o => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group" style={{ marginBottom: 16 }}>
            <label className="form-label">World</label>
            <select className="form-select" value={worldId} onChange={e => setWorldId(e.target.value)}>
              {WORLD_OPTIONS.map(o => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group" style={{ marginBottom: 16 }}>
            <label className="form-label">Level ID</label>
            <input
              type="text"
              className="form-select"
              placeholder="e.g. w1_l1 or numeric id"
              value={levelId}
              onChange={e => setLevelId(e.target.value)}
            />
          </div>

          <div className="form-group" style={{ marginBottom: 16 }}>
            <label
              className="form-label"
              style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}
            >
              <input
                type="checkbox"
                checked={firstAttemptsOnly}
                onChange={e => setFirstAttemptsOnly(e.target.checked)}
              />
              First attempts only (first visit per level)
            </label>
            <p style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', marginTop: 6, marginBottom: 0 }}>
              Keeps rows where <code>is_first_attempt = true</code> (no prior completion on that level for that user).
            </p>
          </div>

          <div className="form-group" style={{ marginBottom: 16 }}>
            <label className="form-label">Export format</label>
            <select
              className="form-select"
              value={format}
              onChange={e => setFormat(e.target.value as 'a' | 'b' | 'c' | 'raw')}
            >
              {FORMAT_OPTIONS.map(o => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>

          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <button type="button" className="btn btn-secondary" onClick={() => void loadStats()} disabled={statsLoading}>
              <RefreshCw size={16} style={{ opacity: statsLoading ? 0.5 : 1 }} />
              {statsLoading ? 'Refreshing…' : 'Refresh stats'}
            </button>
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => void handleDownload()}
              disabled={downloadLoading}
            >
              <Download size={16} />
              {downloadLoading ? 'Downloading…' : 'Download'}
            </button>
          </div>

          {downloadError && (
            <p style={{ color: '#ef4444', fontSize: 'var(--text-sm)', marginTop: 12 }}>{downloadError}</p>
          )}
        </div>

        <div className="card">
          <h3 style={{ fontWeight: 600, marginBottom: 16 }}>Stats (filtered)</h3>
          {statsError && (
            <p style={{ color: '#ef4444', fontSize: 'var(--text-sm)', marginBottom: 12 }}>{statsError}</p>
          )}
          {statsLoading && !stats && <p style={{ color: 'var(--color-text-muted)' }}>Loading…</p>}
          {stats && (
            <>
              <div className="stat-card" style={{ marginBottom: 16 }}>
                <span className="stat-card-label">Total packets</span>
                <span className="stat-card-value">{stats.total}</span>
              </div>
              <h4 style={{ fontSize: 'var(--text-xs)', textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--color-text-muted)', marginBottom: 8 }}>
                By mode
              </h4>
              <div style={{ display: 'grid', gap: 8, marginBottom: 20 }}>
                {Object.entries(stats.by_mode).map(([k, v]) => (
                  <div key={k} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--text-sm)' }}>
                    <span>{k}</span>
                    <strong>{v}</strong>
                  </div>
                ))}
              </div>
              <h4 style={{ fontSize: 'var(--text-xs)', textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--color-text-muted)', marginBottom: 8 }}>
                By dimension
              </h4>
              <div style={{ display: 'grid', gap: 8, maxHeight: 220, overflow: 'auto' }}>
                {Object.entries(stats.by_dimension)
                  .sort((a, b) => b[1] - a[1])
                  .map(([k, v]) => (
                    <div key={k} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--text-sm)' }}>
                      <span style={{ wordBreak: 'break-word', paddingRight: 8 }}>{k}</span>
                      <strong>{v}</strong>
                    </div>
                  ))}
              </div>
            </>
          )}
        </div>
      </div>

      <div className="card" style={{ marginTop: 24, maxWidth: 900 }}>
        <h3 style={{ fontWeight: 600, marginBottom: 12 }}>Format reference</h3>
        <ul style={{ margin: 0, paddingLeft: 20, color: 'var(--color-text-secondary)', lineHeight: 1.7, fontSize: 'var(--text-sm)' }}>
          <li>
            <strong>A</strong> — One JSONL row per packet with <code>tactic_success</code> and a non-empty chosen tactic:
            proof state, tactic, premises, difficulty, topics.
          </li>
          <li>
            <strong>B</strong> — One JSONL row per rejected alternative (with a chosen tactic): chosen vs rejected
            plus reasons and dimension.
          </li>
          <li>
            <strong>C</strong> — One JSONL row per packet with non-empty <code>premises_used</code>: relevant vs available
            premises for retrieval-style exports.
          </li>
          <li>
            <strong>Raw</strong> — Pretty-printed JSON array of full session step rows matching filters.
          </li>
        </ul>
      </div>
    </div>
  )
}
