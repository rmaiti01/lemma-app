'use client'

import { ArrowUpRight } from 'lucide-react'

const pipelineStages = [
  { id: 'applied', label: 'Applied', color: 'var(--color-info)' },
  { id: 'accepted', label: 'Accepted', color: 'var(--color-warning)' },
  { id: 'in_progress', label: 'In Progress', color: 'var(--color-accent)' },
  { id: '5_prs', label: '5+ Merged PRs', color: 'var(--color-primary-light)' },
  { id: '10_prs', label: '10+ Merged PRs', color: 'var(--color-success)' },
  { id: 'completed', label: 'Reviewer Bootcamp Ready', color: 'var(--color-success)' },
]

export default function AdminL2PipelinePage() {
  // In production, L2 tracks fetched from Supabase
  const l2Students: Record<string, any[]> = {}
  pipelineStages.forEach(s => { l2Students[s.id] = [] })

  return (
    <div>
      <div className="dashboard-header">
        <h1>L2 Pipeline Tracker</h1>
        <p>Post-program pathway: from L1 certification to Reviewer Bootcamp readiness</p>
      </div>

      {/* Pipeline visualization */}
      <div style={{ marginBottom: '24px' }}>
        <div className="pipeline" style={{ marginBottom: '8px' }}>
          {pipelineStages.map((stage, i) => (
            <div key={stage.id} className="pipeline-step">
              <div className="pipeline-node">{stage.label}</div>
              {i < pipelineStages.length - 1 && <div className="pipeline-arrow" />}
            </div>
          ))}
        </div>
      </div>

      {/* Kanban Board */}
      <div className="kanban">
        {pipelineStages.map(stage => (
          <div key={stage.id} className="kanban-column">
            <div className="kanban-column-header">
              <span>{stage.label}</span>
              <span className="badge badge-neutral">{l2Students[stage.id]?.length || 0}</span>
            </div>
            {(l2Students[stage.id] || []).length === 0 ? (
              <div style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', textAlign: 'center', padding: '24px 8px' }}>
                No students in this stage
              </div>
            ) : (
              l2Students[stage.id].map((student: any) => (
                <div key={student.id} className="kanban-card">
                  <div style={{ fontWeight: 600, fontSize: 'var(--text-sm)', marginBottom: '4px' }}>{student.full_name}</div>
                  <div style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)' }}>
                    {student.merged_pr_count} merged PRs
                  </div>
                </div>
              ))
            )}
          </div>
        ))}
      </div>

      {/* Info Card */}
      <div className="card" style={{ marginTop: '24px' }}>
        <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 'var(--text-sm)', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <ArrowUpRight size={16} color="var(--color-accent)" />
          About the L2 Track
        </h3>
        <p style={{ fontSize: 'var(--text-sm)' }}>
          The strongest L1 graduates (~60–70%) continue part-time (12–15 hours/week, 3–6 months), 
          building toward the 10 merged PRs that the MRB-style Reviewer Bootcamp requires as entry. 
          This creates the upstream pipeline toward Mathlib Initiative contributor programs.
        </p>
      </div>
    </div>
  )
}
