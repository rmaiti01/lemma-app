import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { Download, BarChart3 } from 'lucide-react'

export default async function AdminAnalyticsPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/studio/auth/sign-in')

  // Verify admin
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()
  if (profile?.role !== 'admin') redirect('/studio/dashboard')

  // Fetch stats
  const { data: traces, count: traceCount } = await supabase
    .from('exercise_traces')
    .select('id, status, time_spent_minutes, exercise_id, layer0_completed_at, layer1_completed_at, layer2_completed_at, layer3_completed_at, layer4_completed_at', { count: 'exact' })

  const { data: exercises } = await supabase.from('exercises').select('id, title, difficulty, category')
  const { data: feedback } = await supabase.from('exercise_feedback').select('id')
  const { data: students } = await supabase.from('profiles').select('id').eq('role', 'student')

  const totalTraces = traceCount || 0
  const submittedTraces = traces?.filter(t => t.status === 'submitted' || t.status === 'reviewed') || []
  const reviewedTraces = traces?.filter(t => t.status === 'reviewed') || []
  const avgTime = submittedTraces.length > 0
    ? Math.round(submittedTraces.reduce((sum, t) => sum + (t.time_spent_minutes || 0), 0) / submittedTraces.length)
    : 0

  // Layer completion rates
  const layerFields = ['layer0_completed_at', 'layer1_completed_at', 'layer2_completed_at', 'layer3_completed_at', 'layer4_completed_at']
  const layerRates = layerFields.map(field => {
    if (!traces?.length) return 0
    return Math.round((traces.filter((t: any) => t[field]).length / traces.length) * 100)
  })

  // AI review issues
  const aiReviewExercises = exercises?.filter(e => e.category === 'ai_review') || []

  return (
    <div>
      <div className="dashboard-header">
        <h1>Analytics</h1>
        <p>Platform-wide data and performance metrics</p>
      </div>

      {/* Top stats */}
      <div className="grid grid-4" style={{ marginBottom: '32px' }}>
        <div className="stat-card">
          <span className="stat-card-label">Total Traces</span>
          <span className="stat-card-value">{totalTraces}</span>
        </div>
        <div className="stat-card">
          <span className="stat-card-label">Submitted</span>
          <span className="stat-card-value">{submittedTraces.length}</span>
        </div>
        <div className="stat-card">
          <span className="stat-card-label">Reviewed</span>
          <span className="stat-card-value">{reviewedTraces.length}</span>
        </div>
        <div className="stat-card">
          <span className="stat-card-label">Avg. Minutes/Exercise</span>
          <span className="stat-card-value">{avgTime}</span>
        </div>
      </div>

      <div className="grid grid-2" style={{ marginBottom: '32px' }}>
        {/* Layer completion rates */}
        <div className="card">
          <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, marginBottom: 'var(--space-4)' }}>
            <BarChart3 size={18} style={{ verticalAlign: 'text-bottom', marginRight: '8px' }} />
            Layer Completion Rates
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
            {['Inventory', 'Type Skeleton', 'Statement', 'Proof', 'Culture Check'].map((name, i) => (
              <div key={i}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--text-xs)', marginBottom: '4px' }}>
                  <span>Layer {i}: {name}</span>
                  <span style={{ fontWeight: 600 }}>{layerRates[i]}%</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-bar-fill" style={{ width: `${layerRates[i]}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick stats */}
        <div className="card">
          <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, marginBottom: 'var(--space-4)' }}>
            Platform Overview
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: 'var(--space-3) 0', borderBottom: '1px solid var(--color-border)' }}>
              <span style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-secondary)' }}>Total Students</span>
              <span style={{ fontWeight: 600 }}>{students?.length || 0}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: 'var(--space-3) 0', borderBottom: '1px solid var(--color-border)' }}>
              <span style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-secondary)' }}>Exercises Available</span>
              <span style={{ fontWeight: 600 }}>{exercises?.length || 0}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: 'var(--space-3) 0', borderBottom: '1px solid var(--color-border)' }}>
              <span style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-secondary)' }}>AI Review Exercises</span>
              <span style={{ fontWeight: 600 }}>{aiReviewExercises.length}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: 'var(--space-3) 0', borderBottom: '1px solid var(--color-border)' }}>
              <span style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-secondary)' }}>Mentor Reviews</span>
              <span style={{ fontWeight: 600 }}>{feedback?.length || 0}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Export */}
      <div className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, marginBottom: 'var(--space-1)' }}>
            Export Trace Data
          </h3>
          <p style={{ fontSize: 'var(--text-sm)' }}>
            Download all process traces as JSON for your records.
          </p>
        </div>
        <a href="/studio/api/admin/export" className="btn btn-primary">
          <Download size={16} /> Export JSON
        </a>
      </div>
    </div>
  )
}
