'use client'

import { useState } from 'react'
import { BookOpen, Plus } from 'lucide-react'

export default function AdminCohortsPage() {
  const [showCreate, setShowCreate] = useState(false)
  const [cohortName, setCohortName] = useState('')
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')

  // In production, fetched from Supabase
  const cohorts: any[] = []

  const handleCreate = async () => {
    alert(`Cohort "${cohortName}" created (Supabase integration pending)`)
    setShowCreate(false)
    setCohortName('')
    setStartDate('')
    setEndDate('')
  }

  return (
    <div>
      <div className="dashboard-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1>Cohorts</h1>
          <p>Create and manage learner cohorts</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="btn btn-primary">
          <Plus size={16} /> New Cohort
        </button>
      </div>

      {/* Create Cohort Form */}
      {showCreate && (
        <div className="card" style={{ marginBottom: '24px' }}>
          <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 'var(--text-base)', marginBottom: '16px' }}>Create New Cohort</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px', marginBottom: '16px' }}>
            <div className="form-group">
              <label className="form-label">Cohort Name</label>
              <input className="form-input" placeholder="e.g. Cohort 1 — Summer 2026" value={cohortName} onChange={e => setCohortName(e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label">Start Date</label>
              <input type="date" className="form-input" value={startDate} onChange={e => setStartDate(e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label">End Date</label>
              <input type="date" className="form-input" value={endDate} onChange={e => setEndDate(e.target.value)} />
            </div>
          </div>
          <p style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', marginBottom: '16px' }}>
            The default 10-week curriculum will be automatically created for this cohort. You can customise it afterwards.
          </p>
          <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
            <button onClick={() => setShowCreate(false)} className="btn btn-secondary btn-sm">Cancel</button>
            <button onClick={handleCreate} className="btn btn-primary btn-sm" disabled={!cohortName}>Create Cohort</button>
          </div>
        </div>
      )}

      {/* Cohort List */}
      {cohorts.length === 0 && !showCreate ? (
        <div className="card">
          <div className="empty-state">
            <BookOpen className="empty-state-icon" />
            <h3>No Cohorts Yet</h3>
            <p>Create your first cohort to start enrolling students.</p>
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {cohorts.map(cohort => (
            <div key={cohort.id} className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 'var(--text-base)' }}>{cohort.name}</h3>
                  <p style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)' }}>
                    {cohort.start_date} → {cohort.end_date}
                  </p>
                </div>
                <span className={`badge ${cohort.status === 'active' ? 'badge-success' : cohort.status === 'upcoming' ? 'badge-info' : 'badge-neutral'}`}>
                  {cohort.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
