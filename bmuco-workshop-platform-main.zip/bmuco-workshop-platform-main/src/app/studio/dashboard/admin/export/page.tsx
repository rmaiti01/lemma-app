'use client'

import { useState } from 'react'
import { Download, FileJson, FileSpreadsheet } from 'lucide-react'

export default function AdminExportPage() {
  const [exporting, setExporting] = useState(false)
  const [format, setFormat] = useState<'json' | 'csv'>('json')
  const [cohortFilter, setCohortFilter] = useState('all')

  const handleExport = async () => {
    setExporting(true)
    // In production: fetch all process traces from Supabase with filters
    // For JSON: JSON.stringify and download
    // For CSV: use papaparse to convert and download
    
    setTimeout(() => {
      const dummyData = JSON.stringify({ traces: [], metadata: { exported_at: new Date().toISOString(), format } }, null, 2)
      const blob = new Blob([dummyData], { type: format === 'json' ? 'application/json' : 'text/csv' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `lemma-process-traces-${new Date().toISOString().split('T')[0]}.${format}`
      a.click()
      URL.revokeObjectURL(url)
      setExporting(false)
    }, 1000)
  }

  return (
    <div>
      <div className="dashboard-header">
        <h1>Export Data</h1>
        <p>Export process traces and program data for analysis</p>
      </div>

      <div className="card" style={{ maxWidth: '600px' }}>
        <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 'var(--text-base)', marginBottom: '20px' }}>
          Export Process Traces
        </h3>

        {/* Format Selection */}
        <div className="form-group" style={{ marginBottom: '20px' }}>
          <label className="form-label">Format</label>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              onClick={() => setFormat('json')}
              className={`btn ${format === 'json' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ flex: 1 }}
            >
              <FileJson size={16} /> JSON
            </button>
            <button
              onClick={() => setFormat('csv')}
              className={`btn ${format === 'csv' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ flex: 1 }}
            >
              <FileSpreadsheet size={16} /> CSV
            </button>
          </div>
        </div>

        {/* Cohort Filter */}
        <div className="form-group" style={{ marginBottom: '20px' }}>
          <label className="form-label">Cohort</label>
          <select className="form-select" value={cohortFilter} onChange={e => setCohortFilter(e.target.value)}>
            <option value="all">All Cohorts</option>
          </select>
        </div>

        {/* Export Info */}
        <div style={{
          background: 'rgba(27,65,52,0.1)', border: '1px solid rgba(27,65,52,0.2)',
          borderRadius: 'var(--radius-md)', padding: '12px', marginBottom: '20px',
          fontSize: 'var(--text-xs)', color: 'var(--color-text-secondary)'
        }}>
          <strong>Included fields:</strong> title, nl_statement, informal_proof, formal_proof, 
          step_level_alignment, proof_development_journal, ai_usage_log, error_chain, 
          quality_annotations, autoformaliser_correction_record, pr_link, pr_feedback_status, 
          mentor_feedback, pr_interactions, version_history
        </div>

        <button onClick={handleExport} className="btn btn-primary btn-lg" style={{ width: '100%' }} disabled={exporting}>
          {exporting ? 'Exporting...' : 'Download Export'}
          {!exporting && <Download size={16} />}
        </button>
      </div>
    </div>
  )
}
