'use client'

import { useState } from 'react'
import { Users, Shield } from 'lucide-react'

export default function AdminUsersPage() {
  // In production, users fetched from profiles table
  const users: any[] = []
  const [editingRole, setEditingRole] = useState<string | null>(null)

  const handleRoleChange = async (userId: string, newRole: string) => {
    // Update role in profiles table
    alert(`Role updated to ${newRole} (Supabase integration pending)`)
    setEditingRole(null)
  }


  return (
    <div>
      <div className="dashboard-header">
        <h1>User Management</h1>
        <p>Manage user roles, assign students to mentors, and enroll users in cohorts</p>
      </div>

      {users.length === 0 ? (
        <div className="card">
          <div className="empty-state">
            <Users className="empty-state-icon" />
            <h3>No Users Yet</h3>
            <p>Users will appear here once they sign up. You can change their roles and assign mentors.</p>
          </div>
        </div>
      ) : (
        <div className="table-wrapper">
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Cohort</th>
                <th>Mentor</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user.id}>
                  <td style={{ fontWeight: 500, color: 'var(--color-text)' }}>{user.full_name || '—'}</td>
                  <td>{user.email}</td>
                  <td>
                    {editingRole === user.id ? (
                      <select
                        className="form-select"
                        style={{ width: 'auto', padding: '4px 8px', fontSize: 'var(--text-xs)' }}
                        defaultValue={user.role}
                        onChange={e => handleRoleChange(user.id, e.target.value)}
                        onBlur={() => setEditingRole(null)}
                        autoFocus
                      >
                        <option value="student">student</option>
                        <option value="mentor">mentor</option>
                        <option value="admin">admin</option>
                      </select>
                    ) : (
                      <button
                        onClick={() => setEditingRole(user.id)}
                        className={`badge ${user.role === 'admin' ? 'badge-error' : user.role === 'mentor' ? 'badge-info' : 'badge-primary'}`}
                        style={{ cursor: 'pointer', border: 'none' }}
                      >
                        <Shield size={10} /> {user.role}
                      </button>
                    )}
                  </td>
                  <td>{user.cohort_name || '—'}</td>
                  <td>{user.mentor_name || '—'}</td>
                  <td>
                    <button className="btn btn-ghost btn-sm">
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
