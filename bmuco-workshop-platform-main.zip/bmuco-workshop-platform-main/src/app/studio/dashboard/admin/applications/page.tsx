'use client'

import { useState } from 'react'
import { FileText, CheckCircle, XCircle, Clock } from 'lucide-react'

export default function AdminApplicationsPage() {
  // In production, fetched from Supabase
  const [filter, setFilter] = useState<'all' | 'pending' | 'accepted' | 'rejected'>('pending')
  const applications: any[] = []

  const handleAction = async (id: string, action: 'accepted' | 'rejected') => {
    // Update application status in Supabase
    alert(`Application ${action} (Supabase integration pending)`)
  }

  return (
    <div>
      <div className="dashboard-header">
        <h1>Student Applications</h1>
        <p>Review and manage program applications</p>
      </div>

      {/* Filter Tabs */}
      <div className="tabs">
        {(['all', 'pending', 'accepted', 'rejected'] as const).map(tab => (
          <button key={tab} className={`tab ${filter === tab ? 'active' : ''}`} onClick={() => setFilter(tab)}>
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {applications.length === 0 ? (
        <div className="card">
          <div className="empty-state">
            <FileText className="empty-state-icon" />
            <h3>No Applications</h3>
            <p>No{filter !== 'all' ? ` ${filter}` : ''} applications found.</p>
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {applications.map(app => (
            <div key={app.id} className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                <div>
                  <h3 style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 'var(--text-base)' }}>{app.full_name}</h3>
                  <p style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)' }}>{app.email}</p>
                </div>
                <span className={`badge ${app.status === 'pending' ? 'badge-warning' : app.status === 'accepted' ? 'badge-success' : 'badge-error'}`}>
                  {app.status === 'pending' && <Clock size={10} />}
                  {app.status === 'accepted' && <CheckCircle size={10} />}
                  {app.status === 'rejected' && <XCircle size={10} />}
                  {app.status}
                </span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px', fontSize: 'var(--text-sm)', marginBottom: '12px' }}>
                <div><span style={{ color: 'var(--color-text-muted)' }}>University:</span> {app.university || '—'}</div>
                <div><span style={{ color: 'var(--color-text-muted)' }}>Level:</span> {app.degree_level || '—'}</div>
                <div><span style={{ color: 'var(--color-text-muted)' }}>Lean exp:</span> {app.lean_experience}</div>
              </div>
              {app.motivation && (
                <p style={{ fontSize: 'var(--text-sm)', borderTop: '1px solid var(--color-border)', paddingTop: '12px' }}>
                  {app.motivation}
                </p>
              )}
              {app.status === 'pending' && (
                <div style={{ display: 'flex', gap: '8px', marginTop: '12px', justifyContent: 'flex-end' }}>
                  <button onClick={() => handleAction(app.id, 'rejected')} className="btn btn-secondary btn-sm">
                    <XCircle size={14} /> Reject
                  </button>
                  <button onClick={() => handleAction(app.id, 'accepted')} className="btn btn-primary btn-sm">
                    <CheckCircle size={14} /> Accept
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
