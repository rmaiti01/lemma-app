import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export default async function DashboardPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect('/studio/auth/sign-in')
  }

  // Get user's role
  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  const role = profile?.role || 'student'

  // Redirect to role-specific dashboard
  switch (role) {
    case 'admin':
      redirect('/studio/dashboard/admin')
    case 'mentor':
      redirect('/studio/dashboard/mentor')
    default:
      redirect('/studio/dashboard/student')
  }
}
