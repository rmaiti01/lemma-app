import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import DashboardSidebar from '@/components/DashboardSidebar'
import { UserRole } from '@/lib/types'

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect('/studio/auth/sign-in')
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role, full_name')
    .eq('id', user.id)
    .single()

  const role = (profile?.role || 'student') as UserRole
  const userName = profile?.full_name || user.email || 'User'

  return (
    <div className="dashboard-layout">
      <DashboardSidebar role={role} userName={userName} />
      <main className="dashboard-main">
        {children}
      </main>
    </div>
  )
}
