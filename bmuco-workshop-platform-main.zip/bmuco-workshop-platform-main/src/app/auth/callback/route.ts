import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

/**
 * Root OAuth callback — use redirectTo `${origin}/auth/callback` when the app is served from this origin.
 * Exchanges the code for a session then sends the user to the marketing home page.
 */
export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get('code')
  const origin = requestUrl.origin

  if (code) {
    const supabase = createClient()
    const { error } = await supabase.auth.exchangeCodeForSession(code)
    if (!error) {
      return NextResponse.redirect(new URL('/', origin))
    }
  }

  return NextResponse.redirect(new URL('/studio/auth/sign-in?error=auth_callback_error', origin))
}
