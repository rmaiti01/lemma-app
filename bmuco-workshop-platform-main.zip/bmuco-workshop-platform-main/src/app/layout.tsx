import type { Metadata } from 'next'
import './globals.css'
import { OnboardingProvider } from '@/components/OnboardingProvider'
import GameToaster from '@/components/GameToaster'

export const dynamic = 'force-dynamic'
export const revalidate = 0

export const metadata: Metadata = {
  title: 'Lemma — Learn Lean 4 by Playing',
  description:
    'A gamified Lean 4 theorem proving game. ' +
    'Review proofs, fill in tactics, annotate reasoning. ' +
    'Built for mathematicians who finished the Natural Number Game.',
  themeColor: '#3b82f6',
  openGraph: {
    title: 'Lemma — Learn Lean 4 by Playing',
    description:
      'A gamified Lean 4 theorem proving game. ' +
      'Review proofs, fill in tactics, annotate reasoning. ' +
      'Built for mathematicians who finished the Natural Number Game.',
  },
  twitter: {
    card: 'summary',
    title: 'Lemma — Learn Lean 4 by Playing',
    description:
      'A gamified Lean 4 theorem proving game. ' +
      'Review proofs, fill in tactics, annotate reasoning. ' +
      'Built for mathematicians who finished the Natural Number Game.',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,100..800;1,100..800&display=swap"
          rel="stylesheet"
        />
        <meta httpEquiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
        <meta httpEquiv="Pragma" content="no-cache" />
        <meta httpEquiv="Expires" content="0" />
      </head>
      <body>
        <OnboardingProvider>
          {children}
          <GameToaster />
        </OnboardingProvider>
      </body>
    </html>
  )
}