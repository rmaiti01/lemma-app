import { NextResponse } from 'next/server'
import {
  AXLE_BASE,
  AXLE_TIMEOUT_MS,
  defaultAxleEnv,
  ensureMathlibImport,
  getAxleApiKey,
  leanErrorsCount,
} from '@/lib/axle-env'

function firstLeanErrorMessage(data: Record<string, unknown>): string | null {
  const lean = data.lean_messages as { errors?: Array<{ message?: string } | string> } | undefined
  const arr = lean?.errors
  if (!Array.isArray(arr) || arr.length === 0) return null
  const e = arr[0]
  if (typeof e === 'string') return e
  if (e && typeof e === 'object' && typeof e.message === 'string') return e.message
  return null
}

export async function POST(req: Request) {
  const apiKey = getAxleApiKey()
  const isMock = !apiKey

  const body = await req.json()
  const raw = (body?.content ?? '').trim()

  if (isMock) {
    console.log('[AXLE /repair] No API key — mock')
    return NextResponse.json({
      repaired: false,
      content: null,
      error_message: 'AXLE offline — set AXLE_API_KEY to enable repair hints',
      mock: true,
    })
  }

  if (!raw) {
    return NextResponse.json(
      {
        repaired: false,
        content: null,
        error_message: 'Missing content',
        mock: false,
      },
      { status: 400 }
    )
  }

  const content = ensureMathlibImport(raw)
  const environment = defaultAxleEnv()

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), AXLE_TIMEOUT_MS)

  try {
    const url = `${AXLE_BASE}/repair_proofs`
    console.log(`[AXLE /repair] POST ${url} env=${environment}`)

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        content,
        environment,
        ignore_imports: body?.ignore_imports ?? true,
        timeout_seconds: body?.timeout_seconds ?? 120,
      }),
      signal: controller.signal,
    })

    const rawText = await response.text()
    let data: Record<string, unknown> = {}
    try {
      data = JSON.parse(rawText) as Record<string, unknown>
    } catch {
      data = {}
    }

    if (!response.ok) {
      console.error(`[AXLE /repair] HTTP ${response.status}: ${rawText}`)
      return NextResponse.json({
        repaired: false,
        content: null,
        error_message: `AXLE HTTP ${response.status}`,
        mock: false,
      })
    }

    const errCount = leanErrorsCount(data)
    const out =
      typeof data.content === 'string' && data.content.trim() ? data.content.trim() : null
    const stats = data.repair_stats as Record<string, number> | undefined
    const statsSum =
      stats && typeof stats === 'object'
        ? Object.values(stats).reduce((a, v) => a + (typeof v === 'number' ? v : 0), 0)
        : 0

    const didRepair =
      errCount === 0 &&
      out != null &&
      (statsSum > 0 || out.trim() !== content.trim())

    return NextResponse.json({
      repaired: didRepair,
      content: errCount > 0 ? null : out,
      error_message: errCount > 0 ? firstLeanErrorMessage(data) ?? 'Lean errors after repair' : null,
      mock: false,
    })
  } catch (error: unknown) {
    const isTimeout = error instanceof DOMException && error.name === 'AbortError'
    const msg = isTimeout ? 'AXLE repair timed out' : error instanceof Error ? error.message : 'Unknown error'
    console.error(`[AXLE /repair] ${msg}`)
    return NextResponse.json({
      repaired: false,
      content: null,
      error_message: msg,
      mock: false,
    })
  } finally {
    clearTimeout(timeout)
  }
}
