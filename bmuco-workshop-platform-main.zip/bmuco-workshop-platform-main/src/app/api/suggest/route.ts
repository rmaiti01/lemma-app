export async function POST() {
  // TODO: internal retrieval model endpoint
  return Response.json({ ok: false, error: 'Not implemented' }, { status: 501 })
}
