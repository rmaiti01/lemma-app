import { NextResponse } from 'next/server'
import {
  AXLE_BASE,
  AXLE_TIMEOUT_MS,
  defaultAxleEnv,
  ensureMathlibImport,
  getAxleApiKey,
  leanErrorsCount,
} from '@/lib/axle-env'

function formatCounterexample(data: Record<string, unknown>): string | null {
  const disproved = data.disproved_theorems
  const results = data.results as Record<string, string> | undefined
  if (!Array.isArray(disproved) || disproved.length === 0) return null
  if (!results || typeof results !== 'object') return disproved.join(', ')

  const parts: string[] = []
  for (const name of disproved) {
    const r = results[name]
    if (typeof r === 'string' && r.trim()) parts.push(`[${name}]\n${r.trim()}`)
  }
  return parts.length > 0 ? parts.join('\n\n') : disproved.join(', ')
}

export async function POST(req: Request) {
  const apiKey = getAxleApiKey()
  const isMock = !apiKey

  const body = await req.json()
  const raw = (body?.content ?? '').trim()

  if (isMock) {
    console.log('[AXLE /disprove] No API key — mock')
    return NextResponse.json({
      disproved: false,
      counterexample: null,
      mock: true,
    })
  }

  if (!raw) {
    return NextResponse.json(
      { disproved: false, counterexample: null, error_message: 'Missing content', mock: false },
      { status: 400 }
    )
  }

  const content = ensureMathlibImport(raw)
  const environment = defaultAxleEnv()

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), AXLE_TIMEOUT_MS)

  try {
    const url = `${AXLE_BASE}/disprove`
    console.log(`[AXLE /disprove] POST ${url} env=${environment}`)

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        content,
        environment,
        ignore_imports: body?.ignore_imports ?? true,
        timeout_seconds: body?.timeout_seconds ?? 120,
        names: Array.isArray(body?.names) ? body.names : undefined,
        terminal_tactics: Array.isArray(body?.terminal_tactics) ? body.terminal_tactics : undefined,
      }),
      signal: controller.signal,
    })

    const rawText = await response.text()
    let data: Record<string, unknown> = {}
    try {
      data = JSON.parse(rawText) as Record<string, unknown>
    } catch {
      data = {}
    }

    if (!response.ok) {
      console.error(`[AXLE /disprove] HTTP ${response.status}: ${rawText}`)
      return NextResponse.json({
        disproved: false,
        counterexample: null,
        error_message: `AXLE HTTP ${response.status}`,
        mock: false,
      })
    }

    const errCount = leanErrorsCount(data)
    if (errCount > 0) {
      return NextResponse.json({
        disproved: false,
        counterexample: null,
        error_message: 'Invalid Lean before disprove',
        mock: false,
      })
    }

    const disprovedList = data.disproved_theorems
    const disproved = Array.isArray(disprovedList) && disprovedList.length > 0
    const counterexample = disproved ? formatCounterexample(data) : null

    return NextResponse.json({
      disproved,
      counterexample,
      mock: false,
      error_message: null,
    })
  } catch (error: unknown) {
    const isTimeout = error instanceof DOMException && error.name === 'AbortError'
    const msg = isTimeout ? 'AXLE disprove timed out' : error instanceof Error ? error.message : 'Unknown error'
    console.error(`[AXLE /disprove] ${msg}`)
    return NextResponse.json({
      disproved: false,
      counterexample: null,
      error_message: msg,
      mock: false,
    })
  } finally {
    clearTimeout(timeout)
  }
}
