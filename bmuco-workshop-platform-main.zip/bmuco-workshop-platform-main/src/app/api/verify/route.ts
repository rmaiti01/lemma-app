import { NextResponse } from 'next/server'

const AXLE_BASE = 'https://axle.axiommath.ai/api/v1'
const AXLE_TIMEOUT_MS = 30_000
/** AXLE expects names like lean-4.28.0 (see https://axle.axiommath.ai/v1/docs/tools/verify_proof/) */
const defaultAxleEnv = () => (process.env.AXLE_ENV ?? 'lean-4.28.0').trim() || 'lean-4.28.0'

function getAxleApiKey(): string {
  return (process.env.AXLE_API_KEY ?? process.env.AXIOMMATH_API_KEY ?? '').trim()
}

/** AXLE verify_proof expects a full Lean file; prepend Mathlib if missing. */
function ensureMathlibImport(lean: string): string {
  const trimmed = lean.trim()
  if (/^import\s+/m.test(trimmed)) return trimmed
  return `import Mathlib\n\n${trimmed}`
}

function firstAxleErrorMessage(data: Record<string, unknown> | null): string | null {
  if (!data) return null
  if (typeof data.error === 'string' && data.error) return data.error
  const tool = data.tool_messages as { errors?: unknown[] } | undefined
  const te = tool?.errors
  if (Array.isArray(te) && te.length > 0) {
    const e = te[0]
    if (typeof e === 'string') return e
    if (e && typeof e === 'object' && 'message' in e && typeof (e as { message: string }).message === 'string') {
      return (e as { message: string }).message
    }
  }
  const lean = data.lean_messages as { errors?: unknown[] } | undefined
  const le = lean?.errors
  if (Array.isArray(le) && le.length > 0) {
    const e = le[0]
    if (typeof e === 'string') return e
    if (e && typeof e === 'object' && 'message' in e && typeof (e as { message: string }).message === 'string') {
      return (e as { message: string }).message
    }
  }
  return null
}

export async function POST(req: Request) {
  const apiKey = getAxleApiKey()
  const isMock = !apiKey

  const body = await req.json()
  const rawContent = (body?.content ?? body?.proof ?? '').trim()
  const rawFormal = (body?.formal_statement ?? body?.formalStatement ?? '').trim()

  if (isMock) {
    console.log('[AXLE /verify] No AXLE_API_KEY or AXIOMMATH_API_KEY — returning mock')
    return NextResponse.json({
      verified: true,
      error_message: null,
      goal_state_after: null,
      mock: true,
    })
  }

  if (!rawFormal) {
    console.error('[AXLE /verify] Missing formal_statement (required by verify_proof API)')
    return NextResponse.json(
      {
        verified: false,
        error_message:
          'Server misconfiguration: formal_statement missing. The game must send level.formalStatement with the verify request.',
        goal_state_after: null,
        mock: false,
      },
      { status: 400 }
    )
  }

  const content = ensureMathlibImport(rawContent)
  const formal_statement = ensureMathlibImport(rawFormal)
  const environment = defaultAxleEnv()

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), AXLE_TIMEOUT_MS)

  try {
    const url = `${AXLE_BASE}/verify_proof`
    console.log(`[AXLE /verify] POST ${url} env=${environment} keyLen=${apiKey.length}`)

    const axleRes = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        content,
        formal_statement,
        environment,
        ignore_imports: body?.ignore_imports ?? true,
        timeout_seconds: 120,
      }),
      signal: controller.signal,
    })

    const rawText = await axleRes.text()
    console.error('AXLE status:', axleRes.status)
    console.error('AXLE raw:', rawText)

    let data: Record<string, unknown> = {}
    try {
      data = JSON.parse(rawText) as Record<string, unknown>
    } catch {
      data = { parseError: rawText }
    }

    if (!axleRes.ok) {
      console.error(`[AXLE /verify] HTTP ${axleRes.status}: ${rawText}`)
      return NextResponse.json({
        verified: false,
        error_message: `AXLE returned HTTP ${axleRes.status}`,
        goal_state_after: null,
        mock: false,
      })
    }

    const okay = data.okay === true
    const errMsg = okay ? null : firstAxleErrorMessage(data) ?? 'Proof verification failed'

    return NextResponse.json({
      verified: okay,
      error_message: errMsg,
      goal_state_after: (typeof data.goal_state === 'string' ? data.goal_state : null) as string | null,
      mock: false,
    })
  } catch (error: unknown) {
    const isTimeout =
      error instanceof DOMException && error.name === 'AbortError'
    const msg = isTimeout
      ? 'AXLE verification timed out'
      : error instanceof Error ? error.message : 'Unknown error'
    console.error(`[AXLE /verify] ${isTimeout ? 'TIMEOUT' : 'ERROR'}: ${msg}`)
    return NextResponse.json({
      verified: false,
      error_message: msg,
      goal_state_after: null,
      mock: false,
    })
  } finally {
    clearTimeout(timeout)
  }
}
