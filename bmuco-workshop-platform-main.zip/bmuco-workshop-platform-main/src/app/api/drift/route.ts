export async function POST() {
  // TODO: internal model endpoint
  return Response.json({ ok: false, error: 'Not implemented' }, { status: 501 })
}
