import { NextResponse } from 'next/server'
import { AXLE_BASE, AXLE_TIMEOUT_MS, defaultAxleEnv, getAxleApiKey } from '@/lib/axle-env'

export async function POST(req: Request) {
  const apiKey = getAxleApiKey()
  const isMock = !apiKey

  const body = await req.json()
  const content = body?.content ?? body?.partial_proof ?? ''

  if (isMock) {
    console.log('[AXLE /check] No AXLE_API_KEY or AXIOMMATH_API_KEY — returning mock')
    return NextResponse.json({
      ok: true,
      has_errors: false,
      message: 'No errors so far — keep going',
      goal_state: null,
      mock: true,
      result: { okay: true, lean_messages: { errors: [] } },
    })
  }

  const environment = defaultAxleEnv()

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), AXLE_TIMEOUT_MS)

  try {
    const url = `${AXLE_BASE}/check`
    console.log(`[AXLE /check] POST ${url} env=${environment} keyLen=${apiKey.length}`)

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        content,
        environment,
        ignore_imports: body?.ignore_imports ?? true,
        timeout_seconds: 120,
      }),
      signal: controller.signal,
    })

    if (!response.ok) {
      const errorText = await response.text().catch(() => '')
      console.error(`[AXLE /check] HTTP ${response.status}: ${errorText}`)
      return NextResponse.json({
        ok: false,
        has_errors: true,
        error: `AXLE returned HTTP ${response.status}`,
        message: `AXLE returned HTTP ${response.status}`,
        goal_state: null,
        mock: false,
        result: { okay: false, lean_messages: { errors: [{ message: `AXLE returned HTTP ${response.status}` }] } },
      })
    }

    const data = await response.json()
    console.log(`[AXLE /check] okay=${data?.okay}`)

    const hasErrors = !(data.okay ?? true)
    const leanErrors = Array.isArray(data.lean_messages?.errors) ? data.lean_messages.errors : []
    const msg = data.error ?? 'No errors so far — keep going'

    return NextResponse.json({
      ok: !hasErrors,
      has_errors: hasErrors,
      error: hasErrors ? msg : undefined,
      message: msg,
      goal_state: data.goal_state ?? null,
      mock: false,
      result: {
        okay: !hasErrors,
        lean_messages: { errors: leanErrors },
        goal_state: data.goal_state ?? null,
      },
    })
  } catch (error: unknown) {
    const isTimeout =
      error instanceof DOMException && error.name === 'AbortError'
    const msg = isTimeout
      ? 'AXLE check timed out'
      : error instanceof Error ? error.message : 'Unknown error'
    console.error(`[AXLE /check] ${isTimeout ? 'TIMEOUT' : 'ERROR'}: ${msg}`)
    return NextResponse.json({
      ok: false,
      has_errors: true,
      error: msg,
      message: msg,
      goal_state: null,
      mock: false,
      result: { okay: false, lean_messages: { errors: [{ message: msg }] } },
    })
  } finally {
    clearTimeout(timeout)
  }
}
