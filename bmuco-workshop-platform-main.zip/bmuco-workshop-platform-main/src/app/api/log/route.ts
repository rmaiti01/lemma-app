import { createClient } from '@/lib/supabase/server'

export async function POST(req: Request) {
  const body = await req.json()
  const { session_id, level_id, events } = body

  console.log('[BMUCO SERVER LOG]', JSON.stringify(body, null, 2))

  const supabase = createClient()
  const { error } = await supabase
    .from('bmuco_events')
    .insert((events || []).map((e: any) => ({
      session_id,
      level_id,
      mode: e.mode,
      step_id: e.step_id,
      event: e.event,
      value: e.value,
      duration_ms: e.duration_ms,
      confidence: e.confidence,
      annotation: e.annotation,
    })))

  if (error) {
    console.error('[BMUCO] Supabase insert error', error)
    return Response.json({ ok: false, error: error.message }, { status: 500 })
  }

  return Response.json({ ok: true })
}
