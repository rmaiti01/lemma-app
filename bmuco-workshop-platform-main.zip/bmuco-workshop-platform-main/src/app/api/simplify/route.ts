import { NextResponse } from 'next/server'
import {
  AXLE_BASE,
  AXLE_TIMEOUT_MS,
  defaultAxleEnv,
  ensureMathlibImport,
  getAxleApiKey,
  leanErrorsCount,
} from '@/lib/axle-env'

export async function POST(req: Request) {
  const apiKey = getAxleApiKey()
  const isMock = !apiKey

  const body = await req.json()
  const raw = (body?.content ?? '').trim()

  if (isMock) {
    console.log('[AXLE /simplify] No API key — mock')
    return NextResponse.json({
      simplified: false,
      content: null,
      mock: true,
    })
  }

  if (!raw) {
    return NextResponse.json(
      { simplified: false, content: null, error_message: 'Missing content', mock: false },
      { status: 400 }
    )
  }

  const content = ensureMathlibImport(raw)
  const environment = defaultAxleEnv()

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), AXLE_TIMEOUT_MS)

  try {
    const url = `${AXLE_BASE}/simplify_theorems`
    console.log(`[AXLE /simplify] POST ${url} env=${environment}`)

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        content,
        environment,
        ignore_imports: body?.ignore_imports ?? true,
        timeout_seconds: body?.timeout_seconds ?? 120,
      }),
      signal: controller.signal,
    })

    const rawText = await response.text()
    let data: Record<string, unknown> = {}
    try {
      data = JSON.parse(rawText) as Record<string, unknown>
    } catch {
      data = {}
    }

    if (!response.ok) {
      console.error(`[AXLE /simplify] HTTP ${response.status}: ${rawText}`)
      return NextResponse.json({
        simplified: false,
        content: null,
        mock: false,
        error_message: `AXLE HTTP ${response.status}`,
      })
    }

    const errCount = leanErrorsCount(data as { lean_messages?: { errors?: unknown[] } })
    const out =
      typeof data.content === 'string' && data.content.trim() ? data.content.trim() : null
    const stats = data.simplification_stats as Record<string, number> | undefined
    const statsSum =
      stats && typeof stats === 'object'
        ? Object.values(stats).reduce((a, v) => a + (typeof v === 'number' ? v : 0), 0)
        : 0

    const didSimplify =
      errCount === 0 &&
      out != null &&
      (statsSum > 0 || out.trim() !== content.trim())

    return NextResponse.json({
      simplified: didSimplify,
      content: errCount > 0 ? null : out,
      mock: false,
      error_message: errCount > 0 ? 'Lean errors after simplify' : null,
    })
  } catch (error: unknown) {
    const isTimeout = error instanceof DOMException && error.name === 'AbortError'
    const msg = isTimeout ? 'AXLE simplify timed out' : error instanceof Error ? error.message : 'Unknown error'
    console.error(`[AXLE /simplify] ${msg}`)
    return NextResponse.json({
      simplified: false,
      content: null,
      mock: false,
      error_message: msg,
    })
  } finally {
    clearTimeout(timeout)
  }
}
