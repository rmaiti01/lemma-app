'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import LevelPlayer from '@/components/game/LevelPlayer'
import type { GameLevel } from '@/lib/game-types'
import { WORLD_1_LEVELS } from '@/lib/world1-data'

const FIRST_FILL_IN_LEVEL_ID = WORLD_1_LEVELS[0]?.id ?? 'w1_l1'

interface WorldPlayClientProps {
  worldId: number
  levels: GameLevel[]
  userId: string | null
  completedLevelIds?: number[]
}

export default function WorldPlayClient({
  worldId,
  levels,
  userId,
  completedLevelIds = [],
}: WorldPlayClientProps) {
  const router = useRouter()
  const [currentIndex, setCurrentIndex] = useState(0)
  const [localCompleted, setLocalCompleted] = useState<Set<number>>(new Set(completedLevelIds))
  const level = levels[currentIndex]
  const isLast = currentIndex >= levels.length - 1

  /** Smell-test (MCQ) World 1 → first fill-in-the-blank level after level 6 or after the final MCQ level (e.g. boss). */
  const bridgeMcqToFillIn = () => {
    router.push(`/studio/worlds/1/levels/${FIRST_FILL_IN_LEVEL_ID}?mode=build`)
  }

  const handleNextLevel = () => {
    setLocalCompleted(prev => new Set(prev).add(level.id))
    if (worldId === 1) {
      const afterSmellTestRun =
        level.level_number === 6 || isLast
      if (afterSmellTestRun) {
        bridgeMcqToFillIn()
        return
      }
    }
    if (!isLast) {
      setCurrentIndex(prev => prev + 1)
    }
  }

  const showNextButton = !isLast || (worldId === 1 && isLast)

  const nextLevelLabel =
    worldId === 1 && (level.level_number === 6 || isLast)
      ? 'Continue to fill-in proofs →'
      : isLast
        ? undefined
        : levels[currentIndex + 1]?.is_boss
          ? 'Boss Level'
          : `Level ${levels[currentIndex + 1]?.level_number}`

  return (
    <div>
      {/* Level selector */}
      <div style={{
        display: 'flex',
        gap: 6,
        marginBottom: 32,
        flexWrap: 'wrap',
      }}>
        {levels.map((l, i) => {
          const done = localCompleted.has(l.id)
          return (
            <button
              key={l.id}
              onClick={() => setCurrentIndex(i)}
              style={{
                padding: '8px 16px',
                fontSize: 13,
                fontWeight: i === currentIndex ? 600 : 500,
                border: '1px solid',
                borderColor: i === currentIndex ? '#3b82f6' : done ? 'rgba(59, 130, 246, 0.4)' : 'var(--color-border)',
                borderRadius: 6,
                background: i === currentIndex ? 'rgba(59, 130, 246, 0.08)' : done ? 'rgba(59, 130, 246, 0.04)' : 'var(--color-surface)',
                color: i === currentIndex ? '#3b82f6' : done ? '#3b82f6' : 'var(--color-text-secondary)',
                cursor: 'pointer',
                transition: 'all 150ms',
                display: 'inline-flex',
                alignItems: 'center',
                gap: 4,
              }}
            >
              {done && <span style={{ fontSize: 11 }}>&#x2713;</span>}
              {l.is_boss ? 'Boss' : `${l.level_number}`}
            </button>
          )
        })}
      </div>

      {/* Current level */}
      <LevelPlayer
        key={level.id}
        level={level}
        isBoss={level.is_boss}
        userId={userId}
        onNextLevel={showNextButton ? handleNextLevel : undefined}
        nextLevelLabel={showNextButton ? nextLevelLabel : undefined}
      />
    </div>
  )
}
