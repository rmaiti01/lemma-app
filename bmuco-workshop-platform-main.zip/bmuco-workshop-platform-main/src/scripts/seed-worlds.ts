// BMUCO Studio — Seed Script
// Run: npx tsx src/scripts/seed-worlds.ts
// Requires SUPABASE_SERVICE_ROLE_KEY in .env.local

import { createClient } from '@supabase/supabase-js'
import {
  WORLD_1,
  WORLD_1_LEVELS,
  WORLD_2,
  WORLD_2_LEVELS,
  LOCKED_WORLDS,
} from '../lib/seed-data/world1-levels'
import { assertWorld2SeedAlignedWithRegistry } from '../lib/worlds-registry'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !serviceRoleKey) {
  console.error('Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in environment')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, serviceRoleKey, {
  auth: { persistSession: false },
})

async function seed() {
  assertWorld2SeedAlignedWithRegistry()
  console.log('Seeding game worlds and levels...\n')

  // 1. Upsert all worlds (World 1 + locked placeholders)
  const allWorlds = [WORLD_1, WORLD_2, ...LOCKED_WORLDS]
  const { error: worldErr } = await supabase
    .from('game_worlds')
    .upsert(allWorlds, { onConflict: 'id' })

  if (worldErr) {
    console.error('Failed to insert worlds:', worldErr.message)
    process.exit(1)
  }
  console.log(`  Inserted ${allWorlds.length} worlds`)

  // 2. Upsert World 1 levels
  const { error: levelErr } = await supabase
    .from('game_levels')
    .upsert(WORLD_1_LEVELS, { onConflict: 'world_id,level_number' })

  if (levelErr) {
    console.error('Failed to insert levels:', levelErr.message)
    process.exit(1)
  }
  console.log(`  Inserted ${WORLD_1_LEVELS.length} levels for World 1`)

  const { error: w2Err } = await supabase
    .from('game_levels')
    .upsert(WORLD_2_LEVELS, { onConflict: 'world_id,level_number' })

  if (w2Err) {
    console.error('Failed to insert World 2 levels:', w2Err.message)
    process.exit(1)
  }
  console.log(`  Inserted ${WORLD_2_LEVELS.length} levels for World 2`)

  console.log('\nDone!')
}

seed()
