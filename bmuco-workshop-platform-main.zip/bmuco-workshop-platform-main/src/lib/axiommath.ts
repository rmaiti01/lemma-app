// BMUCO Studio — AxiomMath AXLE API Client
// Docs: https://axle.axiommath.ai/

const BASE_URL = process.env.AXLE_BASE || 'https://axle.axiommath.ai/api/v1'
const DEFAULT_ENV = process.env.AXLE_ENV || 'lean-4.28.0'

// ── Types ──────────────────────────────────────────

export interface AxleTimings {
  total_ms?: number
  lean_ms?: number
  [key: string]: number | undefined
}

export interface AxleMessage {
  severity: string
  message: string
  pos?: { line: number; column: number }
  endPos?: { line: number; column: number }
}

export interface AxleBaseResponse {
  okay: boolean
  content: string
  lean_messages: Record<string, AxleMessage[]>
  tool_messages: Record<string, AxleMessage[]>
  failed_declarations: string[]
  timings: AxleTimings
}

export interface AxleCheckRequest {
  content: string
  environment?: string
  mathlib_linter?: boolean
  ignore_imports?: boolean
  timeout_seconds?: number
}

export interface AxleVerifyProofRequest {
  formal_statement: string
  content: string
  environment?: string
  permitted_sorries?: string[]
  mathlib_linter?: boolean
  use_def_eq?: boolean
  ignore_imports?: boolean
  timeout_seconds?: number
}

export interface AxleExtractTheoremsRequest {
  content: string
  environment?: string
  ignore_imports?: boolean
  timeout_seconds?: number
}

export interface AxleTheoremDocument {
  declaration: string
  content: string
  signature: string
  type: string
  is_sorry: boolean
  line_pos: number
  proof_length: number
  tactic_counts: Record<string, number>
}

export interface AxleExtractTheoremsResponse extends AxleBaseResponse {
  documents: Record<string, AxleTheoremDocument>
}

export interface AxleTransformRequest {
  content: string
  names?: string[]
  indices?: number[]
  environment?: string
  ignore_imports?: boolean
  timeout_seconds?: number
}

// ── API Client ─────────────────────────────────────

function getHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  }
  const apiKey = process.env.AXLE_API_KEY || process.env.AXIOMMATH_API_KEY
  if (apiKey) {
    headers['Authorization'] = `Bearer ${apiKey}`
  }
  return headers
}

async function axlePost<T = AxleBaseResponse>(endpoint: string, body: Record<string, unknown>): Promise<T> {
  const res = await fetch(`${BASE_URL}/${endpoint}`, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify(body),
  })

  if (!res.ok) {
    const text = await res.text().catch(() => 'Unknown error')
    throw new Error(`AXLE API error (${res.status}): ${text}`)
  }

  return res.json()
}

// ── Public API ─────────────────────────────────────

export async function check(req: AxleCheckRequest): Promise<AxleBaseResponse> {
  return axlePost('check', {
    content: req.content,
    environment: req.environment || DEFAULT_ENV,
    mathlib_linter: req.mathlib_linter ?? false,
    ignore_imports: req.ignore_imports ?? false,
    timeout_seconds: req.timeout_seconds ?? 120,
  })
}

export async function verifyProof(req: AxleVerifyProofRequest): Promise<AxleBaseResponse> {
  return axlePost('verify_proof', {
    formal_statement: req.formal_statement,
    content: req.content,
    environment: req.environment || DEFAULT_ENV,
    permitted_sorries: req.permitted_sorries,
    mathlib_linter: req.mathlib_linter ?? false,
    use_def_eq: req.use_def_eq ?? true,
    ignore_imports: req.ignore_imports ?? false,
    timeout_seconds: req.timeout_seconds ?? 120,
  })
}

export async function extractTheorems(req: AxleExtractTheoremsRequest): Promise<AxleExtractTheoremsResponse> {
  return axlePost<AxleExtractTheoremsResponse>('extract_theorems', {
    content: req.content,
    environment: req.environment || DEFAULT_ENV,
    ignore_imports: req.ignore_imports ?? false,
    timeout_seconds: req.timeout_seconds ?? 120,
  })
}

export async function theorem2sorry(req: AxleTransformRequest): Promise<AxleBaseResponse> {
  return axlePost('theorem2sorry', {
    content: req.content,
    names: req.names,
    indices: req.indices,
    environment: req.environment || DEFAULT_ENV,
    ignore_imports: req.ignore_imports ?? false,
    timeout_seconds: req.timeout_seconds ?? 120,
  })
}

export async function have2sorry(req: AxleTransformRequest): Promise<AxleBaseResponse> {
  return axlePost('have2sorry', {
    content: req.content,
    names: req.names,
    indices: req.indices,
    environment: req.environment || DEFAULT_ENV,
    ignore_imports: req.ignore_imports ?? false,
    timeout_seconds: req.timeout_seconds ?? 120,
  })
}
