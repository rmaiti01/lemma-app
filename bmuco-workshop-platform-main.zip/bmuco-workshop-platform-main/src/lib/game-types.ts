// BMUCO Studio — Game Type System

export interface GameWorld {
  id: number
  name: string
  slug: string
  description: string | null
  type: string
  unlock_stars: number
  is_active: boolean
}

export interface GameLevel {
  id: number
  world_id: number
  level_number: number
  title: string
  skill_tag: string | null
  proof_display: string
  informal_statement: string | null
  issues: LevelIssue[]
  decoys: LevelDecoy[]
  total_issues: number
  is_boss: boolean
}

export interface LevelIssue {
  id: string
  label: string
  explanation: string
  is_real_issue: true
}

export interface LevelDecoy {
  id: string
  label: string
  is_real_issue: false
}

export type ChecklistItem = {
  id: string
  label: string
  is_real_issue: boolean
}

export interface PlayerProgress {
  user_id: string
  total_stars: number
  total_points: number
  current_streak: number
  longest_streak: number
  last_played_at: string | null
  created_at: string
}

export interface LevelCompletion {
  id: number
  user_id: string
  level_id: number
  stars: number
  points: number
  issues_found: string[]
  issues_missed: string[]
  false_positives: string[]
  time_seconds: number | null
  completed_at: string
  /** True when this row was the first successful completion for this user+level (set on insert only). */
  is_first_completion?: boolean
}

export interface GameTrace {
  session_id: string | null
  user_id: string | null
  level_id: number
  world_id: number
  level_number: number
  proof_shown: string
  issues_identified: string[]
  issues_missed: string[]
  false_positives: string[]
  stars_earned: number
  points_earned: number
  time_seconds: number | null
  player_skill: string
}

export interface LeaderboardEntry {
  user_id: string
  github_username: string
  avatar_url: string | null
  total_stars: number
  total_points: number
  current_streak: number
  rank: number
}

export interface ScoreResult {
  stars: 0 | 1 | 2 | 3
  points: number
  issuesFound: string[]
  issuesMissed: string[]
  falsePositives: string[]
}

export interface ProofPacket {
  session_id: string
  user_id: string | null
  level_id: string
  world_id: number | null
  mode: 'mcq' | 'build' | 'trace' | 'review'

  proof_state_before: string
  tactic_chosen: string | null
  proof_state_after: string | null
  tactic_success: boolean

  tactics_rejected: Array<{ tactic: string; reason: string; was_attempted: boolean }>
  premises_used: string[]
  premises_available: string[]

  confidence: number | null
  time_to_decision_ms: number | null
  hints_used_this_step: number
  hint_content: string | null

  user_reasoning: string | null
  expert_explanation: string | null

  axle_endpoint: string | null
  axle_response_ok: boolean | null
  axle_duration_ms: number | null
  axle_error_message: string | null

  step_number: number
  total_steps: number | null

  difficulty_rating: number | null
  topic_tags: string[]
  dimension: string | null
  dataset_label: string | null
  /** Set by the server from `level_completions`; omit when sending from the client. */
  is_first_attempt?: boolean
  /** Prior completed sessions for this level; set by the server. */
  previous_attempts_count?: number
}
