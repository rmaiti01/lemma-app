// BMUCO Studio — World 1 Scoring

import type { W1Level } from './world1-data'

export interface W1ScoreBreakdown {
  score: number
  stars: 1 | 2 | 3
  base: number
  attemptPenalty: number
  verdictBonus: number
  reasoningBonus: number
  correctVerdictBonus: number
  hintPenalty: number
}

export function calculateW1Score(
  level: W1Level,
  blankStates: Record<
    string,
    {
      accepted: boolean | null
      attempts: string[]
      reasoning: string
      hintLevel: number
    }
  >,
  verdict: string | null
): W1ScoreBreakdown {
  let base = 0
  let attemptPenalty = 0
  let hintPenalty = 0
  let allReasoned = true

  for (const blank of level.blanks) {
    const state = blankStates[blank.id]
    if (!state) {
      allReasoned = false
      continue
    }

    // Base: 100 per blank correct on first attempt
    if (state.accepted === true) {
      base += 100
    }

    // Penalty: -15 per failed attempt per blank
    const failedAttempts = Math.max(0, state.attempts.length - (state.accepted ? 1 : 0))
    attemptPenalty += failedAttempts * 15

    // Penalty: -25 per Hint tier 3 used
    if (state.hintLevel >= 3) {
      hintPenalty += 25
    }

    if (!state.reasoning || state.reasoning.trim() === '') {
      allReasoned = false
    }
  }

  // Bonus: +50 if verdict is filled
  const verdictBonus = verdict ? 50 : 0

  // Bonus: +30 if ALL blanks have reasoning filled
  const reasoningBonus = allReasoned ? 30 : 0

  // Bonus: +20 if verdict is correct
  let correctVerdictBonus = 0
  if (verdict) {
    const correctVerdict = level.type === 'A' ? 'works' : 'broken'
    if (verdict === correctVerdict) {
      correctVerdictBonus = 20
    }
  }

  const score = Math.max(
    0,
    base - attemptPenalty + verdictBonus + reasoningBonus + correctVerdictBonus - hintPenalty
  )

  const stars: 1 | 2 | 3 = score >= 250 ? 3 : score >= 150 ? 2 : 1

  return {
    score,
    stars,
    base,
    attemptPenalty,
    verdictBonus,
    reasoningBonus,
    correctVerdictBonus,
    hintPenalty,
  }
}
