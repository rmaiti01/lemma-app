// Lemma — World 1 hardcoded level data

export interface HighlightedSentence {
  id: string
  text: string
  blankRef: string
}

export interface InformalProof {
  statement: string
  text: string
  highlightedSentences: HighlightedSentence[]
}

export interface BlankDef {
  id: string
  hints: [string, string, string]
}

export interface ReviewIssue {
  id: string
  text: string
  correct: boolean
}

export interface TraceStepAlt {
  tactic: string
  why_rejected: string
}

export interface RichTraceStep {
  id: string
  step_number: number
  total_steps: number
  tactic: string
  goal_before: string
  goal_after: string | string[]
  context: string
  annotation_prompt: string
  explanation_if_skipped: string
  alternatives: TraceStepAlt[]
  dimension: string
  dataset_label: string
}

export interface TraceStep {
  id: string
  code: string
}

export interface W1Level {
  id: string
  number: number
  theorem: string
  type: 'A' | 'B'
  isTrap: boolean
  locked?: boolean
  informalProof: InformalProof
  leanSkeleton: string
  blanks: BlankDef[]
  correctAnswers: string[]
  correctBlanks?: string[]
  formalStatement: string
  leanFullProof?: string
  /** When set, Review mode shows this bloated proof instead of leanFullProof (canonical proof stays separate). */
  reviewProofDisplay?: string
  reviewIssues?: ReviewIssue[]
  traceSteps?: TraceStep[]
  richTraceSteps?: RichTraceStep[]
}

const LEVEL_1_FULL_PROOF = `import Mathlib

namespace LemmaWorld1

theorem zero_add (n : ℕ) : 0 + n = n := by
  induction n with
  | zero =>
    rfl
  | succ k ih =>
    simp [Nat.succ_add, ih]

end LemmaWorld1`

const LEVEL_2_FULL_PROOF = `import Mathlib

namespace LemmaWorld1

theorem succ_ne_zero (n : ℕ) : n.succ ≠ 0 := by
  exact Nat.succ_ne_zero n

end LemmaWorld1`

function makeLockedLevel(number: number, theorem: string): W1Level {
  return {
    id: `w1_l${number}`,
    number,
    theorem,
    type: 'A',
    isTrap: false,
    locked: true,
    informalProof: {
      statement: '',
      text: '',
      highlightedSentences: [],
    },
    leanSkeleton: '',
    blanks: [],
    correctAnswers: [],
    formalStatement: '',
  }
}

export const WORLD_1_LEVELS: W1Level[] = [
  {
    id: 'w1_l1',
    number: 1,
    theorem: 'zero_add',
    type: 'A',
    isTrap: false,
    informalProof: {
      statement: '0 + n = n for all natural numbers n',
      text: 'We prove this by induction on n. Base case: 0 + 0 = 0 by definition. Inductive step: assume 0 + n = n, then 0 + succ(n) = succ(0 + n) = succ(n) by IH.',
      highlightedSentences: [
        { id: 'h1', text: 'Base case: 0 + 0 = 0 by definition.', blankRef: 'b1' },
        { id: 'h2', text: '0 + succ(n) = succ(0 + n) = succ(n) by IH.', blankRef: 'b2' },
      ],
    },
    leanSkeleton: `import Mathlib

namespace LemmaWorld1

theorem zero_add (n : ℕ) : 0 + n = n := by
  induction n with
  | zero => [BLANK_1]
  | succ k ih => [BLANK_2]

end LemmaWorld1`,
    blanks: [
      {
        id: 'b1',
        hints: [
          'Base case goal is 0 + 0 = 0.',
          'This holds by definitional equality — no simp needed.',
          'rfl',
        ],
      },
      {
        id: 'b2',
        hints: [
          'Use the induction hypothesis ih.',
          'Simplify using ih in the succ branch.',
          'simp [ih]',
        ],
      },
    ],
    correctAnswers: ['rfl', 'simp [ih]'],
    correctBlanks: ['rfl', 'simp [ih]'],
    formalStatement: `import Mathlib

namespace LemmaWorld1

theorem zero_add (n : ℕ) : 0 + n = n := by
  sorry

end LemmaWorld1`,
    leanFullProof: LEVEL_1_FULL_PROOF,
    reviewIssues: [
      {
        id: 'i1',
        text: 'Could use simp [Nat.zero_add] instead of full induction',
        correct: true,
      },
      {
        id: 'i2',
        text: 'Proof style is heavier than a one-line Mathlib lemma',
        correct: true,
      },
      {
        id: 'i3',
        text: 'Induction is unnecessary if Nat.zero_add is available',
        correct: true,
      },
      {
        id: 'i4',
        text: 'Should use ℤ instead of ℕ',
        correct: false,
      },
      {
        id: 'i5',
        text: 'Theorem name add_zero_eq is incorrect',
        correct: false,
      },
    ],
    traceSteps: [
      { id: 's1', code: 'induction n with' },
      { id: 's2', code: '| zero => rfl' },
      { id: 's3', code: '| succ k ih =>' },
      { id: 's4', code: 'simp [Nat.succ_add, ih]' },
    ],
  },
  {
    id: 'w1_l2',
    number: 2,
    theorem: 'succ_ne_zero',
    type: 'A',
    isTrap: false,
    informalProof: {
      statement: 'For all n : ℕ, succ(n) ≠ 0',
      text: 'Follows from the fact that zero and succ are distinct constructors of ℕ. No contradiction is needed.',
      highlightedSentences: [
        {
          id: 'h1',
          text: 'zero and succ are distinct constructors of ℕ',
          blankRef: 'b1',
        },
      ],
    },
    leanSkeleton: `import Mathlib

namespace LemmaWorld1

theorem succ_ne_zero (n : ℕ) : n.succ ≠ 0 := by
  [BLANK_1]

end LemmaWorld1`,
    blanks: [
      {
        id: 'b1',
        hints: [
          'This follows from constructor inequality for Nat.',
          'Use Nat.succ_ne_zero directly.',
          'exact Nat.succ_ne_zero n',
        ],
      },
    ],
    correctAnswers: ['exact Nat.succ_ne_zero n'],
    correctBlanks: ['exact Nat.succ_ne_zero n'],
    formalStatement: `import Mathlib

namespace LemmaWorld1

theorem succ_ne_zero (n : ℕ) : n.succ ≠ 0 := by
  sorry

end LemmaWorld1`,
    leanFullProof: LEVEL_2_FULL_PROOF,
    reviewProofDisplay: `import Mathlib

namespace LemmaWorld1

theorem succ_ne_zero (n : ℕ) : n.succ ≠ 0 := by
  by_contra h
  have h1 : n.succ = 0 := by exact h
  cases h1

end LemmaWorld1`,
    reviewIssues: [
      {
        id: 'i1',
        text: 'Uses by_contra when exact closes it directly',
        correct: true,
      },
      {
        id: 'i2',
        text: 'Introduces unused hypothesis h',
        correct: true,
      },
      {
        id: 'i3',
        text: 'Wrong type annotation on n',
        correct: false,
      },
      {
        id: 'i4',
        text: 'Missing import Mathlib',
        correct: false,
      },
    ],
    richTraceSteps: [
      {
        id: 'step_1',
        step_number: 1,
        total_steps: 1,
        tactic: 'exact Nat.succ_ne_zero n',
        goal_before: '⊢ n.succ ≠ 0',
        goal_after: 'goals accomplished ✓',
        context: 'theorem succ_ne_zero (n : ℕ) : n.succ ≠ 0. This follows from constructor distinctness.',
        annotation_prompt: 'Why does exact Nat.succ_ne_zero work? What does Lean know about constructors?',
        explanation_if_skipped: 'Lean\'s type theory guarantees that distinct constructors produce distinct values (no confusion principle). Nat.succ_ne_zero is a library lemma encoding this: succ n ≠ 0 for any n.',
        alternatives: [
          { tactic: 'by_contra h; cases h', why_rejected: 'Works but roundabout — introduces contradiction then eliminates the impossible case' },
          { tactic: 'simp', why_rejected: 'simp may close it via Nat.succ_ne_zero but hides the reasoning' },
          {
            tactic: 'omega',
            why_rejected:
              'omega may close this by normalizing succ n to n+1, but it is overkill and hides the real reason: constructor distinctness. exact Nat.succ_ne_zero n is idiomatic.',
          },
          { tactic: 'decide', why_rejected: 'decide works for concrete values but not for universally quantified n' },
        ],
        dimension: 'tactic_selection',
        dataset_label: 'TACTIC_SELECTION — using exact with a library lemma vs contradiction strategies',
      },
    ],
  },
  {
    id: 'w1_l3',
    number: 3,
    theorem: 'add_zero',
    type: 'A' as const,
    isTrap: false,
    informalProof: {
      statement: 'n + 0 = n for all natural numbers n',
      text: 'This holds by the definition of addition on ℕ. The base case of Nat.add says n + 0 = n directly (definitional reduction), so rfl suffices.',
      highlightedSentences: [
        { id: 'h1', text: 'rfl suffices since n + 0 reduces to n by definition.', blankRef: 'b1' },
      ],
    },
    leanSkeleton: `import Mathlib

namespace LemmaWorld1

theorem add_zero (n : ℕ) : n + 0 = n := by
  [BLANK_1]

end LemmaWorld1`,
    blanks: [
      {
        id: 'b1',
        hints: [
          'n + 0 unfolds to n by definition of Nat.add.',
          'Both sides are definitionally equal.',
          'rfl',
        ],
      },
    ],
    correctAnswers: ['rfl'],
    correctBlanks: ['rfl'],
    formalStatement: `import Mathlib

namespace LemmaWorld1

theorem add_zero (n : ℕ) : n + 0 = n := by
  sorry

end LemmaWorld1`,
    reviewIssues: [
      { id: 'i1', text: 'Uses induction when rfl closes it immediately', correct: true },
      { id: 'i2', text: 'Contains multiple unnecessary rewrites', correct: true },
      { id: 'i3', text: 'Missing the Nat namespace qualifier', correct: false },
    ],
    richTraceSteps: [
      {
        id: 'step_1',
        step_number: 1,
        total_steps: 1,
        tactic: 'rfl',
        goal_before: '⊢ n + 0 = n',
        goal_after: 'goals accomplished ✓',
        context: 'theorem add_zero (n : ℕ) : n + 0 = n. n + 0 reduces to n by the base case of Nat.add.',
        annotation_prompt: 'Why does rfl work here but not for 0 + n = n?',
        explanation_if_skipped: 'Nat.add is defined by recursion on the second argument: n + 0 = n is the base case, so it holds by definition. But 0 + n requires induction because recursion is on the right operand.',
        alternatives: [
          { tactic: 'simp', why_rejected: 'Works but is heavier than rfl for definitional equality' },
          { tactic: 'omega', why_rejected: 'Closes it but obscures that the proof is definitional' },
          { tactic: 'induction n', why_rejected: 'Unnecessary — no induction needed for definitional equality' },
          { tactic: 'exact Nat.add_zero n', why_rejected: 'Correct term-mode proof but tactic mode rfl is cleaner' },
        ],
        dimension: 'tactic_selection',
        dataset_label: 'TACTIC_SELECTION — recognizing when rfl suffices vs when simp/induction is needed',
      },
    ],
  },
  {
    id: 'w1_l4',
    number: 4,
    theorem: 'add_succ',
    type: 'A' as const,
    isTrap: false,
    informalProof: {
      statement: 'n + succ(m) = succ(n + m) for all natural numbers n, m',
      text: 'This is the successor case of Nat.add: n + (m+1) = (n+m)+1. It holds definitionally.',
      highlightedSentences: [
        { id: 'h1', text: 'Holds definitionally by the successor case of Nat.add.', blankRef: 'b1' },
      ],
    },
    leanSkeleton: `import Mathlib

namespace LemmaWorld1

theorem add_succ (n m : ℕ) : n + Nat.succ m = Nat.succ (n + m) := by
  [BLANK_1]

end LemmaWorld1`,
    blanks: [
      {
        id: 'b1',
        hints: [
          'n + succ m unfolds to succ (n + m) by definition.',
          'Both sides are definitionally equal.',
          'rfl',
        ],
      },
    ],
    correctAnswers: ['rfl'],
    correctBlanks: ['rfl'],
    formalStatement: `import Mathlib

namespace LemmaWorld1

theorem add_succ (n m : ℕ) : n + Nat.succ m = Nat.succ (n + m) := by
  sorry

end LemmaWorld1`,
    reviewIssues: [
      { id: 'i1', text: 'Uses simp when rfl is sufficient', correct: true },
      { id: 'i2', text: 'Should use omega for arithmetic', correct: false },
    ],
    richTraceSteps: [
      {
        id: 'step_1',
        step_number: 1,
        total_steps: 1,
        tactic: 'rfl',
        goal_before: '⊢ n + Nat.succ m = Nat.succ (n + m)',
        goal_after: 'goals accomplished ✓',
        context: 'theorem add_succ (n m : ℕ). The successor case of Nat.add gives n + succ m = succ (n + m) definitionally.',
        annotation_prompt: 'Both add_zero and add_succ are proved by rfl. What do they have in common structurally?',
        explanation_if_skipped: 'Both are direct consequences of how Nat.add is defined by pattern matching: n + 0 = n (base) and n + succ m = succ (n + m) (step). No induction is needed because these ARE the definition.',
        alternatives: [
          { tactic: 'simp [Nat.add_succ]', why_rejected: 'Correct but unnecessary since rfl already works' },
          { tactic: 'induction m', why_rejected: 'Induction is not needed for a definitional fact' },
          { tactic: 'omega', why_rejected: 'Works but hides the definitional nature of the proof' },
          { tactic: 'ring', why_rejected: 'ring does not apply to Nat.succ patterns' },
        ],
        dimension: 'generality_judgment',
        dataset_label: 'GENERALITY — recognizing definitional equality from the definition of Nat.add',
      },
    ],
  },
  {
    id: 'w1_l5',
    number: 5,
    theorem: 'add_comm',
    type: 'A' as const,
    isTrap: false,
    informalProof: {
      statement: 'n + m = m + n for all natural numbers n, m',
      text: 'We prove by induction on m. Base: n + 0 = n = 0 + n (using add_zero and zero_add). Step: n + succ(m) = succ(n + m) = succ(m + n) by IH = m + succ(n) using succ_add.',
      highlightedSentences: [
        { id: 'h1', text: 'Base case uses add_zero and zero_add.', blankRef: 'b1' },
        { id: 'h2', text: 'Inductive step uses IH and succ_add.', blankRef: 'b2' },
      ],
    },
    leanSkeleton: `import Mathlib

namespace LemmaWorld1

theorem add_comm (n m : ℕ) : n + m = m + n := by
  induction m with
  | zero => [BLANK_1]
  | succ k ih => [BLANK_2]

end LemmaWorld1`,
    blanks: [
      {
        id: 'b1',
        hints: [
          'Goal becomes n + 0 = 0 + n.',
          'Use the facts add_zero and zero_add.',
          'simp [Nat.add_zero, Nat.zero_add]',
        ],
      },
      {
        id: 'b2',
        hints: [
          'Goal becomes n + succ k = succ k + n.',
          'Rewrite using succ_add and the IH.',
          'rw [Nat.add_succ, Nat.succ_add, ih]',
        ],
      },
    ],
    correctAnswers: ['simp [Nat.add_zero, Nat.zero_add]', 'rw [Nat.add_succ, Nat.succ_add, ih]'],
    correctBlanks: ['simp [Nat.add_zero, Nat.zero_add]', 'rw [Nat.add_succ, Nat.succ_add, ih]'],
    formalStatement: `import Mathlib

namespace LemmaWorld1

theorem add_comm (n m : ℕ) : n + m = m + n := by
  sorry

end LemmaWorld1`,
    reviewIssues: [
      { id: 'i1', text: 'Uses omega instead of building on prior lemmas', correct: true },
      { id: 'i2', text: 'Does not demonstrate the recursive structure', correct: true },
      { id: 'i3', text: 'Induction variable should be n not m', correct: false },
    ],
    richTraceSteps: [
      {
        id: 'step_1',
        step_number: 1,
        total_steps: 4,
        tactic: 'induction m with',
        goal_before: '⊢ n + m = m + n',
        goal_after: ['| zero ⊢ n + 0 = 0 + n', '| succ k ih ⊢ n + Nat.succ k = Nat.succ k + n'],
        context: 'theorem add_comm (n m : ℕ) : n + m = m + n',
        annotation_prompt: 'Why induct on m rather than n? Does the choice matter?',
        explanation_if_skipped: 'Both work, but inducting on m means the base case is n + 0 = 0 + n which uses add_zero (definitional) and zero_add (proven earlier). The step case then uses add_succ and succ_add. Inducting on n would work symmetrically.',
        alternatives: [
          { tactic: 'omega', why_rejected: 'Closes it but bypasses the inductive structure entirely' },
          { tactic: 'simp [Nat.add_comm]', why_rejected: 'Circular — we are proving add_comm' },
          { tactic: 'ring', why_rejected: 'ring does not apply to recursively-defined Nat addition' },
          { tactic: 'induction n with', why_rejected: 'Would also work but we follow the convention of inducting on the second argument' },
        ],
        dimension: 'tactic_selection',
        dataset_label: 'TACTIC_SELECTION — choosing induction variable for commutativity',
      },
      {
        id: 'step_2',
        step_number: 2,
        total_steps: 4,
        tactic: 'simp [Nat.add_zero, Nat.zero_add]',
        goal_before: '⊢ n + 0 = 0 + n',
        goal_after: 'goals accomplished ✓',
        context: 'Base case: m = 0. Need to show n + 0 = 0 + n. add_zero gives n + 0 = n, zero_add gives 0 + n = n.',
        annotation_prompt: 'Which two lemmas does simp use here, and why are both needed?',
        explanation_if_skipped: 'Nat.add_zero : n + 0 = n (definitional, right side) and Nat.zero_add : 0 + n = n (requires proof, left side). simp rewrites both sides to n and closes with rfl.',
        alternatives: [
          { tactic: 'rfl', why_rejected: 'Fails because 0 + n is not definitionally equal to n (needs zero_add)' },
          { tactic: 'rw [Nat.add_zero, Nat.zero_add]', why_rejected: 'Would work but less concise than simp for two rewrites' },
          { tactic: 'omega', why_rejected: 'Works but does not demonstrate which lemmas are in play' },
          { tactic: 'exact Nat.add_zero n', why_rejected: 'Only rewrites one side; still leaves 0 + n unresolved' },
        ],
        dimension: 'lemma_retrieval',
        dataset_label: 'LEMMA_RETRIEVAL — combining add_zero and zero_add for the base case of commutativity',
      },
      {
        id: 'step_3',
        step_number: 3,
        total_steps: 4,
        tactic: 'rw [Nat.add_succ, Nat.succ_add]',
        goal_before: '⊢ n + Nat.succ k = Nat.succ k + n',
        goal_after: '⊢ Nat.succ (n + k) = Nat.succ (k + n)',
        context: 'Inductive step. ih : n + k = k + n is in scope. Need to expose the IH subterm.',
        annotation_prompt: 'What does each rewrite accomplish? Why this order?',
        explanation_if_skipped: 'Nat.add_succ rewrites n + succ k to succ (n + k). Nat.succ_add rewrites succ k + n to succ (k + n). After both, the goal becomes succ (n + k) = succ (k + n), which the IH can close.',
        alternatives: [
          { tactic: 'rw [ih]', why_rejected: 'ih rewrites n + k = k + n but the subterm is not yet exposed' },
          { tactic: 'simp [Nat.add_succ, Nat.succ_add, ih]', why_rejected: 'Works but hides the step-by-step reasoning' },
          { tactic: 'omega', why_rejected: 'Closes it but teaches nothing about how commutativity is built from succ lemmas' },
          { tactic: 'exact congrArg Nat.succ ih', why_rejected: 'Only works after the rewrites expose the right form' },
        ],
        dimension: 'lemma_retrieval',
        dataset_label: 'LEMMA_RETRIEVAL — using add_succ and succ_add to expose the IH in commutativity step',
      },
      {
        id: 'step_4',
        step_number: 4,
        total_steps: 4,
        tactic: 'rw [ih]',
        goal_before: '⊢ Nat.succ (n + k) = Nat.succ (k + n)',
        goal_after: 'goals accomplished ✓',
        context: 'ih : n + k = k + n. The subterm n + k appears on the left inside Nat.succ.',
        annotation_prompt: 'After rw [ih], why does the goal close automatically?',
        explanation_if_skipped: 'rw [ih] replaces n + k with k + n, making both sides Nat.succ (k + n). The goal becomes trivially true (rfl is applied automatically by rw when the result is a = a).',
        alternatives: [
          { tactic: 'exact congrArg Nat.succ ih', why_rejected: 'Correct term-mode proof but rw is more readable in tactic mode' },
          { tactic: 'simp [ih]', why_rejected: 'Works but heavier than rw for a direct substitution' },
          { tactic: 'assumption', why_rejected: 'ih is not literally the goal — it needs congruence under succ' },
          { tactic: 'rfl', why_rejected: 'Fails because n + k ≠ k + n definitionally' },
        ],
        dimension: 'dead_end_recognition',
        dataset_label: 'DEAD_END — understanding why rw [ih] works here but not before the succ rewrites',
      },
    ],
  },
  {
    id: 'w1_l6',
    number: 6,
    theorem: 'zero_mul',
    type: 'A' as const,
    isTrap: false,
    informalProof: {
      statement: '0 * n = 0 for all natural numbers n',
      text: 'We prove by induction on n. Base case: 0 * 0 = 0 by definition. Inductive step: 0 * succ(k) = 0 * k + 0 = 0 + 0 = 0 by the IH.',
      highlightedSentences: [
        { id: 'h1', text: 'Base case: 0 * 0 = 0 by definition.', blankRef: 'b1' },
        { id: 'h2', text: 'Inductive step uses IH and add_zero.', blankRef: 'b2' },
      ],
    },
    leanSkeleton: `import Mathlib

namespace LemmaWorld1

theorem zero_mul (n : ℕ) : 0 * n = 0 := by
  induction n with
  | zero => [BLANK_1]
  | succ k ih => [BLANK_2]

end LemmaWorld1`,
    blanks: [
      {
        id: 'b1',
        hints: [
          '0 * 0 reduces to 0 by the base case of Nat.mul.',
          'Both sides are definitionally equal.',
          'rfl',
        ],
      },
      {
        id: 'b2',
        hints: [
          '0 * succ k = 0 * k + 0 by definition of Nat.mul.',
          'Use the IH and the fact that x + 0 = x.',
          'simp [ih]',
        ],
      },
    ],
    correctAnswers: ['rfl', 'simp [ih]'],
    correctBlanks: ['rfl', 'simp [ih]'],
    formalStatement: `import Mathlib

namespace LemmaWorld1

theorem zero_mul (n : ℕ) : 0 * n = 0 := by
  sorry

end LemmaWorld1`,
    reviewIssues: [
      { id: 'i1', text: 'Uses omega instead of exposing the inductive structure', correct: true },
      { id: 'i2', text: 'Does not demonstrate the Nat.mul recursive definition', correct: true },
      { id: 'i3', text: 'Should use ring instead of induction', correct: false },
    ],
    richTraceSteps: [
      {
        id: 'step_1',
        step_number: 1,
        total_steps: 3,
        tactic: 'induction n with',
        goal_before: '⊢ 0 * n = 0',
        goal_after: ['| zero ⊢ 0 * 0 = 0', '| succ k ih ⊢ 0 * Nat.succ k = 0'],
        context: 'theorem zero_mul (n : ℕ) : 0 * n = 0',
        annotation_prompt: 'Compare: n * 0 = 0 is rfl, but 0 * n = 0 needs induction. Why?',
        explanation_if_skipped:
          'Nat.mul recurses on the RIGHT argument: n * 0 = 0 is the base case (definitional). But 0 * n requires unfolding the recursion on n step by step. This mirrors exactly why add_zero is rfl but zero_add needs induction.',
        alternatives: [
          {
            tactic: 'rfl',
            why_rejected:
              '0 * n is not definitionally 0 — mul recurses on the right, so 0 * succ n unfolds to 0 * n + 0, not 0 directly',
          },
          { tactic: 'simp', why_rejected: 'simp would use Nat.zero_mul from Mathlib, which is circular if we are proving it' },
          {
            tactic: 'omega',
            why_rejected: 'Closes it but does not show why induction is needed here and not for mul_zero',
          },
          { tactic: 'exact Nat.zero_mul n', why_rejected: 'Circular — we are proving zero_mul' },
        ],
        dimension: 'tactic_selection',
        dataset_label: 'TACTIC_SELECTION — why zero_mul needs induction when mul_zero is rfl',
      },
      {
        id: 'step_2',
        step_number: 2,
        total_steps: 3,
        tactic: 'rfl',
        goal_before: '⊢ 0 * 0 = 0',
        goal_after: 'goals accomplished ✓',
        context: 'Base case: n = 0. Nat.mul base case: n * 0 = 0, so 0 * 0 = 0 definitionally.',
        annotation_prompt: 'This rfl closes 0 * 0 = 0. Which clause of Nat.mul makes this definitional?',
        explanation_if_skipped:
          'Nat.mul is defined as: n * 0 = 0 (base) and n * succ m = n * m + n (step). The base clause directly gives 0 * 0 = 0 by reduction.',
        alternatives: [
          { tactic: 'simp', why_rejected: 'Works but rfl is exact for definitional equality' },
          { tactic: 'omega', why_rejected: 'Overkill for a base case that is definitional' },
          { tactic: 'norm_num', why_rejected: 'Works on concrete numerics but not idiomatic here' },
          { tactic: 'exact Nat.zero_mul 0', why_rejected: 'Circular if we are proving zero_mul' },
        ],
        dimension: 'generality_judgment',
        dataset_label: 'GENERALITY — base case of mul is definitional (n * 0 = 0)',
      },
      {
        id: 'step_3',
        step_number: 3,
        total_steps: 3,
        tactic: 'simp [ih]',
        goal_before: '⊢ 0 * Nat.succ k = 0',
        goal_after: 'goals accomplished ✓',
        context:
          'Inductive step. ih : 0 * k = 0. Nat.mul step: n * succ m = n * m + n, so 0 * succ k = 0 * k + 0.',
        annotation_prompt: 'What chain does simp [ih] perform? What would the explicit rw steps be?',
        explanation_if_skipped:
          'Nat.mul gives 0 * succ k = 0 * k + 0. simp rewrites 0 * k to 0 via ih, then simplifies 0 + 0 = 0. Explicitly: rw [Nat.mul_succ, ih, Nat.add_zero].',
        alternatives: [
          {
            tactic: 'rw [Nat.mul_succ, ih, Nat.add_zero]',
            why_rejected: 'Correct and more explicit, but simp [ih] is concise enough here',
          },
          { tactic: 'omega', why_rejected: 'Closes it but hides the mul recursion structure' },
          { tactic: 'rfl', why_rejected: 'Fails — 0 * succ k is not definitionally 0' },
          { tactic: 'exact ih', why_rejected: 'ih proves 0 * k = 0, not 0 * succ k = 0' },
        ],
        dimension: 'lemma_retrieval',
        dataset_label: 'LEMMA_RETRIEVAL — using IH with simp to close the inductive step of zero_mul',
      },
    ],
  },
  makeLockedLevel(7, 'add_assoc'),
  makeLockedLevel(8, 'mul_comm'),
]

export function getW1Level(levelId: string): W1Level | undefined {
  return WORLD_1_LEVELS.find(level => level.id === levelId)
}

export function getW1LevelByNumber(num: number): W1Level | undefined {
  return WORLD_1_LEVELS.find(level => level.number === num)
}
