// Mathlib naming convention dictionary
// Reference: https://leanprover-community.github.io/contribute/naming.html

export const NAMING_DICTIONARY: Record<string, string> = {
  // Operations
  '+': 'add',
  '*': 'mul',
  '-': 'sub',
  '/': 'div',
  '^': 'pow',
  '∣': 'dvd',
  '∘': 'comp',
  '⁻¹': 'inv',

  // Relations
  '=': 'eq',
  '≠': 'ne',
  '≤': 'le',
  '<': 'lt',
  '≥': 'ge',
  '>': 'gt',

  // Properties
  'commutative': 'comm',
  'associative': 'assoc',
  'distributive': 'distrib',
  'injective': 'injective',
  'surjective': 'surjective',
  'bijective': 'bijective',
  'monotone': 'monotone',
  'continuous': 'continuous',
  'symmetric': 'symm',
  'transitive': 'trans',
  'reflexive': 'refl',
  'idempotent': 'idem',

  // Common patterns
  'nonneg': 'nonneg',     // 0 ≤ x
  'pos': 'pos',           // 0 < x
  'nonpos': 'nonpos',     // x ≤ 0
  'neg': 'neg',           // x < 0
  'zero': 'zero',
  'one': 'one',
  'two': 'two',
  'succ': 'succ',
  'pred': 'pred',

  // Logical
  'and': 'and',
  'or': 'or',
  'not': 'not',
  'iff': 'iff',
  'implies': 'imp',
  'exists': 'exists',
  'forall': 'forall',

  // Types / Structures
  'natural': 'Nat',
  'integer': 'Int',
  'rational': 'Rat',
  'real': 'Real',
  'complex': 'Complex',
  'list': 'List',
  'set': 'Set',
  'finset': 'Finset',
  'group': 'Group',
  'ring': 'Ring',
  'field': 'Field',

  // Common predicates
  'even': 'Even',
  'odd': 'Odd',
  'prime': 'Prime',
  'irreducible': 'Irreducible',
  'unit': 'IsUnit',
}

export const NAMING_RULES = [
  'Use dot notation: if about Even, name starts with Even.',
  'Describe the conclusion, not the hypotheses',
  'Use lowercase_with_underscores for theorems',
  'Use CamelCase for types and structures',
  'Separate hypothesis descriptions with _of_',
  'Use _left/_right for variants of binary operations',
  'American English spelling (factorization, not factorisation)',
  'Avoid redundancy: Even.add, not Even.even_add',
  'The namespace gives context: Nat.Prime.mul, not Nat.prime_mul_is_prime',
]

// Examples for the reference panel
export const NAMING_EXAMPLES = [
  { name: 'Even.add', description: 'Sum of two even numbers is even', pattern: 'TypeName.operation' },
  { name: 'Nat.Prime.mul', description: 'About Nat.Prime and multiplication', pattern: 'Namespace.TypeName.operation' },
  { name: 'List.map_comp', description: 'About List.map and composition', pattern: 'TypeName.operation_qualifier' },
  { name: 'dvd_trans', description: 'Transitivity of divisibility', pattern: 'relation_property' },
  { name: 'add_comm', description: 'Commutativity of addition', pattern: 'operation_property' },
  { name: 'mul_left_cancel', description: 'Left cancellation of multiplication', pattern: 'operation_direction_property' },
  { name: 'Even.mul_right', description: 'Even * anything is even', pattern: 'TypeName.operation_direction' },
  { name: 'Odd.add_even', description: 'Odd + even = odd', pattern: 'TypeName.operation_qualifier' },
]

// Key terms to extract from theorem statements for name validation
const KEY_TERMS = [
  'Even', 'Odd', 'Prime', 'Nat', 'Int', 'Real', 'List', 'Set', 'Finset',
  'add', 'mul', 'sub', 'div', 'pow', 'dvd', 'comp',
  'comm', 'assoc', 'trans', 'refl', 'symm',
  'left', 'right', 'zero', 'one', 'two', 'succ',
]

export interface NamingValidation {
  level: 'green' | 'yellow' | 'red'
  message: string
  suggestions: string[]
}

/**
 * Validates a proposed Mathlib-style name against conventions.
 * This is an advisory tool, not a blocker.
 */
export function validateName(proposedName: string, theoremStatement: string): NamingValidation {
  const suggestions: string[] = []

  // Red: empty or clearly wrong
  if (!proposedName || proposedName.trim() === '') {
    return { level: 'red', message: 'Name is required.', suggestions: [] }
  }

  // Red: contains spaces
  if (proposedName.includes(' ')) {
    return {
      level: 'red',
      message: 'Name should not contain spaces. Use underscores or dot notation.',
      suggestions: ['Replace spaces with underscores or dots'],
    }
  }

  // Red: all uppercase (probably a type, not a theorem)
  if (proposedName === proposedName.toUpperCase() && proposedName.length > 2) {
    return {
      level: 'red',
      message: 'Theorem names should use lowercase_with_underscores, not ALL_CAPS.',
      suggestions: ['Use lowercase: ' + proposedName.toLowerCase()],
    }
  }

  // Check for dot notation (TypeName.operation)
  const hasDot = proposedName.includes('.')

  // Extract key terms from the theorem statement
  const statementTerms = KEY_TERMS.filter(term =>
    theoremStatement.toLowerCase().includes(term.toLowerCase())
  )

  // Check if key terms are reflected in the name
  const lowerName = proposedName.toLowerCase()
  const matchedTerms = statementTerms.filter(term =>
    lowerName.includes(term.toLowerCase())
  )

  // Check for common anti-patterns
  if (proposedName.includes('is_') || proposedName.includes('_is_')) {
    suggestions.push('Avoid "is_" in names — describe the conclusion directly')
  }

  if (proposedName.includes('theorem') || proposedName.includes('lemma')) {
    suggestions.push('Don\'t include "theorem" or "lemma" in the name')
  }

  // Check if using dot notation when a type is involved
  const typeTerms = ['Even', 'Odd', 'Prime', 'Nat', 'Int', 'List', 'Set', 'Finset']
  const relevantTypes = typeTerms.filter(t =>
    theoremStatement.includes(t)
  )

  if (relevantTypes.length > 0 && !hasDot) {
    suggestions.push(`Consider dot notation: ${relevantTypes[0]}.${proposedName}`)
  }

  // Score
  if (suggestions.length === 0 && hasDot && matchedTerms.length >= 2) {
    return {
      level: 'green',
      message: 'Name follows Mathlib conventions. ✓',
      suggestions: [],
    }
  }

  if (suggestions.length <= 1 && matchedTerms.length >= 1) {
    return {
      level: 'yellow',
      message: 'Name partially follows conventions.',
      suggestions,
    }
  }

  return {
    level: 'red',
    message: 'Name does not follow Mathlib conventions.',
    suggestions: suggestions.length > 0 ? suggestions : [
      'Use dot notation: TypeName.operation',
      'Include key terms from the theorem',
    ],
  }
}
