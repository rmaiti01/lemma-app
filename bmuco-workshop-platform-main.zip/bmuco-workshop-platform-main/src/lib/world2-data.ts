/**
 * World 2 (Style Police). Canonical level payloads are in seed-data/world1-levels.ts
 * (historic file name). Runtime MCQ play at /studio/play/2 loads rows from
 * game_levels where world_id = 2 (see migration 011 / 013 and seed-worlds.ts).
 */
export { WORLD_2, WORLD_2_LEVELS } from './seed-data/world1-levels'

/** URL-style ids, aligned with World 1’s w1_l{n} pattern (MCQ play uses DB numeric ids). */
export const WORLD_2_LEVEL_IDS = [
  'w2_l1',
  'w2_l2',
  'w2_l3',
  'w2_l4',
  'w2_l5',
  'w2_l6',
] as const

export type World2LevelSlug = (typeof WORLD_2_LEVEL_IDS)[number]

export function world2SlugFromLevelNumber(n: number): World2LevelSlug | null {
  if (n < 1 || n > WORLD_2_LEVEL_IDS.length) return null
  return WORLD_2_LEVEL_IDS[n - 1]
}
