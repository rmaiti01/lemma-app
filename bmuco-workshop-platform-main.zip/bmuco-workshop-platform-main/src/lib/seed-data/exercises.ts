// Exercise seed data for the Lemma platform
// 12 exercises across 3 difficulty tiers
// Tier 1 (5 exercises): Week 1-2, one-level proofs
// Tier 2 (3 exercises): Week 3-4, two-level proofs / Mathlib navigation
// Tier 3 (4 exercises): Week 5-6, AI review exercises

import { Exercise } from '../exercise-types'

type SeedExercise = Omit<Exercise, 'id' | 'created_at'>

export const SEED_EXERCISES: SeedExercise[] = [
  // ═══════════════════════════════════════════════════════
  // TIER 1 — Week 1-2: One-level proofs
  // ═══════════════════════════════════════════════════════

  {
    title: 'Sum of two even numbers is even',
    difficulty: 1,
    week: 1,
    category: 'original_formalization',
    nl_statement: 'If m and n are even natural numbers, then m + n is even.',
    nl_proof: 'Since m is even, there exists a such that m = 2a. Since n is even, there exists b such that n = 2b. Then m + n = 2a + 2b = 2(a + b), so m + n is even.',
    ai_lean_code: null,
    ai_failure_modes: null,
    reference_lean_code: `theorem Even.add {m n : ℤ} (hm : Even m) (hn : Even n) : Even (m + n) := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  exact ⟨a + b, by rw [ha, hb]; ring⟩`,
    reference_name: 'Even.add',
    mathlib_search_hints: ['Even', 'add', 'Int.even_add'],
    generality_notes: 'In Mathlib, Even is defined for any type with Add and exists k, m = k + k. The most general version works over any AddMonoid, not just ℤ or ℕ. Note: Even uses k + k, not 2 * k.',
    source: 'buzzard_course',
    tags: ['even', 'addition', 'number_theory', 'tier1'],
  },

  {
    title: 'Even plus two is even',
    difficulty: 1,
    week: 1,
    category: 'original_formalization',
    nl_statement: 'If n is an even integer, then n + 2 is even.',
    nl_proof: 'Since n is even, there exists k such that n = 2k. Then n + 2 = 2k + 2 = 2(k + 1), so n + 2 is even.',
    ai_lean_code: null,
    ai_failure_modes: null,
    reference_lean_code: `theorem Even.add_two {n : ℤ} (h : Even n) : Even (n + 2) := by
  exact h.add (even_two)`,
    reference_name: 'Even.add_two',
    mathlib_search_hints: ['Even', 'add', 'two', 'even_two'],
    generality_notes: 'This is a special case of Even.add. In Mathlib, even_two proves that 2 is even. The cleanest proof reuses Even.add.',
    source: 'buzzard_course',
    tags: ['even', 'addition', 'number_theory', 'tier1'],
  },

  {
    title: 'Odd plus even is odd',
    difficulty: 2,
    week: 1,
    category: 'original_formalization',
    nl_statement: 'If m is an odd integer and n is an even integer, then m + n is odd.',
    nl_proof: 'Since m is odd, there exists a such that m = 2a + 1. Since n is even, there exists b such that n = 2b. Then m + n = (2a + 1) + 2b = 2(a + b) + 1, so m + n is odd.',
    ai_lean_code: null,
    ai_failure_modes: null,
    reference_lean_code: `theorem Odd.add_even {m n : ℤ} (hm : Odd m) (hn : Even n) : Odd (m + n) := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  exact ⟨a + b, by rw [ha, hb]; ring⟩`,
    reference_name: 'Odd.add_even',
    mathlib_search_hints: ['Odd', 'Even', 'add', 'Int.odd_add'],
    generality_notes: 'Odd is defined as ∃ k, n = 2 * k + 1. Like Even, this generalizes beyond ℤ.',
    source: 'buzzard_course',
    tags: ['odd', 'even', 'addition', 'number_theory', 'tier1'],
  },

  {
    title: 'Odd plus odd is even',
    difficulty: 2,
    week: 2,
    category: 'original_formalization',
    nl_statement: 'If m and n are both odd integers, then m + n is even.',
    nl_proof: 'Since m is odd, m = 2a + 1 for some a. Since n is odd, n = 2b + 1 for some b. Then m + n = (2a + 1) + (2b + 1) = 2a + 2b + 2 = 2(a + b + 1), so m + n is even.',
    ai_lean_code: null,
    ai_failure_modes: null,
    reference_lean_code: `theorem Odd.add_odd {m n : ℤ} (hm : Odd m) (hn : Odd n) : Even (m + n) := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  exact ⟨a + b + 1, by rw [ha, hb]; ring⟩`,
    reference_name: 'Odd.add_odd',
    mathlib_search_hints: ['Odd', 'Even', 'add', 'Int.odd_add_odd'],
    generality_notes: 'The witness here is a + b + 1. Remember Even uses k + k, so we need m + n = (a+b+1) + (a+b+1).',
    source: 'buzzard_course',
    tags: ['odd', 'even', 'addition', 'number_theory', 'tier1'],
  },

  {
    title: 'Even times any is even',
    difficulty: 2,
    week: 2,
    category: 'original_formalization',
    nl_statement: 'If m is an even integer, then m * n is even for any integer n.',
    nl_proof: 'Since m is even, there exists k such that m = 2k. Then m * n = 2k * n = 2(k * n), so m * n is even.',
    ai_lean_code: null,
    ai_failure_modes: null,
    reference_lean_code: `theorem Even.mul_right {m : ℤ} (hm : Even m) (n : ℤ) : Even (m * n) := by
  obtain ⟨k, hk⟩ := hm
  exact ⟨k * n, by rw [hk]; ring⟩`,
    reference_name: 'Even.mul_right',
    mathlib_search_hints: ['Even', 'mul', 'mul_right'],
    generality_notes: 'Note the naming: mul_right because the even number is on the left. Mathlib also has Even.mul_left for the other direction. These generalize to any Monoid.',
    source: 'buzzard_course',
    tags: ['even', 'multiplication', 'number_theory', 'tier1'],
  },

  // ═══════════════════════════════════════════════════════
  // TIER 2 — Week 3-4: Two-level proofs, Mathlib navigation
  // ═══════════════════════════════════════════════════════

  {
    title: 'Sum of first n natural numbers',
    difficulty: 3,
    week: 3,
    category: 'original_formalization',
    nl_statement: 'For any natural number n, the sum 0 + 1 + 2 + ... + n equals n * (n + 1) / 2.',
    nl_proof: 'By induction on n. Base case: 0 = 0 * 1 / 2 = 0. ✓ Inductive step: Assume the sum up to n equals n(n+1)/2. Then the sum up to n+1 equals n(n+1)/2 + (n+1) = (n+1)(n/2 + 1) = (n+1)(n+2)/2. ✓',
    ai_lean_code: null,
    ai_failure_modes: null,
    reference_lean_code: `-- In Mathlib, this is Finset.sum_range_id_eq_sum or Gauss' formula
-- The exact statement uses Finset.sum and Finset.range
theorem sum_range_id (n : ℕ) :
    2 * (Finset.range n).sum id = n * (n - 1) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Finset.sum_range_succ, mul_add, ih]
    omega`,
    reference_name: 'Finset.sum_range_id',
    mathlib_search_hints: ['Finset.sum', 'Finset.range', 'Gauss', 'sum_range_id'],
    generality_notes: 'This already exists in Mathlib as Gauss\' sum. The key learning here is finding it using Moogle/LeanSearch rather than reproving it. Searching for "sum of first n" or "Gauss sum" should locate it.',
    source: 'custom',
    tags: ['induction', 'finset', 'sum', 'gauss', 'tier2'],
  },

  {
    title: 'Divisibility is transitive',
    difficulty: 3,
    week: 3,
    category: 'original_formalization',
    nl_statement: 'If a divides b and b divides c, then a divides c.',
    nl_proof: 'Since a | b, there exists k such that b = a * k. Since b | c, there exists l such that c = b * l. Then c = b * l = (a * k) * l = a * (k * l), so a | c.',
    ai_lean_code: null,
    ai_failure_modes: null,
    reference_lean_code: `-- This already exists in Mathlib as dvd_trans
-- The exercise is to FIND it, not reprove it
-- #check dvd_trans
-- dvd_trans : a ∣ b → b ∣ c → a ∣ c
-- It's in Mathlib.Order.Defs.PartialOrder

-- But if you wanted to prove it from scratch:
theorem dvd_trans' {a b c : ℤ} (hab : a ∣ b) (hbc : b ∣ c) : a ∣ c := by
  obtain ⟨k, hk⟩ := hab
  obtain ⟨l, hl⟩ := hbc
  exact ⟨k * l, by rw [hl, hk]; ring⟩`,
    reference_name: 'dvd_trans',
    mathlib_search_hints: ['dvd', 'trans', 'dvd_trans', 'Dvd'],
    generality_notes: 'dvd_trans already exists in Mathlib and works for any type with a Dvd instance. The real exercise here is learning to search Mathlib effectively. Use `exact?` to find it automatically.',
    source: 'custom',
    tags: ['divisibility', 'transitivity', 'search_exercise', 'tier2'],
  },

  {
    title: 'Product of two odd numbers is odd',
    difficulty: 3,
    week: 4,
    category: 'original_formalization',
    nl_statement: 'If m and n are both odd integers, then m * n is odd.',
    nl_proof: 'Since m is odd, m = 2a + 1. Since n is odd, n = 2b + 1. Then m * n = (2a + 1)(2b + 1) = 4ab + 2a + 2b + 1 = 2(2ab + a + b) + 1, which is odd.',
    ai_lean_code: null,
    ai_failure_modes: null,
    reference_lean_code: `theorem Odd.mul {m n : ℤ} (hm : Odd m) (hn : Odd n) : Odd (m * n) := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  exact ⟨2 * a * b + a + b, by rw [ha, hb]; ring⟩`,
    reference_name: 'Odd.mul',
    mathlib_search_hints: ['Odd', 'mul', 'Int.odd_mul'],
    generality_notes: 'The witness 2ab + a + b comes from expanding (2a+1)(2b+1) - 1 and dividing by 2. This is a two-step proof requiring careful algebraic manipulation.',
    source: 'custom',
    tags: ['odd', 'multiplication', 'number_theory', 'tier2'],
  },

  // ═══════════════════════════════════════════════════════
  // TIER 3 — Week 5-6: AI Review exercises
  // ═══════════════════════════════════════════════════════

  {
    title: 'AI Review: Sum of two even numbers',
    difficulty: 3,
    week: 5,
    category: 'ai_review',
    nl_statement: 'If m and n are even natural numbers, then m + n is even.',
    nl_proof: 'Since m is even, there exists a such that m = 2a. Since n is even, there exists b such that n = 2b. Then m + n = 2a + 2b = 2(a + b), so m + n is even.',
    ai_lean_code: `-- AI-generated Lean 4 code (contains quality issues)
theorem even_add_even (m n : ℕ) (hm : ∃ k, m = 2 * k) (hn : ∃ k, n = 2 * k) :
    ∃ k, m + n = 2 * k := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  use a + b
  omega`,
    ai_failure_modes: [
      { layer: 1, issue: 'Uses raw ∃ k, m = 2 * k instead of Even predicate', severity: 'high' },
      { layer: 4, issue: 'Hardcoded to ℕ instead of working over a general AddMonoid', severity: 'high' },
      { layer: 4, issue: 'Named even_add_even instead of Even.add (no dot notation)', severity: 'medium' },
      { layer: 3, issue: 'Uses omega instead of ring for the arithmetic step', severity: 'low' },
      { layer: 2, issue: 'Statement uses 2 * k instead of k + k (Mathlib convention for Even)', severity: 'medium' },
    ],
    reference_lean_code: `theorem Even.add {m n : ℤ} (hm : Even m) (hn : Even n) : Even (m + n) := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  exact ⟨a + b, by rw [ha, hb]; ring⟩`,
    reference_name: 'Even.add',
    mathlib_search_hints: ['Even', 'add'],
    generality_notes: 'The AI version compiles and is mathematically correct but fails Mathlib quality standards on multiple dimensions: wrong predicate, wrong generality, wrong naming convention, and suboptimal tactic choice.',
    source: 'custom',
    tags: ['even', 'addition', 'ai_review', 'tier3'],
  },

  {
    title: 'AI Review: Even plus two is even',
    difficulty: 3,
    week: 5,
    category: 'ai_review',
    nl_statement: 'If n is an even integer, then n + 2 is even.',
    nl_proof: 'Since n is even, there exists k such that n = 2k. Then n + 2 = 2k + 2 = 2(k + 1), so n + 2 is even.',
    ai_lean_code: `-- AI-generated Lean 4 code (contains quality issues)
theorem even_plus_two (n : Int) (h : Even n) : Even (n + 2) := by
  unfold Even at *
  obtain ⟨r, hr⟩ := h
  exact ⟨r + 1, by rw [hr]; ring⟩`,
    ai_failure_modes: [
      { layer: 4, issue: 'Named even_plus_two instead of Even.add_two (not using dot notation)', severity: 'medium' },
      { layer: 3, issue: 'Unnecessarily unfolds Even instead of using Even.add with even_two', severity: 'medium' },
      { layer: 4, issue: 'Uses Int instead of ℤ (notation preference)', severity: 'low' },
      { layer: 2, issue: 'Hypotheses are named h/r instead of descriptive names', severity: 'low' },
      { layer: 3, issue: 'Re-proves from scratch instead of composing existing lemmas (Even.add)', severity: 'high' },
    ],
    reference_lean_code: `theorem Even.add_two {n : ℤ} (h : Even n) : Even (n + 2) := by
  exact h.add (even_two)`,
    reference_name: 'Even.add_two',
    mathlib_search_hints: ['Even', 'add', 'two', 'even_two'],
    generality_notes: 'The biggest issue here is that the AI reproves something from scratch when it should compose existing lemmas. Library-quality code maximally reuses what already exists.',
    source: 'custom',
    tags: ['even', 'addition', 'ai_review', 'tier3'],
  },

  {
    title: 'AI Review: Odd plus even is odd',
    difficulty: 4,
    week: 5,
    category: 'ai_review',
    nl_statement: 'If m is an odd integer and n is an even integer, then m + n is odd.',
    nl_proof: 'Since m is odd, m = 2a + 1 for some a. Since n is even, n = 2b for some b. Then m + n = 2a + 1 + 2b = 2(a + b) + 1, so m + n is odd.',
    ai_lean_code: `-- AI-generated Lean 4 code (contains quality issues)
lemma odd_add_even_is_odd (m n : Nat) :
    (∃ k, m = 2 * k + 1) → (∃ k, n = 2 * k) → (∃ k, m + n = 2 * k + 1) := by
  intro ⟨a, ha⟩ ⟨b, hb⟩
  refine ⟨a + b, ?_⟩
  subst ha
  subst hb
  ring`,
    ai_failure_modes: [
      { layer: 1, issue: 'Uses raw existential instead of Odd/Even predicates', severity: 'high' },
      { layer: 2, issue: 'Arrow-style hypotheses instead of named hypotheses in signature', severity: 'medium' },
      { layer: 4, issue: 'Uses Nat instead of general type, and uses lemma instead of theorem', severity: 'medium' },
      { layer: 4, issue: 'Named odd_add_even_is_odd — verbose, not Mathlib convention (should be Odd.add_even)', severity: 'medium' },
      { layer: 3, issue: 'Uses subst which is fragile — better to use rw or let ring handle it', severity: 'low' },
    ],
    reference_lean_code: `theorem Odd.add_even {m n : ℤ} (hm : Odd m) (hn : Even n) : Odd (m + n) := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  exact ⟨a + b, by rw [ha, hb]; ring⟩`,
    reference_name: 'Odd.add_even',
    mathlib_search_hints: ['Odd', 'Even', 'add'],
    generality_notes: 'Multiple issues compound here: wrong predicates, wrong type, verbose naming, and fragile proof tactics. This is representative of typical autoformaliser output that compiles but would be immediately rejected from Mathlib.',
    source: 'custom',
    tags: ['odd', 'even', 'addition', 'ai_review', 'tier3'],
  },

  {
    title: 'AI Review: Odd times odd is odd',
    difficulty: 4,
    week: 6,
    category: 'ai_review',
    nl_statement: 'If m and n are both odd integers, then m * n is odd.',
    nl_proof: 'Since m = 2a + 1 and n = 2b + 1, we have m * n = (2a+1)(2b+1) = 4ab + 2a + 2b + 1 = 2(2ab + a + b) + 1, which is odd.',
    ai_lean_code: `-- AI-generated Lean 4 code (contains quality issues)
def is_odd (n : ℤ) : Prop := ∃ k : ℤ, n = 2 * k + 1

theorem odd_mul_odd_is_odd (m n : ℤ) (hm : is_odd m) (hn : is_odd n) : is_odd (m * n) := by
  rcases hm with ⟨a, rfl⟩
  rcases hn with ⟨b, rfl⟩
  use 2 * a * b + a + b
  ring`,
    ai_failure_modes: [
      { layer: 1, issue: 'Defines custom is_odd predicate instead of using Mathlib Odd', severity: 'high' },
      { layer: 4, issue: 'Named odd_mul_odd_is_odd — extremely verbose vs. Odd.mul', severity: 'medium' },
      { layer: 3, issue: 'Uses rcases with rfl instead of obtain — style preference, but rfl can be fragile', severity: 'low' },
      { layer: 4, issue: 'Missing namespace: should be in Odd namespace for dot notation', severity: 'medium' },
      { layer: 1, issue: 'is_odd uses 2 * k + 1 instead of Mathlib convention', severity: 'high' },
    ],
    reference_lean_code: `theorem Odd.mul {m n : ℤ} (hm : Odd m) (hn : Odd n) : Odd (m * n) := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  exact ⟨2 * a * b + a + b, by rw [ha, hb]; ring⟩`,
    reference_name: 'Odd.mul',
    mathlib_search_hints: ['Odd', 'mul'],
    generality_notes: 'The worst issue here is defining a custom predicate. This is a classic autoformaliser failure: the AI doesn\'t know that Odd already exists in Mathlib and re-invents it with a slightly different definition. This creates incompatibility with the entire Mathlib ecosystem.',
    source: 'custom',
    tags: ['odd', 'multiplication', 'ai_review', 'tier3'],
  },
]
