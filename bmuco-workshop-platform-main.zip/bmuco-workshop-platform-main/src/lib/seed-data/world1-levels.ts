// Lemma — Game seed data (Worlds 1–2 + locked placeholders)
// Format matches game_worlds + game_levels tables.

export const WORLD_1 = {
  id: 1,
  name: 'Smell Test',
  slug: 'smell-test',
  description:
    'Completed the Natural Number Game? Great. Now spot surface-level red flags in Lean 4 proofs.',
  type: 'smell_test',
  unlock_stars: 0,
  is_active: true,
}

export const WORLD_1_LEVELS = [
  {
    world_id: 1,
    level_number: 1,
    title: 'zero_add',
    skill_tag: 'length',
    informal_statement: '0 + n = n for all natural numbers n',
    proof_display: `import Mathlib

namespace LemmaWorld1

theorem zero_add (n : ℕ) : 0 + n = n := by
  induction n with
  | zero =>
    rfl
  | succ k ih =>
    simp [Nat.succ_add, ih]

end LemmaWorld1`,
    issues: [
      {
        id: 'i1',
        label: 'Could use simp [Nat.zero_add] instead of induction',
        explanation:
          'Mathlib already proves 0 + n = n in one step; induction is pedagogical, not minimal.',
        is_real_issue: true,
      },
      {
        id: 'i2',
        label: 'Proof is more verbose than the one-line library proof',
        explanation:
          'A single simp with Nat.zero_add closes the goal without explicit induction.',
        is_real_issue: true,
      },
      {
        id: 'i3',
        label: 'Induction duplicates what Nat.zero_add encodes',
        explanation:
          'The inductive argument mirrors the library lemma rather than adding new insight.',
        is_real_issue: true,
      },
    ],
    decoys: [
      {
        id: 'i4',
        label: 'Should use ℤ instead of ℕ',
        is_real_issue: false,
      },
      {
        id: 'i5',
        label: 'Theorem name add_zero_eq is incorrect',
        is_real_issue: false,
      },
    ],
    total_issues: 3,
    is_boss: false,
  },
  {
    world_id: 1,
    level_number: 2,
    title: 'succ_ne_zero',
    skill_tag: 'style',
    informal_statement: 'For all n : ℕ, succ(n) ≠ 0',
    proof_display: `import Mathlib

namespace LemmaWorld1

theorem succ_ne_zero (n : ℕ) : n.succ ≠ 0 := by
  exact Nat.succ_ne_zero n

end LemmaWorld1`,
    issues: [
      {
        id: 'i1',
        label: 'Uses by_contra when exact closes it directly',
        explanation:
          'This theorem can be finished directly with Nat.succ_ne_zero n.',
        is_real_issue: true,
      },
      {
        id: 'i2',
        label: 'Introduces unused hypothesis h',
        explanation:
          'The contradiction path creates an unnecessary intermediate hypothesis.',
        is_real_issue: true,
      },
    ],
    decoys: [
      {
        id: 'i3',
        label: 'Wrong type annotation on n',
        is_real_issue: false,
      },
      {
        id: 'i4',
        label: 'Missing import Mathlib',
        is_real_issue: false,
      },
    ],
    total_issues: 2,
    is_boss: false,
  },
]

export const WORLD_2 = {
  id: 2,
  name: 'Style Police',
  slug: 'style-police',
  description:
    'Proofs that compile but violate Mathlib conventions. Naming, generality, tactic choice — spot what a reviewer would reject.',
  type: 'style_police',
  unlock_stars: 8,
  is_active: true,
}

export const WORLD_2_LEVELS = [
  {
    world_id: 2,
    level_number: 1,
    title: 'Even.add — wrong predicate',
    skill_tag: 'predicate_choice',
    informal_statement: 'The sum of two even integers is even.',
    proof_display: `import Mathlib

namespace World2

theorem even_add_even (m n : ℕ) (hm : ∃ k, m = 2 * k) (hn : ∃ k, n = 2 * k) :
    ∃ k, m + n = 2 * k := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  use a + b
  omega

end World2`,
    issues: [
      {
        id: 'predicate',
        label: 'Uses raw ∃ instead of the Even predicate from Mathlib',
        explanation:
          'Mathlib defines Even n as ∃ k, n = k + k. Using a raw existential means this proof cannot interact with any other Even theorem in Mathlib. The correct signature is: theorem Even.add {m n : ℤ} (hm : Even m) (hn : Even n) : Even (m + n)',
        is_real_issue: true,
      },
      {
        id: 'generality',
        label: 'Hardcoded to ℕ instead of a general type like AddMonoid',
        explanation:
          'The Mathlib version of Even.add works over any AddMonoid, not just ℕ. Restricting to ℕ makes the theorem less reusable.',
        is_real_issue: true,
      },
      {
        id: 'naming',
        label: 'Named even_add_even instead of Even.add (no dot notation)',
        explanation:
          'Mathlib uses dot notation for theorems about a type. Even.add lives in the Even namespace, enabling hm.add hn syntax. The name even_add_even is verbose and does not enable this.',
        is_real_issue: true,
      },
      {
        id: 'convention',
        label: 'Uses 2 * k instead of k + k (Mathlib convention for Even)',
        explanation:
          'Mathlib defines Even n as ∃ k, n = k + k, not 2 * k. This matters because k + k works in any AddMonoid while 2 * k requires a multiplication structure.',
        is_real_issue: true,
      },
    ],
    decoys: [
      {
        id: 'decoy_omega',
        label: 'omega is not a valid Lean 4 tactic',
        is_real_issue: false,
      },
      {
        id: 'decoy_witness',
        label: 'The witness a + b is mathematically incorrect',
        is_real_issue: false,
      },
    ],
    total_issues: 4,
    is_boss: false,
  },
  {
    world_id: 2,
    level_number: 2,
    title: 'Even.add with fake axiom',
    skill_tag: 'axiom_abuse',
    informal_statement:
      'The sum of two even natural numbers is even (with an unnecessary axiom declaration).',
    proof_display: `import Mathlib

namespace World2

axiom add_double_comm (a b : ℕ) : 2 * a + 2 * b = 2 * (a + b)

theorem even_add_even (m n : ℕ) (hm : ∃ k, m = 2 * k) (hn : ∃ k, n = 2 * k) :
    ∃ k, m + n = 2 * k := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  use a + b
  rw [ha, hb]
  exact add_double_comm a b

end World2`,
    issues: [
      {
        id: 'fake_axiom',
        label: 'Declares an axiom for a trivially provable fact',
        explanation:
          'axiom add_double_comm bypasses the proof checker entirely. The fact 2*a + 2*b = 2*(a+b) is trivially provable with ring. Declaring it as an axiom is a serious red flag — axioms should only be used for foundational assumptions, never for derivable facts.',
        is_real_issue: true,
      },
      {
        id: 'predicate',
        label: 'Uses raw ∃ instead of the Even predicate',
        explanation: 'Same issue as Level 2-1: should use Even from Mathlib.',
        is_real_issue: true,
      },
      {
        id: 'generality',
        label: 'Restricted to ℕ instead of general type',
        explanation: 'Should work over any type with the right algebraic structure.',
        is_real_issue: true,
      },
    ],
    decoys: [
      {
        id: 'decoy_obtain',
        label: 'obtain should be replaced with rcases',
        is_real_issue: false,
      },
      {
        id: 'decoy_witness',
        label: 'The witness a + b is incorrect',
        is_real_issue: false,
      },
    ],
    total_issues: 3,
    is_boss: false,
  },
  {
    world_id: 2,
    level_number: 3,
    title: 'mul_inv_cancel — overcomplicated',
    skill_tag: 'proof_length',
    informal_statement: 'For any element g of a group G, g * g⁻¹ = 1.',
    proof_display: `import Mathlib

namespace World2

theorem h₁ {G : Type*} [Group G] (h₂ : G) : h₂ * h₂⁻¹ = 1 := by
  have h₃ : h₂ * h₂⁻¹ = h₂ * h₂⁻¹ := rfl
  have h₄ : h₂ * h₂⁻¹ = 1 := mul_inv_cancel h₂
  exact h₄

end World2`,
    issues: [
      {
        id: 'naming_subscripts',
        label: 'Variables named h₁, h₂, h₃, h₄ instead of descriptive names',
        explanation:
          'The theorem is named h₁, the group element is h₂, and helper hypotheses are h₃ and h₄. In Mathlib, you would name the element g, the theorem mul_inv_cancel_self or similar. Subscript soup makes code unreadable.',
        is_real_issue: true,
      },
      {
        id: 'redundant_step',
        label: 'h₃ is completely useless (states x = x)',
        explanation:
          'The hypothesis h₃ : h₂ * h₂⁻¹ = h₂ * h₂⁻¹ is true by rfl and is never used. It adds nothing to the proof.',
        is_real_issue: true,
      },
      {
        id: 'overcomplicated',
        label: 'Could be proved with exact mul_inv_cancel h₂ directly',
        explanation:
          'The entire proof could be one line: exact mul_inv_cancel h₂. The intermediate hypothesis h₄ restates what exact would provide directly.',
        is_real_issue: true,
      },
    ],
    decoys: [
      {
        id: 'decoy_group',
        label: 'Should specify the group is commutative',
        is_real_issue: false,
      },
      {
        id: 'decoy_result',
        label: 'g * g⁻¹ = 1 is mathematically wrong',
        is_real_issue: false,
      },
    ],
    total_issues: 3,
    is_boss: false,
  },
  {
    world_id: 2,
    level_number: 4,
    title: 'le_trans — misleading comments',
    skill_tag: 'documentation',
    informal_statement: 'Transitivity of ≤ on natural numbers.',
    proof_display: `import Mathlib

namespace World2

-- Proof by induction on the structure of the ordering
theorem le_trans_proof (a b c : ℕ) (hab : a ≤ b) (hbc : b ≤ c) : a ≤ c := by
  -- First we perform case analysis on whether a = b
  -- Then we use the inductive hypothesis on the successor case
  omega

end World2`,
    issues: [
      {
        id: 'comment_lies',
        label: 'Comments describe induction and case analysis but the proof just calls omega',
        explanation:
          'The comments claim the proof works by induction with case analysis on a = b and an inductive hypothesis on successors. The actual proof is a single call to omega. The comments are completely fabricated and misleading.',
        is_real_issue: true,
      },
      {
        id: 'reinvention',
        label: 'Re-proves a standard library fact instead of citing le_trans',
        explanation:
          'Transitivity of ≤ on ℕ is available as le_trans or Nat.le_trans in Mathlib. Re-proving it (even correctly with omega) is wasteful when the existing lemma is more informative and already integrated into the simp set.',
        is_real_issue: true,
      },
    ],
    decoys: [
      {
        id: 'decoy_omega_invalid',
        label: 'omega is not a valid Lean tactic',
        is_real_issue: false,
      },
      {
        id: 'decoy_types',
        label: 'Should use ℤ instead of ℕ for generality',
        is_real_issue: false,
      },
      {
        id: 'decoy_order',
        label: 'The hypotheses hab and hbc are in the wrong order',
        is_real_issue: false,
      },
    ],
    total_issues: 2,
    is_boss: false,
  },
  {
    world_id: 2,
    level_number: 5,
    title: 'sq_nonneg — type drift',
    skill_tag: 'type_mismatch',
    informal_statement: 'The square of any real number is non-negative.',
    proof_display: `import Mathlib

namespace World2

-- Proof that squares are non-negative for all real numbers
theorem sq_nonneg_proof (n : ℕ) : 0 ≤ n * n := by
  exact Nat.zero_le (n * n)

end World2`,
    issues: [
      {
        id: 'type_mismatch',
        label: 'Claims to prove it for reals but actually proves it for ℕ',
        explanation:
          'The comment says "for all real numbers" but the code uses (n : ℕ). For naturals, n * n ≥ 0 is trivially true because ALL naturals are ≥ 0. The interesting theorem is about reals where negative inputs can occur.',
        is_real_issue: true,
      },
      {
        id: 'trivial_proof',
        label: 'The proof is trivially true for ℕ — it does not demonstrate the actual mathematical content',
        explanation:
          'Nat.zero_le says 0 ≤ n for ANY natural n. So 0 ≤ n * n is just "all naturals are non-negative." This sidesteps the real mathematical content: squaring preserves non-negativity even for negative inputs.',
        is_real_issue: true,
      },
    ],
    decoys: [
      {
        id: 'decoy_sq',
        label: 'Should use n ^ 2 notation instead of n * n',
        is_real_issue: false,
      },
      {
        id: 'decoy_lemma',
        label: 'Nat.zero_le is not a valid Mathlib lemma',
        is_real_issue: false,
      },
    ],
    total_issues: 2,
    is_boss: false,
  },
  {
    world_id: 2,
    level_number: 6,
    title: 'Boss: Even.add — full review',
    skill_tag: 'full_review',
    informal_statement: 'The sum of two even numbers is even (boss level: find ALL the issues).',
    proof_display: `import Mathlib

namespace World2

axiom add_double_comm (a b : ℕ) : 2 * a + 2 * b = 2 * (a + b)

-- Proof by structural analysis of the existential witnesses
theorem even_add_even (m n : ℕ) (hm : ∃ k, m = 2 * k) (hn : ∃ k, n = 2 * k) :
    ∃ k, m + n = 2 * k := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  use a + b
  rw [ha, hb]
  exact add_double_comm a b

end World2`,
    issues: [
      {
        id: 'fake_axiom',
        label: 'Declares an axiom instead of proving the helper lemma',
        explanation:
          'The top of the file declares axiom add_double_comm — an unproven assumption accepted on faith. In Lean, axiom bypasses the proof checker entirely. This fact (2*a + 2*b = 2*(a+b)) is trivially provable with ring, so declaring it as an axiom is a red flag.',
        is_real_issue: true,
      },
      {
        id: 'predicate',
        label: 'Uses raw ∃ instead of the Even predicate',
        explanation:
          'Mathlib defines Even n as ∃ k, n = k + k. Using a raw existential means this proof cannot interact with any other Even theorem in Mathlib.',
        is_real_issue: true,
      },
      {
        id: 'generality',
        label: 'Hardcoded to ℕ instead of a general type',
        explanation: 'The Mathlib version works over any AddMonoid, not just ℕ.',
        is_real_issue: true,
      },
      {
        id: 'naming',
        label: 'Named even_add_even instead of Even.add',
        explanation:
          'Mathlib uses dot notation: Even.add is in the Even namespace, so you can write hm.add hn.',
        is_real_issue: true,
      },
      {
        id: 'convention',
        label: 'Uses 2 * k instead of k + k (Mathlib convention for Even)',
        explanation:
          'Mathlib defines Even n as ∃ k, n = k + k (not 2 * k). This matters because k + k works in any AddMonoid, while 2 * k requires multiplication.',
        is_real_issue: true,
      },
    ],
    decoys: [
      {
        id: 'decoy_witness',
        label: 'The witness a + b is incorrect',
        is_real_issue: false,
      },
      {
        id: 'decoy_obtain',
        label: 'obtain should be replaced with rcases',
        is_real_issue: false,
      },
      {
        id: 'decoy_comment',
        label: 'The comment "structural analysis" is wrong terminology',
        is_real_issue: false,
      },
    ],
    total_issues: 5,
    is_boss: true,
  },
]

// Locked world placeholders (no levels)
export const LOCKED_WORLDS = [
  {
    id: 3,
    name: 'Reinvention Detector',
    slug: 'reinvention-detector',
    description:
      'The proof works — but it reinvents something that already exists in Mathlib. Find the existing lemma.',
    type: 'reinvention_detector',
    unlock_stars: 16,
    is_active: false,
  },
  {
    id: 4,
    name: 'Generality Inspector',
    slug: 'generality-inspector',
    description:
      'The proof works for a specific type. Identify the most general type class it could use.',
    type: 'generality_inspector',
    unlock_stars: 24,
    is_active: false,
  },
  {
    id: 5,
    name: 'Architecture Critic',
    slug: 'architecture-critic',
    description:
      'The proof is correct and stylistically fine — but the structure is bad. Identify how to restructure.',
    type: 'architecture_critic',
    unlock_stars: 32,
    is_active: false,
  },
  {
    id: 6,
    name: 'Drift Detective',
    slug: 'drift-detective',
    description:
      "The informal statement and the Lean formalisation don't match. Find where the drift happened.",
    type: 'drift_detective',
    unlock_stars: 40,
    is_active: false,
  },
  {
    id: 7,
    name: 'Full Review',
    slug: 'full-review',
    description:
      'Real-world proofs. Multiple issues per proof. Full checklist. Timed. Everything combined.',
    type: 'full_review',
    unlock_stars: 48,
    is_active: false,
  },
]
