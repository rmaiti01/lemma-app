// BMUCO Studio — Supabase game data helpers
// Server-side only (uses server client from cookies).

import { WORLD_2_LEVELS } from '@/lib/seed-data/world1-levels'
import { createAdminClient } from '@/lib/supabase/admin'
import { createClient } from '@/lib/supabase/server'
import type {
  GameWorld,
  GameLevel,
  PlayerProgress,
  LevelCompletion,
  LeaderboardEntry,
} from './game-types'

/** If World 2 levels were never migrated, upsert from seed (requires SUPABASE_SERVICE_ROLE_KEY on the server). */
async function repairWorld2LevelsIfEmpty(): Promise<void> {
  const admin = createAdminClient()
  if (!admin) return
  const { data: existing, error: probeErr } = await admin
    .from('game_levels')
    .select('id')
    .eq('world_id', 2)
    .limit(1)
  if (probeErr) {
    console.error('[game-data] repairWorld2LevelsIfEmpty probe:', probeErr.message)
    return
  }
  if (existing && existing.length > 0) return
  const { error } = await admin
    .from('game_levels')
    .upsert(WORLD_2_LEVELS, { onConflict: 'world_id,level_number' })
  if (error) {
    console.error('[game-data] repairWorld2LevelsIfEmpty upsert:', error.message)
  }
}

// ── World & Level queries ──────────────────────────────────

export async function getWorld1Levels(): Promise<GameLevel[]> {
  return getWorldLevels(1)
}

export async function getWorldLevels(worldId: number): Promise<GameLevel[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('game_levels')
    .select('*')
    .eq('world_id', worldId)
    .order('level_number')

  if (error) throw new Error(`getWorldLevels: ${error.message}`)
  let rows = (data ?? []) as GameLevel[]

  if (worldId === 2 && rows.length === 0) {
    await repairWorld2LevelsIfEmpty()
    const { data: retry, error: retryErr } = await supabase
      .from('game_levels')
      .select('*')
      .eq('world_id', worldId)
      .order('level_number')
    if (retryErr) throw new Error(`getWorldLevels: ${retryErr.message}`)
    rows = (retry ?? []) as GameLevel[]
  }

  return rows
}

export async function getLevelById(
  levelId: number
): Promise<{ world: GameWorld; level: GameLevel } | null> {
  const supabase = createClient()

  const { data: level, error: lErr } = await supabase
    .from('game_levels')
    .select('*')
    .eq('id', levelId)
    .single()

  if (lErr || !level) return null

  const { data: world, error: wErr } = await supabase
    .from('game_worlds')
    .select('*')
    .eq('id', level.world_id)
    .single()

  if (wErr || !world) return null

  return { world: world as GameWorld, level: level as GameLevel }
}

export async function getLevelByWorldAndNumber(
  worldId: number,
  levelNumber: number
): Promise<{ world: GameWorld; level: GameLevel } | null> {
  const supabase = createClient()

  const { data: level, error: lErr } = await supabase
    .from('game_levels')
    .select('*')
    .eq('world_id', worldId)
    .eq('level_number', levelNumber)
    .single()

  if (lErr || !level) return null

  const { data: world, error: wErr } = await supabase
    .from('game_worlds')
    .select('*')
    .eq('id', worldId)
    .single()

  if (wErr || !world) return null

  return { world: world as GameWorld, level: level as GameLevel }
}

export async function getAllWorlds(): Promise<GameWorld[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('game_worlds')
    .select('*')
    .order('id')

  if (error) throw new Error(`getAllWorlds: ${error.message}`)
  return data as GameWorld[]
}

// ── Player progress ────────────────────────────────────────

export async function getPlayerProgress(
  userId: string
): Promise<PlayerProgress | null> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('player_progress')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle()

  if (error || !data) return null
  return data as PlayerProgress
}

export async function getLevelCompletions(
  userId: string
): Promise<LevelCompletion[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('level_completions')
    .select('*')
    .eq('user_id', userId)

  if (error) return []
  return data as LevelCompletion[]
}

function startOfWeekMondayUTC(d = new Date()): Date {
  const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()))
  const day = x.getUTCDay()
  const daysSinceMonday = day === 0 ? 6 : day - 1
  x.setUTCDate(x.getUTCDate() - daysSinceMonday)
  x.setUTCHours(0, 0, 0, 0)
  return x
}

/** All-time top N from `leaderboard` view (stars, then points). */
export async function getLeaderboardTop(limit: number): Promise<LeaderboardEntry[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('leaderboard')
    .select('*')
    .order('rank', { ascending: true })
    .limit(limit)

  if (error) throw new Error(`getLeaderboardTop: ${error.message}`)
  return (data as LeaderboardEntry[]) || []
}

/**
 * Weekly leaderboard: sum stars/points from `level_completions` with `completed_at` in the current UTC week (Mon–Sun).
 */
export async function getWeeklyLeaderboardTop(limit: number): Promise<LeaderboardEntry[]> {
  const supabase = createClient()
  const weekStart = startOfWeekMondayUTC()
  const { data: rows, error } = await supabase
    .from('level_completions')
    .select('user_id, stars, points')
    .gte('completed_at', weekStart.toISOString())

  if (error) throw new Error(`getWeeklyLeaderboardTop: ${error.message}`)

  const agg = new Map<string, { stars: number; points: number }>()
  for (const r of rows || []) {
    const uid = r.user_id as string
    const cur = agg.get(uid) || { stars: 0, points: 0 }
    cur.stars += Number(r.stars) || 0
    cur.points += Number(r.points) || 0
    agg.set(uid, cur)
  }

  const sorted = Array.from(agg.entries()).sort(
    (a, b) => b[1].stars - a[1].stars || b[1].points - a[1].points
  )
  const top = sorted.slice(0, limit)
  const ids = top.map(([id]) => id)
  if (ids.length === 0) return []

  const { data: profs } = await supabase
    .from('profiles')
    .select('id, username, avatar_url')
    .in('id', ids)

  const profMap = new Map((profs || []).map(p => [p.id as string, p]))

  return top.map(([user_id, v], i) => {
    const pr = profMap.get(user_id)
    const name =
      pr?.username && String(pr.username).trim() ? String(pr.username).trim() : 'Anonymous'
    return {
      user_id,
      github_username: name,
      avatar_url: (pr?.avatar_url as string | null) ?? null,
      total_stars: v.stars,
      total_points: v.points,
      current_streak: 0,
      rank: i + 1,
    }
  })
}

export async function getUserLeaderboardRank(userId: string): Promise<number | null> {
  const supabase = createClient()
  const { data, error } = await supabase.from('leaderboard').select('rank').eq('user_id', userId).maybeSingle()

  if (error || !data) return null
  return typeof (data as { rank: number }).rank === 'number' ? (data as { rank: number }).rank : null
}
