/**
 * Public site origin for OAuth, email redirects, and absolute URLs.
 * Deploy at https://studio.bmuco.org — set NEXT_PUBLIC_SITE_URL there (no trailing slash).
 * In the browser we prefer the current origin so links work on preview URLs too.
 */
export function getPublicSiteOrigin(): string {
  if (typeof window !== 'undefined') {
    return window.location.origin
  }
  const fromEnv = process.env.NEXT_PUBLIC_SITE_URL?.trim().replace(/\/$/, '')
  if (fromEnv) return fromEnv
  return 'http://localhost:3000'
}

/** Safe path-only redirect target (avoids open redirects). */
export function sanitizeNextPath(raw: string | null, fallback = '/studio'): string {
  if (!raw || !raw.startsWith('/') || raw.startsWith('//')) return fallback
  return raw
}

export function absoluteUrl(path: string): string {
  const p = path.startsWith('/') ? path : `/${path}`
  return `${getPublicSiteOrigin()}${p}`
}
