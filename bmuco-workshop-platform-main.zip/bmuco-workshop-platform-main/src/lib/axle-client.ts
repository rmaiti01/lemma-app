import { log } from '@/lib/logger'

const cache = new Map<string, any>()

async function hashBody(body: string): Promise<string> {
  const encoded = new TextEncoder().encode(body)
  const digest = await crypto.subtle.digest('SHA-256', encoded)
  return Array.from(new Uint8Array(digest))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

export interface AxleCheckResult {
  ok: boolean
  has_errors: boolean
  message: string
  goal_state: string | null
  mock: boolean
  errors: Array<{ line?: number; column?: number; message: string }>
  warnings: Array<{ line?: number; column?: number; message: string }>
  raw?: any
  durationMs: number
}

export interface AxleVerifyResult {
  verified: boolean
  error_message: string | null
  goal_state_after: string | null
  mock: boolean
  durationMs: number
}

export interface AxleSimplifyResult {
  simplified: boolean
  content: string | null
  mock: boolean
  durationMs: number
}

export interface AxleRepairResult {
  repaired: boolean
  content: string | null
  error_message: string | null
  mock: boolean
  durationMs: number
}

export interface AxleDisproveResult {
  disproved: boolean
  counterexample: string | null
  mock: boolean
  durationMs: number
}

type AxleLogMeta = {
  levelId: string
  mode: 'build' | 'review' | 'trace'
  stepId: string
  annotation?: string | null
  confidence?: number | null
  /** Sorried theorem stub — required by AXLE verify_proof alongside the completed proof `content`. */
  formalStatement?: string
}

export async function axleCheck(content: string, logMeta?: AxleLogMeta): Promise<AxleCheckResult> {
  const bodyJson = JSON.stringify({ content })
  const key = await hashBody(bodyJson)

  if (cache.has(key)) return cache.get(key)

  const asMockSuccess = (durationMs: number): AxleCheckResult => ({
    ok: true,
    has_errors: false,
    message: 'No errors so far — keep going',
    goal_state: null,
    mock: true,
    errors: [],
    warnings: [],
    raw: null,
    durationMs,
  })

  const startedAt = performance.now()
  try {
    const res = await fetch('/api/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: bodyJson,
    })
    const payload = await res.json()
    const durationMs = Math.round(performance.now() - startedAt)

    if (!res.ok) {
      const result = asMockSuccess(durationMs)
      if (logMeta) logAxle(logMeta, '/api/check', true, 0, durationMs, true)
      return result
    }

    const hasErrors = payload.has_errors ?? false
    const result: AxleCheckResult = {
      ok: !hasErrors,
      has_errors: hasErrors,
      message: payload.message ?? '',
      goal_state: payload.goal_state ?? null,
      mock: payload.mock === true,
      errors: hasErrors ? [{ message: payload.message ?? 'Check failed' }] : [],
      warnings: [],
      raw: payload,
      durationMs,
    }

    if (logMeta) logAxle(logMeta, '/api/check', result.ok, result.errors.length, durationMs, result.mock)
    cache.set(key, result)
    return result
  } catch {
    const result = asMockSuccess(Math.round(performance.now() - startedAt))
    if (logMeta) logAxle(logMeta, '/api/check', true, 0, result.durationMs, true)
    return result
  }
}

/** Full Lean file content for verify_proof (imports + theorem + proof). */
export async function axleVerify(
  leanContent: string,
  logMeta?: AxleLogMeta
): Promise<AxleVerifyResult> {
  const bodyJson = JSON.stringify({
    proof: leanContent,
    content: leanContent,
    formal_statement: logMeta?.formalStatement ?? '',
  })
  const key = 'verify_' + (await hashBody(bodyJson))

  if (cache.has(key)) return cache.get(key)

  const asMockSuccess = (durationMs: number): AxleVerifyResult => ({
    verified: true,
    error_message: null,
    goal_state_after: null,
    mock: true,
    durationMs,
  })

  const startedAt = performance.now()
  try {
    const res = await fetch('/api/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: bodyJson,
    })
    const payload = await res.json().catch(() => ({}))
    const durationMs = Math.round(performance.now() - startedAt)

    if (!res.ok) {
      const result: AxleVerifyResult = {
        verified: false,
        error_message:
          typeof payload?.error_message === 'string'
            ? payload.error_message
            : `HTTP ${res.status}`,
        goal_state_after: null,
        mock: false,
        durationMs,
      }
      if (logMeta) logAxle(logMeta, '/api/verify', false, 1, durationMs, false)
      return result
    }

    if (payload?.mock === true) {
      const result = asMockSuccess(durationMs)
      if (logMeta) logAxle(logMeta, '/api/verify', true, 0, durationMs, true)
      cache.set(key, result)
      return result
    }

    const result: AxleVerifyResult = {
      verified: payload.verified ?? false,
      error_message: payload.error_message ?? null,
      goal_state_after: payload.goal_state_after ?? null,
      mock: false,
      durationMs,
    }

    if (logMeta) logAxle(logMeta, '/api/verify', result.verified, result.verified ? 0 : 1, durationMs, false)
    cache.set(key, result)
    return result
  } catch {
    const durationMs = Math.round(performance.now() - startedAt)
    const result: AxleVerifyResult = {
      verified: false,
      error_message: 'Network error',
      goal_state_after: null,
      mock: false,
      durationMs,
    }
    if (logMeta) logAxle(logMeta, '/api/verify', false, 1, durationMs, false)
    return result
  }
}

/** Review mode: Mathlib-style simplification of the displayed proof (via `/api/simplify` → AXLE simplify_theorems). */
export async function axleSimplify(content: string): Promise<AxleSimplifyResult> {
  const startedAt = performance.now()
  try {
    const res = await fetch('/api/simplify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content }),
    })
    const payload = await res.json().catch(() => ({}))
    const durationMs = Math.round(performance.now() - startedAt)
    return {
      simplified: payload.simplified === true,
      content: typeof payload.content === 'string' ? payload.content : null,
      mock: payload.mock === true,
      durationMs,
    }
  } catch {
    return {
      simplified: false,
      content: null,
      mock: false,
      durationMs: Math.round(performance.now() - startedAt),
    }
  }
}

/** Build mode advanced hint: AXLE repair_proofs on partial skeleton (via `/api/repair`). */
export async function axleRepair(content: string): Promise<AxleRepairResult> {
  const startedAt = performance.now()
  try {
    const res = await fetch('/api/repair', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content }),
    })
    const payload = await res.json().catch(() => ({}))
    const durationMs = Math.round(performance.now() - startedAt)
    return {
      repaired: payload.repaired === true,
      content: typeof payload.content === 'string' ? payload.content : null,
      error_message: typeof payload.error_message === 'string' ? payload.error_message : null,
      mock: payload.mock === true,
      durationMs,
    }
  } catch {
    const durationMs = Math.round(performance.now() - startedAt)
    return {
      repaired: false,
      content: null,
      error_message: 'Network error',
      mock: false,
      durationMs,
    }
  }
}

/** Trap / false-theorem levels: try to disprove claimed theorems (via `/api/disprove`). */
export async function axleDisprove(content: string): Promise<AxleDisproveResult> {
  const startedAt = performance.now()
  try {
    const res = await fetch('/api/disprove', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content }),
    })
    const payload = await res.json().catch(() => ({}))
    const durationMs = Math.round(performance.now() - startedAt)
    return {
      disproved: payload.disproved === true,
      counterexample: typeof payload.counterexample === 'string' ? payload.counterexample : null,
      mock: payload.mock === true,
      durationMs,
    }
  } catch {
    return {
      disproved: false,
      counterexample: null,
      mock: false,
      durationMs: Math.round(performance.now() - startedAt),
    }
  }
}

function logAxle(
  meta: AxleLogMeta,
  endpoint: string,
  okay: boolean,
  errorCount: number,
  durationMs: number,
  mock: boolean
) {
  log({
    level_id: meta.levelId,
    mode: meta.mode,
    step_id: meta.stepId,
    event: 'axle_response',
    value: { endpoint, okay, error_count: errorCount, duration_ms: durationMs, mock },
    duration_ms: durationMs,
    confidence: meta.confidence ?? null,
    annotation: meta.annotation ?? null,
  })
}

/** Build a full Lean string from a skeleton, filling one blank and sorry-ing the rest */
export function buildLeanContent(
  skeleton: string,
  blanks: Array<{ id: string }>,
  fills: Record<string, string>,
  targetBlankId?: string
): string {
  let lean = skeleton
  for (const blank of blanks) {
    const placeholder = `[BLANK_${blank.id.replace('b', '')}]`
    const fill =
      targetBlankId === undefined || blank.id === targetBlankId
        ? fills[blank.id] || 'sorry'
        : 'sorry'
    lean = lean.replace(placeholder, fill)
  }
  return lean
}

/**
 * Wrap Lean content in a unique session namespace to prevent naming collisions.
 * Strips existing import lines and adds `import Mathlib` at the top.
 */
export function wrapInNamespace(content: string, sessionId: string): string {
  const ns = `LemmaSession_${sessionId.replace(/-/g, '_')}`
  const withoutImports = content.replace(/^import[^\n]*\n/gm, '')
  return `import Mathlib\n\nnamespace ${ns}\n\n${withoutImports.trim()}\n\nend ${ns}`
}
