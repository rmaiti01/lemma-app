/** HttpOnly-safe readable name: set from client; read in /studio/api/progress for anonymous totals. */
export const LEMMA_PROGRESS_SESSION_COOKIE = 'lemma_progress_session'
