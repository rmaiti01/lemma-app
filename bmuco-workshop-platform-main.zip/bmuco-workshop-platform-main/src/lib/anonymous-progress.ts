import type { SupabaseClient } from '@supabase/supabase-js'

export function aggregateTotalsFromTraces(
  traces: { level_id: number | null; stars_earned: number | null; points_earned: number | null }[]
) {
  const byLevel = new Map<number, { stars: number; points: number }>()
  for (const t of traces) {
    const lid = t.level_id
    if (lid == null || !Number.isFinite(Number(lid))) continue
    const id = Math.trunc(Number(lid))
    const cur = byLevel.get(id) ?? { stars: 0, points: 0 }
    const s = Math.max(0, Math.trunc(Number(t.stars_earned ?? 0)))
    const p = Math.max(0, Math.trunc(Number(t.points_earned ?? 0)))
    byLevel.set(id, {
      stars: Math.max(cur.stars, s),
      points: Math.max(cur.points, p),
    })
  }
  let totalStars = 0
  let totalPoints = 0
  for (const v of Array.from(byLevel.values())) {
    totalStars += v.stars
    totalPoints += v.points
  }
  return { totalStars, totalPoints, levelsTouched: byLevel.size }
}

export async function fetchAnonymousTraceTotals(admin: SupabaseClient, sessionId: string) {
  const { data, error } = await admin
    .from('game_traces')
    .select('level_id, stars_earned, points_earned')
    .eq('session_id', sessionId)
    .is('user_id', null)
  if (error) throw new Error(error.message)
  return aggregateTotalsFromTraces(data ?? [])
}

export async function syncAnonymousPlayerProgress(admin: SupabaseClient, sessionId: string) {
  const { totalStars, totalPoints } = await fetchAnonymousTraceTotals(admin, sessionId)
  const { error } = await admin.from('player_progress').upsert(
    {
      user_id: null,
      lemma_session_id: sessionId,
      total_stars: totalStars,
      total_points: totalPoints,
      current_streak: 0,
      longest_streak: 0,
      last_played_at: new Date().toISOString(),
    },
    { onConflict: 'lemma_session_id' }
  )
  if (error) throw new Error(error.message)
}
