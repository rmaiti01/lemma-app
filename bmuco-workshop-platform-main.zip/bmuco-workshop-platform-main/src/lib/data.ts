// BMUCO Studio — Curriculum and configuration data
import { ChecklistItem } from './types'

export interface CurriculumWeekData {
  week_number: number
  title: string
  phase: string
  description: string
  exit_competency: string
  checklist_items: ChecklistItem[]
}

export const DEFAULT_CURRICULUM: CurriculumWeekData[] = [
  {
    week_number: 0,
    title: 'Pre-work',
    phase: 'Preparation',
    description: 'Install Lean 4 and the VS Code extension. Complete the Natural Number Game. Prepare a personal theorem list — 20 results you already know mathematically. The key principle: never learn mathematics and Lean simultaneously. Read Bhavik Mehta\'s formalisation notes §1–2.',
    exit_competency: 'Lean 4 environment ready, familiar with basic interaction, personal theorem list prepared.',
    checklist_items: [
      { id: 'pw-1', label: 'Install Lean 4 and VS Code extension' },
      { id: 'pw-2', label: 'Complete the Natural Number Game' },
      { id: 'pw-3', label: 'Prepare personal theorem list (20 results)' },
      { id: 'pw-4', label: 'Read Bhavik Mehta\'s formalisation notes §1–2' },
      { id: 'pw-5', label: 'Set up GitHub account and course repository' },
    ]
  },
  {
    week_number: 1,
    title: 'Lean Fluency I',
    phase: 'Weeks 1–2: Lean Fluency',
    description: 'Proof states, core tactics, reading the Infoview. Curry-Howard explained operationally. Search tools: #check, exact?, apply?. Proof critique from day one: identify what could be improved in working but non-library-quality proofs.',
    exit_competency: 'Reads proof states and closes basic goals independently.',
    checklist_items: [
      { id: 'w1-1', label: 'Understand proof states and the Infoview' },
      { id: 'w1-2', label: 'Master core tactics: intro, apply, exact, rw, simp' },
      { id: 'w1-3', label: 'Use #check, exact?, apply? for search' },
      { id: 'w1-4', label: 'Complete Week 1 exercises' },
      { id: 'w1-5', label: 'Critique a non-library-quality proof' },
    ]
  },
  {
    week_number: 2,
    title: 'Lean Fluency II',
    phase: 'Weeks 1–2: Lean Fluency',
    description: 'Deeper tactics, induction, cases, have/let, term-mode proofs. Continue proof critique exercises. Begin understanding what Mathlib style looks like.',
    exit_competency: 'Reads proof states and closes basic goals independently.',
    checklist_items: [
      { id: 'w2-1', label: 'Master induction and cases tactics' },
      { id: 'w2-2', label: 'Write proofs using have and let' },
      { id: 'w2-3', label: 'Understand term-mode vs tactic-mode proofs' },
      { id: 'w2-4', label: 'Complete Week 2 exercises' },
      { id: 'w2-5', label: 'Complete proof critique exercise' },
    ]
  },
  {
    week_number: 3,
    title: 'Mathlib Navigation & The Reviewer\'s Eye I',
    phase: 'Weeks 3–4: Mathlib Navigation',
    description: 'Type classes, algebraic hierarchy, Mathlib\'s generality culture. Search tools: Moogle, LeanSearch, Loogle. Mathlib style guide as concrete rules. Automation stack (simp, norm_num, ring, linarith, omega). Mathlib linter mandatory from this point.',
    exit_competency: 'Finds lemmas, writes style-compliant proofs, articulates what reviewers reject and why.',
    checklist_items: [
      { id: 'w3-1', label: 'Understand type classes and the algebraic hierarchy' },
      { id: 'w3-2', label: 'Use Moogle, LeanSearch, and Loogle for search' },
      { id: 'w3-3', label: 'Study the Mathlib style guide' },
      { id: 'w3-4', label: 'Use automation: simp, norm_num, ring, linarith, omega' },
      { id: 'w3-5', label: 'Pass Mathlib linter on all submissions' },
      { id: 'w3-6', label: 'Complete Week 3 exercises' },
    ]
  },
  {
    week_number: 4,
    title: 'Mathlib Navigation & The Reviewer\'s Eye II',
    phase: 'Weeks 3–4: Mathlib Navigation',
    description: 'Core exercise: receive AI-generated proofs that compile but contain multiple quality issues. Write mock reviews explaining every problem — exactly as a Mathlib PR reviewer would. Begin shadow-reviewing real open PRs in your domain.',
    exit_competency: 'Finds lemmas, writes style-compliant proofs, articulates what reviewers reject and why.',
    checklist_items: [
      { id: 'w4-1', label: 'Write mock review of AI-generated proof #1' },
      { id: 'w4-2', label: 'Write mock review of AI-generated proof #2' },
      { id: 'w4-3', label: 'Shadow-review a real open Mathlib PR' },
      { id: 'w4-4', label: 'Use AXLE to verify kernel soundness' },
      { id: 'w4-5', label: 'Complete Week 4 exercises' },
    ]
  },
  {
    week_number: 5,
    title: 'Domain Production I',
    phase: 'Weeks 5–6: Domain Production',
    description: 'Claim theorems from curated backlogs. Each submission includes informal proof, formal proof, step-level alignment, proof development journal, AI usage reflection, self-review against quality checklist, and peer feedback. All interactions are recorded as process traces.',
    exit_competency: 'Sustained library-quality production in their domain.',
    checklist_items: [
      { id: 'w5-1', label: 'Claim theorem(s) from the backlog' },
      { id: 'w5-2', label: 'Submit first process trace with all fields' },
      { id: 'w5-3', label: 'Complete peer review of another submission' },
      { id: 'w5-4', label: 'Document AI usage and reflection' },
      { id: 'w5-5', label: 'Self-review against quality checklist' },
    ]
  },
  {
    week_number: 6,
    title: 'Domain Production II',
    phase: 'Weeks 5–6: Domain Production',
    description: 'Continue domain production. Prepare first PR drafts. Focus on library integration and correct generality. Practice addressing common reviewer feedback patterns.',
    exit_competency: 'Sustained library-quality production in their domain.',
    checklist_items: [
      { id: 'w6-1', label: 'Submit additional process traces' },
      { id: 'w6-2', label: 'Prepare first PR draft' },
      { id: 'w6-3', label: 'Study common Mathlib reviewer feedback patterns' },
      { id: 'w6-4', label: 'Complete peer review of PR draft' },
      { id: 'w6-5', label: 'Get mentor sign-off on PR readiness' },
    ]
  },
  {
    week_number: 7,
    title: 'The Real PR Cycle I',
    phase: 'Weeks 7–8: Real PR Cycle',
    description: 'Post planned contribution in the relevant Lean Zulip stream to solicit community feedback on approach, generality, and naming. Submit real pull requests to Mathlib or community project repositories.',
    exit_competency: 'Submitted at least one real PR and iterated on reviewer feedback.',
    checklist_items: [
      { id: 'w7-1', label: 'Post in Lean Zulip for community pre-PR feedback' },
      { id: 'w7-2', label: 'Incorporate Zulip feedback into PR' },
      { id: 'w7-3', label: 'Submit real PR to Mathlib or project repository' },
      { id: 'w7-4', label: 'Document PR submission in process trace' },
      { id: 'w7-5', label: 'Record Zulip discussion in PR interactions' },
    ]
  },
  {
    week_number: 8,
    title: 'The Real PR Cycle II',
    phase: 'Weeks 7–8: Real PR Cycle',
    description: 'Receive real reviewer feedback, iterate, and experience rejection. Document all interaction rounds — this data is critical for training the quality-aware prover.',
    exit_competency: 'Submitted at least one real PR and iterated on reviewer feedback.',
    checklist_items: [
      { id: 'w8-1', label: 'Respond to reviewer feedback' },
      { id: 'w8-2', label: 'Submit PR revision' },
      { id: 'w8-3', label: 'Update process trace with reviewer interaction records' },
      { id: 'w8-4', label: 'Reflect on feedback patterns and lessons learned' },
      { id: 'w8-5', label: 'Prepare for final assessment' },
    ]
  },
  {
    week_number: 9,
    title: 'Autoformaliser Review I',
    phase: 'Weeks 9–10: Autoformaliser Review',
    description: 'Evaluate AI-generated proofs against a structured checklist: (1) kernel soundness via AXLE verify; (2) Mathlib coverage; (3) style and naming compliance; (4) proof architecture and readability; (5) abstraction level. Each correction is documented as a training triple.',
    exit_competency: 'Takes AI-generated Lean code and brings it to Mathlib standard.',
    checklist_items: [
      { id: 'w9-1', label: 'Evaluate AI proof: kernel soundness check' },
      { id: 'w9-2', label: 'Evaluate AI proof: Mathlib coverage analysis' },
      { id: 'w9-3', label: 'Evaluate AI proof: style and naming compliance' },
      { id: 'w9-4', label: 'Evaluate AI proof: architecture and readability' },
      { id: 'w9-5', label: 'Submit autoformaliser correction record' },
    ]
  },
  {
    week_number: 10,
    title: 'Autoformaliser Review II & Assessment',
    phase: 'Weeks 9–10: Autoformaliser Review + Assessment',
    description: 'Final assessment: (1) Autoformaliser correction exercise (45 min) — fix a previously unseen AI-generated proof; (2) Independent formalisation (45 min) — prove a theorem from scratch; (3) Viva (30 min) — walk through your best contribution.',
    exit_competency: 'Certified: can review and correct AI-generated Lean code to Mathlib standard, and independently formalise theorems.',
    checklist_items: [
      { id: 'w10-1', label: 'Complete autoformaliser correction exercise (45 min)' },
      { id: 'w10-2', label: 'Complete independent formalisation exercise (45 min)' },
      { id: 'w10-3', label: 'Complete viva (30 min)' },
      { id: 'w10-4', label: 'Confirm: at least 1 PR submitted' },
      { id: 'w10-5', label: 'Confirm: at least 1 round of reviewer feedback received' },
      { id: 'w10-6', label: 'Receive certification decision' },
    ]
  },
]

export const TEAM_MEMBERS: any[] = []
export const APPLICATION_FORM_FIELDS: any[] = []
