import { ScoreResult } from '../game-types'

export function calculateScore(
  submitted: string[],
  realIssueIds: string[],
  allDecoyIds: string[]
): ScoreResult {
  const found = submitted.filter(id => realIssueIds.includes(id))
  const missed = realIssueIds.filter(id => !submitted.includes(id))
  const fps = submitted.filter(id => allDecoyIds.includes(id))

  const ratio = realIssueIds.length > 0 ? found.length / realIssueIds.length : 0
  const hasFP = fps.length > 0

  let stars: 0 | 1 | 2 | 3 = 0
  if (ratio === 1 && !hasFP) stars = 3
  else if (ratio >= 0.5 && fps.length <= 1) stars = 2
  else if (ratio > 0) stars = 1

  // Base: 100 pts per correct. Bonus: 50 for all found, no FPs. Penalty: -30 per FP.
  const points = Math.max(0, (found.length * 100) + (stars === 3 ? 50 : 0) - (fps.length * 30))

  return { stars, points, issuesFound: found, issuesMissed: missed, falsePositives: fps }
}
