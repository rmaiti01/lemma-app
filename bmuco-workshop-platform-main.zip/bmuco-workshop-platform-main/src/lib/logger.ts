'use client'

export type LogEntry = {
  timestamp: string
  session_id: string
  level_id: string
  mode: 'mcq' | 'build' | 'review' | 'trace'
  step_id: string
  event: string
  value: unknown
  duration_ms: number
  confidence: number | null
  annotation: string | null
}

const SESSION_ID = crypto.randomUUID()

export const BMUCO_LOG: LogEntry[] = []

export function log(entry: Omit<LogEntry, 'timestamp' | 'session_id'>) {
  const full: LogEntry = {
    ...entry,
    timestamp: new Date().toISOString(),
    session_id: SESSION_ID,
  }
  BMUCO_LOG.push(full)
  console.log('[BMUCO]', full)
}

export async function flush(level_id: string, opts?: { keepalive?: boolean }) {
  const batch = BMUCO_LOG.filter(e => e.level_id === level_id)
  if (batch.length === 0) return

  await fetch('/api/log', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      session_id: SESSION_ID,
      level_id,
      events: batch,
    }),
    keepalive: opts?.keepalive === true,
  }).catch(() => {})
}
