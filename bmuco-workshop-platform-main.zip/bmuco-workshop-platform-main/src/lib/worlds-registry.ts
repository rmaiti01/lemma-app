/**
 * Seed-side registry: which objects feed game_worlds / game_levels.
 * The studio play pages read worlds and levels from Supabase, not from this file.
 */
import { WORLD_1, WORLD_2, LOCKED_WORLDS } from './seed-data/world1-levels'
import { WORLD_2_LEVELS, WORLD_2_LEVEL_IDS } from './world2-data'

/** Order matches seed-worlds.ts upsert sequence (ids match game_worlds.id). */
export const GAME_WORLDS_SEED_REGISTRY = [WORLD_1, WORLD_2, ...LOCKED_WORLDS] as const

export function assertWorld2SeedAlignedWithRegistry(): void {
  if (WORLD_2.id !== 2) throw new Error('WORLD_2.id must be 2')
  if (!WORLD_2.is_active) throw new Error('WORLD_2 must be is_active for studio play')
  if (WORLD_2_LEVELS.length !== 6) throw new Error('WORLD_2_LEVELS must define 6 levels')
  if (WORLD_2_LEVEL_IDS.length !== WORLD_2_LEVELS.length) {
    throw new Error('WORLD_2_LEVEL_IDS and WORLD_2_LEVELS must stay in sync')
  }
  for (const row of WORLD_2_LEVELS) {
    if (row.world_id !== 2) throw new Error('Each WORLD_2_LEVELS row must have world_id 2')
  }
}
