/** Server-only: achievements returned from POST /studio/api/traces for client toasts. */

export type TraceAchievementPayload = {
  id: string
  title: string
  description: string
}

const XP_THRESHOLDS = [100, 500, 1000, 5000] as const
const STREAK_MILESTONES = [3, 7, 14, 30] as const

export function computeTraceAchievements(args: {
  wroteCompletion: boolean
  stars: number
  priorBestStars: number
  worldJustCompleted: boolean
  streakIncrementedThisSubmit: boolean
  newStreak: number
  prevTotalPoints: number
  newTotalPoints: number
}): TraceAchievementPayload[] {
  const out: TraceAchievementPayload[] = []

  if (args.wroteCompletion && args.stars >= 1 && args.priorBestStars < 1) {
    out.push({
      id: 'level_first_complete',
      title: 'Level cleared',
      description: 'You finished this level for the first time.',
    })
  }

  if (args.wroteCompletion && args.stars === 3 && args.priorBestStars < 3) {
    out.push({
      id: 'level_three_stars',
      title: 'Perfect run',
      description: 'Three stars on this level!',
    })
  }

  if (args.worldJustCompleted) {
    out.push({
      id: 'world_complete',
      title: 'World conquered',
      description: 'You cleared every level in this world.',
    })
  }

  if (args.streakIncrementedThisSubmit) {
    for (const m of STREAK_MILESTONES) {
      if (args.newStreak === m) {
        out.push({
          id: `streak_${m}`,
          title: `${m}-day streak`,
          description: `You're on a ${m}-day play streak.`,
        })
      }
    }
  }

  for (const t of XP_THRESHOLDS) {
    if (args.prevTotalPoints < t && args.newTotalPoints >= t) {
      out.push({
        id: `xp_${t}`,
        title: `${t} XP`,
        description: `You reached ${t} total XP.`,
      })
    }
  }

  return out
}
