/** Shared AXLE HTTP proxy config (server routes). */

export const AXLE_BASE = 'https://axle.axiommath.ai/api/v1'
/** AXLE proxy HTTP timeout (10s per product verification). */
export const AXLE_TIMEOUT_MS = 10_000

export function getAxleApiKey(): string {
  return (process.env.AXLE_API_KEY ?? process.env.AXIOMMATH_API_KEY ?? '').trim()
}

export function defaultAxleEnv(): string {
  return (process.env.AXLE_ENV ?? 'lean-4.28.0').trim() || 'lean-4.28.0'
}

export function ensureMathlibImport(lean: string): string {
  const trimmed = lean.trim()
  if (/^import\s+/m.test(trimmed)) return trimmed
  return `import Mathlib\n\n${trimmed}`
}

export function leanErrorsCount(data: { lean_messages?: { errors?: unknown[] } }): number {
  const e = data.lean_messages?.errors
  return Array.isArray(e) ? e.length : 0
}
