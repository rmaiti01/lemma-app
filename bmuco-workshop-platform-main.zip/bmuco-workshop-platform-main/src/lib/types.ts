// Database types matching the Supabase schema

export type UserRole = 'student' | 'mentor' | 'admin'
export type ApplicationStatus = 'pending' | 'accepted' | 'rejected'
export type CohortStatus = 'upcoming' | 'active' | 'completed'
export type EnrollmentStatus = 'active' | 'completed' | 'withdrawn'
export type TraceStatus = 'draft' | 'submitted' | 'reviewed' | 'revised'
export type PRFeedbackStatus =
  | 'not_submitted' | 'submitted' | 'feedback_received'
  | 'revision_submitted' | 'merged' | 'rejected'
export type FeedbackDecision = 'approve' | 'revise' | 'reject'
export type L2Status = 'applied' | 'accepted' | 'in_progress' | 'completed'
export type PRInteractionType =
  | 'zulip_discussion' | 'pr_submission' | 'reviewer_feedback'
  | 'revision' | 'merge' | 'rejection'

export interface Profile {
  id: string
  email: string
  full_name: string | null
  role: UserRole
  avatar_url: string | null
  created_at: string
  updated_at: string
}

export interface Application {
  id: string
  email: string
  full_name: string
  university: string | null
  degree_level: string | null
  mathematical_background: string | null
  lean_experience: string
  motivation: string | null
  weekly_hours_available: number | null
  how_heard: string | null
  status: ApplicationStatus
  admin_notes: string | null
  created_at: string
  updated_at: string
}

export interface Cohort {
  id: string
  name: string
  description: string | null
  start_date: string | null
  end_date: string | null
  status: CohortStatus
  created_at: string
}

export interface Enrollment {
  id: string
  student_id: string
  cohort_id: string
  mentor_id: string | null
  status: EnrollmentStatus
  created_at: string
}

export interface CurriculumWeek {
  id: string
  cohort_id: string
  week_number: number
  title: string
  phase: string
  description: string | null
  exit_competency: string | null
  checklist_items: ChecklistItem[]
  created_at: string
}

export interface ChecklistItem {
  id: string
  label: string
  description?: string
}

export interface StudentProgress {
  id: string
  student_id: string
  week_id: string
  completed_items: string[]  // array of checklist item IDs
  notes: string | null
  updated_at: string
}

export interface ErrorChainEntry {
  error: string
  diagnosis: string
  fix: string
  reasoning: string
}

export interface QualityAnnotations {
  style_compliance: { score: number; notes: string }
  generality: { score: number; notes: string }
  library_integration: { score: number; notes: string }
  api_completeness: { score: number; notes: string }
  documentation: { score: number; notes: string }
}

export interface AutoformaliserCorrectionRecord {
  ai_attempt: string
  errors_found: string[]
  human_fix: string
  explanation: string
}

export interface ProcessTrace {
  id: string
  student_id: string
  cohort_id: string | null
  title: string
  nl_statement: string | null
  informal_proof: string | null
  formal_proof: string | null
  step_level_alignment: Record<string, string> | null
  proof_development_journal: string | null
  ai_usage_log: string | null
  error_chain: ErrorChainEntry[]
  quality_annotations: Partial<QualityAnnotations>
  autoformaliser_correction_record: AutoformaliserCorrectionRecord | null
  pr_link: string | null
  pr_feedback_status: PRFeedbackStatus
  ready_for_pr: boolean
  status: TraceStatus
  version: number
  created_at: string
  updated_at: string
}

export interface ProcessTraceVersion {
  id: string
  trace_id: string
  version_number: number
  snapshot: Record<string, unknown>
  saved_at: string
  save_type: 'auto' | 'manual'
}

export interface PRInteraction {
  id: string
  trace_id: string
  interaction_type: PRInteractionType
  content: string | null
  url: string | null
  metadata: Record<string, unknown>
  created_at: string
}

export interface MentorFeedback {
  id: string
  trace_id: string
  mentor_id: string
  feedback_text: string | null
  rubric_scores: Partial<{
    style: number
    generality: number
    library_integration: number
    api_completeness: number
    documentation: number
  }>
  decision: FeedbackDecision | null
  created_at: string
}

export interface L2Track {
  id: string
  student_id: string
  cohort_id: string | null
  status: L2Status
  merged_pr_count: number
  start_date: string | null
  end_date: string | null
  notes: string | null
  created_at: string
  updated_at: string
}

export interface Assessment {
  id: string
  student_id: string
  cohort_id: string | null
  autoformaliser_correction_score: number | null
  independent_formalisation_score: number | null
  viva_score: number | null
  pr_submitted: boolean
  reviewer_feedback_received: boolean
  certified: boolean
  notes: string | null
  assessed_at: string
}
