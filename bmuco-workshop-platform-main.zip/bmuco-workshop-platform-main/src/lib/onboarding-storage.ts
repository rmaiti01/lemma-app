/** Key used to remember the homepage onboarding modal was seen or dismissed. */
export const ONBOARDING_STORAGE_KEY = 'bmuco_onboarded'

function tryLocalStorage(): Storage | null {
  try {
    const s = window.localStorage
    const k = `${ONBOARDING_STORAGE_KEY}__probe`
    s.setItem(k, '1')
    s.removeItem(k)
    return s
  } catch {
    return null
  }
}

function trySessionStorage(): Storage | null {
  try {
    const s = window.sessionStorage
    const k = `${ONBOARDING_STORAGE_KEY}__probe`
    s.setItem(k, '1')
    s.removeItem(k)
    return s
  } catch {
    return null
  }
}

function getStorage(): Storage | null {
  if (typeof window === 'undefined') return null
  return tryLocalStorage() ?? trySessionStorage()
}

export function isOnboarded(): boolean {
  if (typeof window === 'undefined') return true
  const s = getStorage()
  if (!s) return false
  return s.getItem(ONBOARDING_STORAGE_KEY) === '1'
}

export function setOnboarded(): void {
  if (typeof window === 'undefined') return
  const s = getStorage()
  if (!s) return
  try {
    s.setItem(ONBOARDING_STORAGE_KEY, '1')
  } catch {
    // ignore
  }
}

export function clearOnboarded(): void {
  if (typeof window === 'undefined') return
  for (const s of [tryLocalStorage(), trySessionStorage()]) {
    if (!s) continue
    try {
      s.removeItem(ONBOARDING_STORAGE_KEY)
    } catch {
      // ignore
    }
  }
}
