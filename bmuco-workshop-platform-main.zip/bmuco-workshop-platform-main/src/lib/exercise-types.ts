// Types for the 5-layer exercise workflow
// These complement the existing types.ts

export type ExerciseCategory = 'original_formalization' | 'ai_review' | 'naming_drill'
export type ExerciseTraceStatus = 'in_progress' | 'submitted' | 'reviewed'
export type GeneralityLevel = 'specific' | 'intermediate' | 'most_general'

export interface Exercise {
  id: string
  title: string
  difficulty: number
  week: number
  category: ExerciseCategory
  nl_statement: string
  nl_proof: string
  ai_lean_code: string | null
  ai_failure_modes: AIFailureMode[] | null
  reference_lean_code: string | null
  reference_name: string | null
  mathlib_search_hints: string[] | null
  generality_notes: string | null
  source: string
  tags: string[] | null
  created_at: string
}

export interface AIFailureMode {
  layer: number
  issue: string
  severity: 'high' | 'medium' | 'low'
  explanation?: string
}

export interface InventoryObject {
  name: string
  identified_type: string
}

export interface InventoryProperty {
  property: string
  mathlib_exists: boolean
  mathlib_name: string
}

export interface SearchLogEntry {
  tool: string
  query: string
  results_found: boolean
  notes?: string
}

export interface TacticChoice {
  tactic: string
  why: string
}

export interface AIReviewIssue {
  dimension: string
  verdict: 'pass' | 'fail' | 'unsure'
  explanation: string
  fix?: string
}

export interface StyleViolation {
  issue: string
  severity: string
}

export interface ExerciseTrace {
  id: string
  student_id: string
  exercise_id: string
  status: ExerciseTraceStatus

  // Layer 0
  layer0_objects: InventoryObject[] | null
  layer0_properties: InventoryProperty[] | null
  layer0_hypotheses: string | null
  layer0_conclusion: string | null
  layer0_search_log: SearchLogEntry[] | null
  layer0_completed_at: string | null

  // Layer 1
  layer1_type_choice: string | null
  layer1_generality_reasoning: string | null
  layer1_skeleton_code: string | null
  layer1_completed_at: string | null

  // Layer 2
  layer2_full_statement: string | null
  layer2_proposed_name: string | null
  layer2_naming_reasoning: string | null
  layer2_completed_at: string | null

  // Layer 3
  layer3_proof_code: string | null
  layer3_tactic_choices: TacticChoice[] | null
  layer3_witness_reasoning: string | null
  layer3_full_lean_code: string | null
  layer3_compiles: boolean | null
  layer3_completed_at: string | null

  // Layer 4
  layer4_exists_in_mathlib: boolean | null
  layer4_mathlib_name: string | null
  layer4_generality_check: string | null
  layer4_style_violations: StyleViolation[] | null
  layer4_api_completeness: string | null
  layer4_completed_at: string | null

  // AI Review
  ai_review_identified_issues: AIReviewIssue[] | null
  ai_review_corrected_code: string | null
  ai_review_reasoning: string | null

  // Metadata
  time_spent_minutes: number
  started_at: string
  submitted_at: string | null

  // Checklist
  checklist_all_layers_complete: boolean
  checklist_code_compiles: boolean
  checklist_name_checked: boolean
  checklist_searched_mathlib: boolean
  checklist_reasoning_filled: boolean
}

export interface ExerciseFeedback {
  id: string
  trace_id: string
  mentor_id: string
  layer0_score: number | null
  layer0_feedback: string | null
  layer0_approved: boolean | null
  layer1_score: number | null
  layer1_feedback: string | null
  layer1_approved: boolean | null
  layer2_score: number | null
  layer2_feedback: string | null
  layer2_approved: boolean | null
  layer3_score: number | null
  layer3_feedback: string | null
  layer3_approved: boolean | null
  layer4_score: number | null
  layer4_feedback: string | null
  layer4_approved: boolean | null
  overall_score: number | null
  overall_feedback: string | null
  ready_for_pr: boolean
  reviewed_at: string
}
