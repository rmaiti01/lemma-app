import { LEMMA_PROGRESS_SESSION_COOKIE } from '@/lib/progress-session'

/**
 * Stable browser session for anonymous traces / progress (matches /studio/api/progress cookie).
 * Client-only; call after mount or from event handlers.
 */
export function getOrCreateStudioSessionId(): string {
  if (typeof document === 'undefined') return ''
  const prefix = `${LEMMA_PROGRESS_SESSION_COOKIE}=`
  const hit = document.cookie.split('; ').find(c => c.startsWith(prefix))
  if (hit) {
    const v = hit.slice(prefix.length).trim()
    if (v) return v
  }
  const id = crypto.randomUUID()
  document.cookie = `${LEMMA_PROGRESS_SESSION_COOKIE}=${id}; Path=/; Max-Age=31536000; SameSite=Lax`
  return id
}
