'use client'

import type { ProofPacket } from './game-types'

// `is_first_attempt` / `previous_attempts_count` on proof rows are computed in POST /studio/api/proof-packets (not sent from the client).

const BUFFER: ProofPacket[] = []
const FLUSH_INTERVAL_MS = 10_000 // flush every 10s
const FLUSH_THRESHOLD = 20 // or when 20 packets buffered

let flushTimer: ReturnType<typeof setInterval> | null = null

/** Merge required packet fields with schema defaults (sparse call sites). */
export function withProofPacketDefaults(
  p: Pick<
    ProofPacket,
    | 'session_id'
    | 'level_id'
    | 'mode'
    | 'proof_state_before'
    | 'tactic_success'
    | 'step_number'
  > &
    Partial<Omit<ProofPacket, 'session_id' | 'level_id' | 'mode' | 'proof_state_before' | 'tactic_success' | 'step_number'>>
): ProofPacket {
  return {
    user_id: null,
    world_id: null,
    tactic_chosen: null,
    proof_state_after: null,
    tactics_rejected: [],
    premises_used: [],
    premises_available: [],
    confidence: null,
    time_to_decision_ms: null,
    hints_used_this_step: 0,
    hint_content: null,
    user_reasoning: null,
    expert_explanation: null,
    axle_endpoint: null,
    axle_response_ok: null,
    axle_duration_ms: null,
    axle_error_message: null,
    total_steps: null,
    difficulty_rating: null,
    topic_tags: [],
    dimension: null,
    dataset_label: null,
    ...p,
  }
}

export function emitPacket(packet: ProofPacket) {
  BUFFER.push(packet)
  if (BUFFER.length >= FLUSH_THRESHOLD) {
    void flushPackets()
  }
}

export async function flushPackets(opts?: { keepalive?: boolean }) {
  if (BUFFER.length === 0) return
  const batch = BUFFER.splice(0, BUFFER.length)

  try {
    const res = await fetch('/studio/api/proof-packets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ packets: batch }),
      keepalive: opts?.keepalive === true,
    })
    if (!res.ok) BUFFER.unshift(...batch)
  } catch {
    // Re-add failed packets to buffer for retry
    BUFFER.unshift(...batch)
  }
}

// Auto-flush on interval
if (typeof window !== 'undefined') {
  flushTimer = setInterval(() => void flushPackets(), FLUSH_INTERVAL_MS)
  window.addEventListener('beforeunload', () => {
    void flushPackets({ keepalive: true })
  })
}

void flushTimer
