/** @type {import('next').NextConfig} */
const nextConfig = {
  // No assetPrefix — required for custom domains (e.g. studio.bmuco.org). Set NEXT_PUBLIC_SITE_URL in env.

  async redirects() {
    return [
      { source: '/leaderboard', destination: '/studio/leaderboard', permanent: true },
      { source: '/about', destination: '/studio/about', permanent: true },
    ]
  },

  // Skip type checking in dev/build for speed — we check separately
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'axle.axiommath.ai',
      },
    ],
  },
}

export default nextConfig
