-- BMUCO Workshop Platform — Exercise Bank Schema
-- This migration adds the exercises table per the new 5-layer spec

-- ═══════════════════════════════════════════════════════
-- EXERCISES (the structured exercise bank)
-- ═══════════════════════════════════════════════════════

CREATE TABLE exercises (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,                    -- e.g. "Sum of two even numbers is even"
  difficulty INT NOT NULL CHECK (difficulty BETWEEN 1 AND 5),
  week INT NOT NULL,                      -- curriculum week (1-10)
  category TEXT NOT NULL CHECK (category IN ('original_formalization', 'ai_review', 'naming_drill')),
  
  -- The theorem in natural language
  nl_statement TEXT NOT NULL,             -- "If m and n are even, then m+n is even"
  nl_proof TEXT NOT NULL,                 -- "Since m=2a, n=2b, m+n=2(a+b)"
  
  -- For ai_review exercises: the AI-generated code to review
  ai_lean_code TEXT,                      -- The (flawed) AI-generated Lean code
  ai_failure_modes JSONB,                 -- Array of {layer, issue, explanation}
  
  -- The reference correct Lean code
  reference_lean_code TEXT,               -- Library-quality Lean version
  reference_name TEXT,                    -- Correct Mathlib-style name
  
  -- Hints and guidance
  mathlib_search_hints TEXT[],            -- e.g. ['Even', 'add'] — what to search for
  generality_notes TEXT,                  -- "This works for any AddMonoid, not just ℕ"
  
  -- Metadata
  source TEXT DEFAULT 'custom',           -- 'buzzard_course' | 'custom' | 'mathlib_gap'
  tags TEXT[],                            -- e.g. ['even', 'odd', 'number_theory']
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS
ALTER TABLE exercises ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read exercises
CREATE POLICY "Exercises readable by authenticated users" ON exercises
  FOR SELECT USING (auth.uid() IS NOT NULL);

-- Only admins can insert/update/delete
CREATE POLICY "Admins can manage exercises" ON exercises
  FOR ALL USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Indexes
CREATE INDEX idx_exercises_week ON exercises(week);
CREATE INDEX idx_exercises_category ON exercises(category);
CREATE INDEX idx_exercises_difficulty ON exercises(difficulty);
