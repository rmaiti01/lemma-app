-- BMUCO Workshop Platform — Process Traces V2 with 5-Layer Structure
-- This replaces/supplements the original process_traces with structured layer data

-- ═══════════════════════════════════════════════════════
-- EXERCISE TRACES (5-layer structured process traces)
-- ═══════════════════════════════════════════════════════

CREATE TABLE exercise_traces (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES profiles(id) NOT NULL,
  exercise_id UUID REFERENCES exercises(id) NOT NULL,
  status TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'submitted', 'reviewed')),
  
  -- Layer 0: Inventory
  layer0_objects JSONB,                   -- [{name: "m", identified_type: "ℕ"}, ...]
  layer0_properties JSONB,                -- [{property: "Even", mathlib_exists: true, mathlib_name: "Even"}]
  layer0_hypotheses TEXT,                 -- Free text: what do we assume?
  layer0_conclusion TEXT,                 -- Free text: what do we claim?
  layer0_search_log JSONB,               -- [{tool: "Moogle", query: "even addition", results_found: true}]
  layer0_completed_at TIMESTAMPTZ,
  
  -- Layer 1: Type Skeleton
  layer1_type_choice TEXT,                -- What type did the student choose? (ℕ, AddMonoid, etc.)
  layer1_generality_reasoning TEXT,       -- WHY did they choose this generality level?
  layer1_skeleton_code TEXT,              -- Just the type signature, no proof
  layer1_completed_at TIMESTAMPTZ,
  
  -- Layer 2: Statement
  layer2_full_statement TEXT,             -- Complete theorem statement (before := by)
  layer2_proposed_name TEXT,              -- Student's proposed Mathlib-style name
  layer2_naming_reasoning TEXT,           -- Why they chose this name
  layer2_completed_at TIMESTAMPTZ,
  
  -- Layer 3: Proof
  layer3_proof_code TEXT,                 -- The proof (after := by)
  layer3_tactic_choices JSONB,            -- [{tactic: "obtain", why: "unpack Even def"}, ...]
  layer3_witness_reasoning TEXT,          -- For the key step: why this witness?
  layer3_full_lean_code TEXT,             -- Complete compilable Lean code
  layer3_compiles BOOLEAN,               -- Did it compile in Codespaces?
  layer3_completed_at TIMESTAMPTZ,
  
  -- Layer 4: Culture Check
  layer4_exists_in_mathlib BOOLEAN,       -- Did student check if it already exists?
  layer4_mathlib_name TEXT,               -- If exists, what's the Mathlib name?
  layer4_generality_check TEXT,           -- Is our version as general as Mathlib's?
  layer4_style_violations JSONB,          -- Any linter issues found?
  layer4_api_completeness TEXT,           -- Should we also prove related theorems?
  layer4_completed_at TIMESTAMPTZ,
  
  -- For AI Review exercises (category = 'ai_review')
  ai_review_identified_issues JSONB,      -- [{layer, issue, explanation, fix}]
  ai_review_corrected_code TEXT,          -- Student's corrected version
  ai_review_reasoning TEXT,               -- Overall reflection on what was wrong and why
  
  -- Submission metadata
  time_spent_minutes INT DEFAULT 0,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  submitted_at TIMESTAMPTZ,
  
  -- Checklist gates (all must be true to submit)
  checklist_all_layers_complete BOOLEAN DEFAULT false,
  checklist_code_compiles BOOLEAN DEFAULT false,
  checklist_name_checked BOOLEAN DEFAULT false,
  checklist_searched_mathlib BOOLEAN DEFAULT false,
  checklist_reasoning_filled BOOLEAN DEFAULT false,
  
  -- Enforce one trace per student per exercise
  UNIQUE(student_id, exercise_id)
);

-- RLS
ALTER TABLE exercise_traces ENABLE ROW LEVEL SECURITY;

-- Students can manage their own traces
CREATE POLICY "Students manage own exercise traces" ON exercise_traces
  FOR ALL USING (student_id = auth.uid());

-- Mentors can read traces of any student (simplified for pilot)
CREATE POLICY "Mentors read exercise traces" ON exercise_traces
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'mentor')
  );

-- Admins can read all traces
CREATE POLICY "Admins read all exercise traces" ON exercise_traces
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Indexes
CREATE INDEX idx_exercise_traces_student ON exercise_traces(student_id);
CREATE INDEX idx_exercise_traces_exercise ON exercise_traces(exercise_id);
CREATE INDEX idx_exercise_traces_status ON exercise_traces(status);
