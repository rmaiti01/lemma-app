-- BMUCO Studio — Game Schema
-- New tables for the gamified Lean Quality Game
-- Existing tables are left untouched for backward compatibility

-- ═══════════════════════════════════════════════════════
-- 1. Game worlds + levels (static content)
-- ═══════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS game_worlds (
  id          SMALLINT PRIMARY KEY,
  name        TEXT NOT NULL,
  slug        TEXT NOT NULL UNIQUE,
  description TEXT,
  type        TEXT NOT NULL,
  unlock_stars INTEGER DEFAULT 0,
  is_active   BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS game_levels (
  id            SERIAL PRIMARY KEY,
  world_id      SMALLINT REFERENCES game_worlds(id),
  level_number  SMALLINT NOT NULL,
  title         TEXT NOT NULL,
  skill_tag     TEXT,
  proof_display TEXT NOT NULL,
  informal_statement TEXT,
  issues        JSONB NOT NULL,
  decoys        JSONB DEFAULT '[]',
  total_issues  SMALLINT NOT NULL,
  is_boss       BOOLEAN DEFAULT FALSE,
  UNIQUE(world_id, level_number)
);

-- 2. Player progress
CREATE TABLE IF NOT EXISTS player_progress (
  user_id         UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  total_stars     INTEGER DEFAULT 0,
  total_points    INTEGER DEFAULT 0,
  current_streak  INTEGER DEFAULT 0,
  longest_streak  INTEGER DEFAULT 0,
  last_played_at  TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS level_completions (
  id            SERIAL PRIMARY KEY,
  user_id       UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  level_id      INTEGER REFERENCES game_levels(id),
  stars         SMALLINT NOT NULL,
  points        INTEGER NOT NULL,
  issues_found  JSONB NOT NULL,
  issues_missed JSONB NOT NULL,
  false_positives JSONB DEFAULT '[]',
  time_seconds  INTEGER,
  completed_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, level_id)
);

-- 3. Trace collection (the real business value — invisible to players)
CREATE TABLE IF NOT EXISTS game_traces (
  id              SERIAL PRIMARY KEY,
  session_id      TEXT,
  user_id         UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  level_id        INTEGER REFERENCES game_levels(id),
  world_id        SMALLINT,
  level_number    SMALLINT,
  proof_shown     TEXT NOT NULL,
  issues_identified JSONB NOT NULL,
  issues_missed   JSONB NOT NULL,
  false_positives JSONB DEFAULT '[]',
  stars_earned    SMALLINT,
  points_earned   INTEGER,
  time_seconds    INTEGER,
  player_skill    TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Leaderboard view
CREATE OR REPLACE VIEW leaderboard AS
  SELECT
    p.user_id,
    u.raw_user_meta_data->>'user_name' AS github_username,
    u.raw_user_meta_data->>'avatar_url' AS avatar_url,
    p.total_stars,
    p.total_points,
    p.current_streak,
    RANK() OVER (ORDER BY p.total_stars DESC, p.total_points DESC) AS rank
  FROM player_progress p
  JOIN auth.users u ON u.id = p.user_id
  ORDER BY rank;

-- 5. Row-level security
ALTER TABLE player_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE level_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_traces ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own progress" ON player_progress FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users upsert own progress" ON player_progress FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users read own completions" ON level_completions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users insert own completions" ON level_completions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Traces insert by anyone" ON game_traces FOR INSERT WITH CHECK (true);
CREATE POLICY "Game worlds public" ON game_worlds FOR SELECT USING (true);
CREATE POLICY "Game levels public" ON game_levels FOR SELECT USING (true);
