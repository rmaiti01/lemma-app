-- Per-step proof training packets (ML export / DPO / retrieval signals)

CREATE TABLE IF NOT EXISTS proof_packets (
  id SERIAL PRIMARY KEY,
  created_at TIMESTAMPTZ DEFAULT NOW(),

  -- Session context
  session_id TEXT NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  level_id TEXT NOT NULL,
  world_id SMALLINT,
  mode TEXT NOT NULL CHECK (mode IN ('mcq', 'build', 'trace', 'review')),

  -- The core training triple
  proof_state_before TEXT NOT NULL,
  tactic_chosen TEXT,
  proof_state_after TEXT,
  tactic_success BOOLEAN NOT NULL,

  -- Negative examples (DPO pairs)
  tactics_rejected JSONB DEFAULT '[]',

  -- Premise retrieval signal
  premises_used JSONB DEFAULT '[]',
  premises_available JSONB DEFAULT '[]',

  -- Quality signal
  confidence INTEGER CHECK (confidence BETWEEN 1 AND 5),
  time_to_decision_ms INTEGER,
  hints_used_this_step INTEGER DEFAULT 0,
  hint_content TEXT,

  -- Annotation (from Trace mode)
  user_reasoning TEXT,
  expert_explanation TEXT,

  -- AXLE verification
  axle_endpoint TEXT,
  axle_response_ok BOOLEAN,
  axle_duration_ms INTEGER,
  axle_error_message TEXT,

  -- Ordering within session
  step_number INTEGER NOT NULL,
  total_steps INTEGER,

  -- Difficulty estimation
  difficulty_rating SMALLINT,
  topic_tags TEXT[],

  -- Dataset labeling
  dimension TEXT,
  dataset_label TEXT
);

CREATE INDEX idx_pp_session ON proof_packets(session_id);
CREATE INDEX idx_pp_mode ON proof_packets(mode);
CREATE INDEX idx_pp_dimension ON proof_packets(dimension);
CREATE INDEX idx_pp_success ON proof_packets(tactic_success);
CREATE INDEX idx_pp_level ON proof_packets(level_id);

ALTER TABLE proof_packets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert proof packets" ON proof_packets
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Admins read proof packets" ON proof_packets
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );
