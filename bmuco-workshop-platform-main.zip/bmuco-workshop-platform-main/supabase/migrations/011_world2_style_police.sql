-- World 2 Style Police — seed game_worlds + game_levels
-- Generated from src/lib/seed-data/world1-levels.ts

INSERT INTO game_worlds (id, name, slug, description, type, unlock_stars, is_active)
VALUES (
  2,
  'Style Police',
  'style-police',
  'Proofs that compile but violate Mathlib conventions. Naming, generality, tactic choice — spot what a reviewer would reject.',
  'style_police',
  8,
  true
)
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  slug = EXCLUDED.slug,
  description = EXCLUDED.description,
  type = EXCLUDED.type,
  unlock_stars = EXCLUDED.unlock_stars,
  is_active = EXCLUDED.is_active;

DELETE FROM game_levels WHERE world_id = 2;

INSERT INTO game_levels (world_id, level_number, title, skill_tag, proof_display, informal_statement, issues, decoys, total_issues, is_boss)
VALUES (
  2,
  1,
  'Even.add — wrong predicate',
  'predicate_choice',
  $w2l1$import Mathlib

namespace World2

theorem even_add_even (m n : ℕ) (hm : ∃ k, m = 2 * k) (hn : ∃ k, n = 2 * k) :
    ∃ k, m + n = 2 * k := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  use a + b
  omega

end World2$w2l1$,
  'The sum of two even integers is even.',
  '[{"id":"predicate","label":"Uses raw ∃ instead of the Even predicate from Mathlib","explanation":"Mathlib defines Even n as ∃ k, n = k + k. Using a raw existential means this proof cannot interact with any other Even theorem in Mathlib. The correct signature is: theorem Even.add {m n : ℤ} (hm : Even m) (hn : Even n) : Even (m + n)","is_real_issue":true},{"id":"generality","label":"Hardcoded to ℕ instead of a general type like AddMonoid","explanation":"The Mathlib version of Even.add works over any AddMonoid, not just ℕ. Restricting to ℕ makes the theorem less reusable.","is_real_issue":true},{"id":"naming","label":"Named even_add_even instead of Even.add (no dot notation)","explanation":"Mathlib uses dot notation for theorems about a type. Even.add lives in the Even namespace, enabling hm.add hn syntax. The name even_add_even is verbose and does not enable this.","is_real_issue":true},{"id":"convention","label":"Uses 2 * k instead of k + k (Mathlib convention for Even)","explanation":"Mathlib defines Even n as ∃ k, n = k + k, not 2 * k. This matters because k + k works in any AddMonoid while 2 * k requires a multiplication structure.","is_real_issue":true}]'::jsonb,
  '[{"id":"decoy_omega","label":"omega is not a valid Lean 4 tactic","is_real_issue":false},{"id":"decoy_witness","label":"The witness a + b is mathematically incorrect","is_real_issue":false}]'::jsonb,
  4,
  false
);

INSERT INTO game_levels (world_id, level_number, title, skill_tag, proof_display, informal_statement, issues, decoys, total_issues, is_boss)
VALUES (
  2,
  2,
  'Even.add with fake axiom',
  'axiom_abuse',
  $w2l2$import Mathlib

namespace World2

axiom add_double_comm (a b : ℕ) : 2 * a + 2 * b = 2 * (a + b)

theorem even_add_even (m n : ℕ) (hm : ∃ k, m = 2 * k) (hn : ∃ k, n = 2 * k) :
    ∃ k, m + n = 2 * k := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  use a + b
  rw [ha, hb]
  exact add_double_comm a b

end World2$w2l2$,
  'The sum of two even natural numbers is even (with an unnecessary axiom declaration).',
  '[{"id":"fake_axiom","label":"Declares an axiom for a trivially provable fact","explanation":"axiom add_double_comm bypasses the proof checker entirely. The fact 2*a + 2*b = 2*(a+b) is trivially provable with ring. Declaring it as an axiom is a serious red flag — axioms should only be used for foundational assumptions, never for derivable facts.","is_real_issue":true},{"id":"predicate","label":"Uses raw ∃ instead of the Even predicate","explanation":"Same issue as Level 2-1: should use Even from Mathlib.","is_real_issue":true},{"id":"generality","label":"Restricted to ℕ instead of general type","explanation":"Should work over any type with the right algebraic structure.","is_real_issue":true}]'::jsonb,
  '[{"id":"decoy_obtain","label":"obtain should be replaced with rcases","is_real_issue":false},{"id":"decoy_witness","label":"The witness a + b is incorrect","is_real_issue":false}]'::jsonb,
  3,
  false
);

INSERT INTO game_levels (world_id, level_number, title, skill_tag, proof_display, informal_statement, issues, decoys, total_issues, is_boss)
VALUES (
  2,
  3,
  'mul_inv_cancel — overcomplicated',
  'proof_length',
  $w2l3$import Mathlib

namespace World2

theorem h₁ {G : Type*} [Group G] (h₂ : G) : h₂ * h₂⁻¹ = 1 := by
  have h₃ : h₂ * h₂⁻¹ = h₂ * h₂⁻¹ := rfl
  have h₄ : h₂ * h₂⁻¹ = 1 := mul_inv_cancel h₂
  exact h₄

end World2$w2l3$,
  'For any element g of a group G, g * g⁻¹ = 1.',
  '[{"id":"naming_subscripts","label":"Variables named h₁, h₂, h₃, h₄ instead of descriptive names","explanation":"The theorem is named h₁, the group element is h₂, and helper hypotheses are h₃ and h₄. In Mathlib, you would name the element g, the theorem mul_inv_cancel_self or similar. Subscript soup makes code unreadable.","is_real_issue":true},{"id":"redundant_step","label":"h₃ is completely useless (states x = x)","explanation":"The hypothesis h₃ : h₂ * h₂⁻¹ = h₂ * h₂⁻¹ is true by rfl and is never used. It adds nothing to the proof.","is_real_issue":true},{"id":"overcomplicated","label":"Could be proved with exact mul_inv_cancel h₂ directly","explanation":"The entire proof could be one line: exact mul_inv_cancel h₂. The intermediate hypothesis h₄ restates what exact would provide directly.","is_real_issue":true}]'::jsonb,
  '[{"id":"decoy_group","label":"Should specify the group is commutative","is_real_issue":false},{"id":"decoy_result","label":"g * g⁻¹ = 1 is mathematically wrong","is_real_issue":false}]'::jsonb,
  3,
  false
);

INSERT INTO game_levels (world_id, level_number, title, skill_tag, proof_display, informal_statement, issues, decoys, total_issues, is_boss)
VALUES (
  2,
  4,
  'le_trans — misleading comments',
  'documentation',
  $w2l4$import Mathlib

namespace World2

-- Proof by induction on the structure of the ordering
theorem le_trans_proof (a b c : ℕ) (hab : a ≤ b) (hbc : b ≤ c) : a ≤ c := by
  -- First we perform case analysis on whether a = b
  -- Then we use the inductive hypothesis on the successor case
  omega

end World2$w2l4$,
  'Transitivity of ≤ on natural numbers.',
  '[{"id":"comment_lies","label":"Comments describe induction and case analysis but the proof just calls omega","explanation":"The comments claim the proof works by induction with case analysis on a = b and an inductive hypothesis on successors. The actual proof is a single call to omega. The comments are completely fabricated and misleading.","is_real_issue":true},{"id":"reinvention","label":"Re-proves a standard library fact instead of citing le_trans","explanation":"Transitivity of ≤ on ℕ is available as le_trans or Nat.le_trans in Mathlib. Re-proving it (even correctly with omega) is wasteful when the existing lemma is more informative and already integrated into the simp set.","is_real_issue":true}]'::jsonb,
  '[{"id":"decoy_omega_invalid","label":"omega is not a valid Lean tactic","is_real_issue":false},{"id":"decoy_types","label":"Should use ℤ instead of ℕ for generality","is_real_issue":false},{"id":"decoy_order","label":"The hypotheses hab and hbc are in the wrong order","is_real_issue":false}]'::jsonb,
  2,
  false
);

INSERT INTO game_levels (world_id, level_number, title, skill_tag, proof_display, informal_statement, issues, decoys, total_issues, is_boss)
VALUES (
  2,
  5,
  'sq_nonneg — type drift',
  'type_mismatch',
  $w2l5$import Mathlib

namespace World2

-- Proof that squares are non-negative for all real numbers
theorem sq_nonneg_proof (n : ℕ) : 0 ≤ n * n := by
  exact Nat.zero_le (n * n)

end World2$w2l5$,
  'The square of any real number is non-negative.',
  '[{"id":"type_mismatch","label":"Claims to prove it for reals but actually proves it for ℕ","explanation":"The comment says \"for all real numbers\" but the code uses (n : ℕ). For naturals, n * n ≥ 0 is trivially true because ALL naturals are ≥ 0. The interesting theorem is about reals where negative inputs can occur.","is_real_issue":true},{"id":"trivial_proof","label":"The proof is trivially true for ℕ — it does not demonstrate the actual mathematical content","explanation":"Nat.zero_le says 0 ≤ n for ANY natural n. So 0 ≤ n * n is just \"all naturals are non-negative.\" This sidesteps the real mathematical content: squaring preserves non-negativity even for negative inputs.","is_real_issue":true}]'::jsonb,
  '[{"id":"decoy_sq","label":"Should use n ^ 2 notation instead of n * n","is_real_issue":false},{"id":"decoy_lemma","label":"Nat.zero_le is not a valid Mathlib lemma","is_real_issue":false}]'::jsonb,
  2,
  false
);

INSERT INTO game_levels (world_id, level_number, title, skill_tag, proof_display, informal_statement, issues, decoys, total_issues, is_boss)
VALUES (
  2,
  6,
  'Boss: Even.add — full review',
  'full_review',
  $w2l6$import Mathlib

namespace World2

axiom add_double_comm (a b : ℕ) : 2 * a + 2 * b = 2 * (a + b)

-- Proof by structural analysis of the existential witnesses
theorem even_add_even (m n : ℕ) (hm : ∃ k, m = 2 * k) (hn : ∃ k, n = 2 * k) :
    ∃ k, m + n = 2 * k := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  use a + b
  rw [ha, hb]
  exact add_double_comm a b

end World2$w2l6$,
  'The sum of two even numbers is even (boss level: find ALL the issues).',
  '[{"id":"fake_axiom","label":"Declares an axiom instead of proving the helper lemma","explanation":"The top of the file declares axiom add_double_comm — an unproven assumption accepted on faith. In Lean, axiom bypasses the proof checker entirely. This fact (2*a + 2*b = 2*(a+b)) is trivially provable with ring, so declaring it as an axiom is a red flag.","is_real_issue":true},{"id":"predicate","label":"Uses raw ∃ instead of the Even predicate","explanation":"Mathlib defines Even n as ∃ k, n = k + k. Using a raw existential means this proof cannot interact with any other Even theorem in Mathlib.","is_real_issue":true},{"id":"generality","label":"Hardcoded to ℕ instead of a general type","explanation":"The Mathlib version works over any AddMonoid, not just ℕ.","is_real_issue":true},{"id":"naming","label":"Named even_add_even instead of Even.add","explanation":"Mathlib uses dot notation: Even.add is in the Even namespace, so you can write hm.add hn.","is_real_issue":true},{"id":"convention","label":"Uses 2 * k instead of k + k (Mathlib convention for Even)","explanation":"Mathlib defines Even n as ∃ k, n = k + k (not 2 * k). This matters because k + k works in any AddMonoid, while 2 * k requires multiplication.","is_real_issue":true}]'::jsonb,
  '[{"id":"decoy_witness","label":"The witness a + b is incorrect","is_real_issue":false},{"id":"decoy_obtain","label":"obtain should be replaced with rcases","is_real_issue":false},{"id":"decoy_comment","label":"The comment \"structural analysis\" is wrong terminology","is_real_issue":false}]'::jsonb,
  5,
  true
);
