-- Anonymous + authenticated progress: surrogate PK, nullable user_id, session key.
-- RLS stays provider-agnostic: auth.uid() = user_id (anonymous rows are read/written via service role in API routes).

ALTER TABLE player_progress ADD COLUMN progress_row_id BIGSERIAL;

ALTER TABLE player_progress DROP CONSTRAINT player_progress_pkey;

ALTER TABLE player_progress ADD PRIMARY KEY (progress_row_id);

CREATE UNIQUE INDEX player_progress_user_id_uidx
  ON player_progress (user_id)
  WHERE user_id IS NOT NULL;

ALTER TABLE player_progress ALTER COLUMN user_id DROP NOT NULL;

ALTER TABLE player_progress ADD COLUMN lemma_session_id TEXT;

CREATE UNIQUE INDEX player_progress_lemma_session_uidx
  ON player_progress (lemma_session_id)
  WHERE lemma_session_id IS NOT NULL;

DROP POLICY IF EXISTS "Users read own progress" ON player_progress;
CREATE POLICY "Users read own progress" ON player_progress
  FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users upsert own progress" ON player_progress;
CREATE POLICY "Users upsert own progress" ON player_progress
  FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
