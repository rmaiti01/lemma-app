-- BMUCO Workshop Platform — Database Schema
-- Run this in the Supabase SQL Editor after creating your project

-- ═══════════════════════════════════════════════════════
-- ENUMS
-- ═══════════════════════════════════════════════════════

CREATE TYPE user_role AS ENUM ('student', 'mentor', 'admin');
CREATE TYPE application_status AS ENUM ('pending', 'accepted', 'rejected');
CREATE TYPE cohort_status AS ENUM ('upcoming', 'active', 'completed');
CREATE TYPE enrollment_status AS ENUM ('active', 'completed', 'withdrawn');
CREATE TYPE trace_status AS ENUM ('draft', 'submitted', 'reviewed', 'revised');
CREATE TYPE pr_feedback_status AS ENUM (
  'not_submitted', 'submitted', 'feedback_received', 
  'revision_submitted', 'merged', 'rejected'
);
CREATE TYPE feedback_decision AS ENUM ('approve', 'revise', 'reject');
CREATE TYPE l2_status AS ENUM ('applied', 'accepted', 'in_progress', 'completed');
CREATE TYPE pr_interaction_type AS ENUM ('zulip_discussion', 'pr_submission', 'reviewer_feedback', 'revision', 'merge', 'rejection');

-- ═══════════════════════════════════════════════════════
-- PROFILES (extends auth.users)
-- ═══════════════════════════════════════════════════════

CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  role user_role DEFAULT 'student',
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public profiles are viewable by everyone" ON profiles
  FOR SELECT USING (true);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins can update any profile" ON profiles
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ═══════════════════════════════════════════════════════
-- APPLICATIONS
-- ═══════════════════════════════════════════════════════

CREATE TABLE applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  university TEXT,
  degree_level TEXT,
  mathematical_background TEXT,
  lean_experience TEXT DEFAULT 'none',
  motivation TEXT,
  weekly_hours_available INTEGER,
  how_heard TEXT,
  status application_status DEFAULT 'pending',
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit an application" ON applications
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Admins can view all applications" ON applications
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Admins can update applications" ON applications
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- COHORTS
-- ═══════════════════════════════════════════════════════

CREATE TABLE cohorts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  start_date DATE,
  end_date DATE,
  status cohort_status DEFAULT 'upcoming',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE cohorts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Cohorts viewable by authenticated users" ON cohorts
  FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can manage cohorts" ON cohorts
  FOR ALL USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- ENROLLMENTS (student ↔ cohort ↔ mentor)
-- ═══════════════════════════════════════════════════════

CREATE TABLE enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  cohort_id UUID NOT NULL REFERENCES cohorts(id) ON DELETE CASCADE,
  mentor_id UUID REFERENCES profiles(id),
  status enrollment_status DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, cohort_id)
);

ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students see own enrollment" ON enrollments
  FOR SELECT USING (student_id = auth.uid());

CREATE POLICY "Mentors see assigned students" ON enrollments
  FOR SELECT USING (mentor_id = auth.uid());

CREATE POLICY "Admins can manage enrollments" ON enrollments
  FOR ALL USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- CURRICULUM WEEKS (configurable per cohort)
-- ═══════════════════════════════════════════════════════

CREATE TABLE curriculum_weeks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cohort_id UUID NOT NULL REFERENCES cohorts(id) ON DELETE CASCADE,
  week_number INTEGER NOT NULL CHECK (week_number >= 0 AND week_number <= 10),
  title TEXT NOT NULL,
  phase TEXT NOT NULL,
  description TEXT,
  exit_competency TEXT,
  checklist_items JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(cohort_id, week_number)
);

ALTER TABLE curriculum_weeks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Curriculum viewable by authenticated users" ON curriculum_weeks
  FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can manage curriculum" ON curriculum_weeks
  FOR ALL USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- STUDENT PROGRESS (self-reported per week)
-- ═══════════════════════════════════════════════════════

CREATE TABLE student_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  week_id UUID NOT NULL REFERENCES curriculum_weeks(id) ON DELETE CASCADE,
  completed_items JSONB DEFAULT '[]'::jsonb,
  notes TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, week_id)
);

ALTER TABLE student_progress ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students manage own progress" ON student_progress
  FOR ALL USING (student_id = auth.uid());

CREATE POLICY "Mentors view assigned student progress" ON student_progress
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM enrollments e 
      WHERE e.student_id = student_progress.student_id 
      AND e.mentor_id = auth.uid()
    )
  );

CREATE POLICY "Admins view all progress" ON student_progress
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- PROCESS TRACES
-- ═══════════════════════════════════════════════════════

CREATE TABLE process_traces (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  cohort_id UUID REFERENCES cohorts(id),
  title TEXT NOT NULL DEFAULT 'Untitled Trace',
  
  -- Core fields
  nl_statement TEXT,                      -- Natural language statement
  informal_proof TEXT,                    -- Informal mathematical proof
  formal_proof TEXT,                      -- Lean 4 code
  step_level_alignment JSONB,             -- Map: informal step → formal step
  proof_development_journal TEXT,         -- Free text narrative
  
  -- AI interaction
  ai_usage_log TEXT,                      -- Tools used, prompts, quality
  
  -- Error tracking
  error_chain JSONB DEFAULT '[]'::jsonb,  -- [{error, diagnosis, fix, reasoning}]
  
  -- Quality self-assessment
  quality_annotations JSONB DEFAULT '{}'::jsonb, -- {style, generality, integration, api, docs} 1-5 + notes
  
  -- Autoformaliser correction (Weeks 9-10)
  autoformaliser_correction_record JSONB, -- {ai_attempt, errors_found, human_fix, explanation}
  
  -- PR tracking
  pr_link TEXT,
  pr_feedback_status pr_feedback_status DEFAULT 'not_submitted',
  ready_for_pr BOOLEAN DEFAULT false,     -- Mentor gate
  
  -- Meta
  status trace_status DEFAULT 'draft',
  version INTEGER DEFAULT 1,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE process_traces ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students manage own traces" ON process_traces
  FOR ALL USING (student_id = auth.uid());

CREATE POLICY "Mentors view assigned student traces" ON process_traces
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM enrollments e 
      WHERE e.student_id = process_traces.student_id 
      AND e.mentor_id = auth.uid()
    )
  );

CREATE POLICY "Admins view all traces" ON process_traces
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- PROCESS TRACE VERSIONS (auto-save history)
-- ═══════════════════════════════════════════════════════

CREATE TABLE process_trace_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trace_id UUID NOT NULL REFERENCES process_traces(id) ON DELETE CASCADE,
  version_number INTEGER NOT NULL,
  snapshot JSONB NOT NULL,                -- Full snapshot of all trace fields
  saved_at TIMESTAMPTZ DEFAULT NOW(),
  save_type TEXT DEFAULT 'auto'           -- 'auto' or 'manual'
);

ALTER TABLE process_trace_versions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students view own trace versions" ON process_trace_versions
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM process_traces pt 
      WHERE pt.id = process_trace_versions.trace_id 
      AND pt.student_id = auth.uid()
    )
  );

CREATE POLICY "Admins view all trace versions" ON process_trace_versions
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- PR INTERACTIONS (Zulip discussions + review rounds)
-- ═══════════════════════════════════════════════════════

CREATE TABLE pr_interactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trace_id UUID NOT NULL REFERENCES process_traces(id) ON DELETE CASCADE,
  interaction_type pr_interaction_type NOT NULL,
  content TEXT,                           -- Discussion content or feedback
  url TEXT,                               -- Link to Zulip thread, GitHub PR, etc.
  metadata JSONB DEFAULT '{}'::jsonb,     -- Flexible additional data
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE pr_interactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students manage own PR interactions" ON pr_interactions
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM process_traces pt 
      WHERE pt.id = pr_interactions.trace_id 
      AND pt.student_id = auth.uid()
    )
  );

CREATE POLICY "Mentors view assigned student PR interactions" ON pr_interactions
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM process_traces pt
      JOIN enrollments e ON e.student_id = pt.student_id
      WHERE pt.id = pr_interactions.trace_id 
      AND e.mentor_id = auth.uid()
    )
  );

CREATE POLICY "Admins view all PR interactions" ON pr_interactions
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- MENTOR FEEDBACK
-- ═══════════════════════════════════════════════════════

CREATE TABLE mentor_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trace_id UUID NOT NULL REFERENCES process_traces(id) ON DELETE CASCADE,
  mentor_id UUID NOT NULL REFERENCES profiles(id),
  feedback_text TEXT,
  
  -- 5-dimension Mathlib quality checklist
  rubric_scores JSONB DEFAULT '{}'::jsonb, -- {style, generality, library_integration, api_completeness, documentation} 1-5
  
  decision feedback_decision,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE mentor_feedback ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Mentors manage own feedback" ON mentor_feedback
  FOR ALL USING (mentor_id = auth.uid());

CREATE POLICY "Students view feedback on own traces" ON mentor_feedback
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM process_traces pt 
      WHERE pt.id = mentor_feedback.trace_id 
      AND pt.student_id = auth.uid()
    )
  );

CREATE POLICY "Admins view all feedback" ON mentor_feedback
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- L2 PIPELINE
-- ═══════════════════════════════════════════════════════

CREATE TABLE l2_tracks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  cohort_id UUID REFERENCES cohorts(id),
  status l2_status DEFAULT 'applied',
  merged_pr_count INTEGER DEFAULT 0,
  start_date DATE,
  end_date DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE l2_tracks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students view own L2 track" ON l2_tracks
  FOR SELECT USING (student_id = auth.uid());

CREATE POLICY "Admins manage L2 tracks" ON l2_tracks
  FOR ALL USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- ASSESSMENTS
-- ═══════════════════════════════════════════════════════

CREATE TABLE assessments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  cohort_id UUID REFERENCES cohorts(id),
  autoformaliser_correction_score INTEGER CHECK (autoformaliser_correction_score BETWEEN 0 AND 100),
  independent_formalisation_score INTEGER CHECK (independent_formalisation_score BETWEEN 0 AND 100),
  viva_score INTEGER CHECK (viva_score BETWEEN 0 AND 100),
  pr_submitted BOOLEAN DEFAULT false,
  reviewer_feedback_received BOOLEAN DEFAULT false,
  certified BOOLEAN DEFAULT false,
  notes TEXT,
  assessed_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE assessments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students view own assessments" ON assessments
  FOR SELECT USING (student_id = auth.uid());

CREATE POLICY "Admins manage assessments" ON assessments
  FOR ALL USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- ═══════════════════════════════════════════════════════
-- INDEXES
-- ═══════════════════════════════════════════════════════

CREATE INDEX idx_enrollments_student ON enrollments(student_id);
CREATE INDEX idx_enrollments_mentor ON enrollments(mentor_id);
CREATE INDEX idx_enrollments_cohort ON enrollments(cohort_id);
CREATE INDEX idx_process_traces_student ON process_traces(student_id);
CREATE INDEX idx_process_traces_cohort ON process_traces(cohort_id);
CREATE INDEX idx_process_traces_status ON process_traces(status);
CREATE INDEX idx_trace_versions_trace ON process_trace_versions(trace_id);
CREATE INDEX idx_pr_interactions_trace ON pr_interactions(trace_id);
CREATE INDEX idx_mentor_feedback_trace ON mentor_feedback(trace_id);
CREATE INDEX idx_student_progress_student ON student_progress(student_id);
CREATE INDEX idx_l2_tracks_student ON l2_tracks(student_id);
CREATE INDEX idx_applications_status ON applications(status);

-- ═══════════════════════════════════════════════════════
-- UPDATED_AT TRIGGER
-- ═══════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON applications
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON process_traces
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON student_progress
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON l2_tracks
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
