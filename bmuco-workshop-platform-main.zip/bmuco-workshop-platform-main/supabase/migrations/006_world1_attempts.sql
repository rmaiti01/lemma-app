-- World 1: The Meta-Proof Trap — attempt tracking table
-- Run this in Supabase SQL Editor

CREATE TABLE IF NOT EXISTS world1_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid UNIQUE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  level_id text NOT NULL,
  started_at timestamptz DEFAULT now(),
  submitted_at timestamptz,

  -- Blank states (full JSON from useLevelState)
  blanks jsonb DEFAULT '{}'::jsonb,

  -- Thought log
  running_notes text DEFAULT '',
  verdict text CHECK (verdict IN ('works', 'broken', 'unsure')),
  verdict_reasoning text DEFAULT '',
  verdict_correct boolean,

  -- AXLE verification
  final_lean_accepted boolean,
  lean_error_messages jsonb DEFAULT '[]'::jsonb,

  -- Hints
  hints_used int DEFAULT 0,
  hint3_used boolean DEFAULT false,
  hints_toggle_on boolean DEFAULT false,

  -- Score
  score int,
  stars int CHECK (stars IN (1, 2, 3))
);

-- Index for fast user lookups
CREATE INDEX IF NOT EXISTS idx_w1a_user ON world1_attempts(user_id);
CREATE INDEX IF NOT EXISTS idx_w1a_level ON world1_attempts(level_id);

-- RLS: users can only see/modify their own rows
ALTER TABLE world1_attempts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own attempts"
  ON world1_attempts FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own attempts"
  ON world1_attempts FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own attempts"
  ON world1_attempts FOR UPDATE
  USING (auth.uid() = user_id);
