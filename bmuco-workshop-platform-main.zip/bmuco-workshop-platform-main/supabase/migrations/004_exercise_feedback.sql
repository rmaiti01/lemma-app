-- BMUCO Workshop Platform — Mentor Feedback for Exercise Traces
-- Per-layer mentor feedback for the 5-layer exercise workflow

CREATE TABLE exercise_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trace_id UUID REFERENCES exercise_traces(id) ON DELETE CASCADE NOT NULL,
  mentor_id UUID REFERENCES profiles(id) NOT NULL,
  
  -- Per-layer scores and feedback
  layer0_score INT CHECK (layer0_score BETWEEN 1 AND 5),
  layer0_feedback TEXT,
  layer0_approved BOOLEAN,
  
  layer1_score INT CHECK (layer1_score BETWEEN 1 AND 5),
  layer1_feedback TEXT,
  layer1_approved BOOLEAN,
  
  layer2_score INT CHECK (layer2_score BETWEEN 1 AND 5),
  layer2_feedback TEXT,
  layer2_approved BOOLEAN,
  
  layer3_score INT CHECK (layer3_score BETWEEN 1 AND 5),
  layer3_feedback TEXT,
  layer3_approved BOOLEAN,
  
  layer4_score INT CHECK (layer4_score BETWEEN 1 AND 5),
  layer4_feedback TEXT,
  layer4_approved BOOLEAN,
  
  -- Overall
  overall_score INT CHECK (overall_score BETWEEN 1 AND 5),
  overall_feedback TEXT,
  ready_for_pr BOOLEAN DEFAULT false,
  
  reviewed_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- One feedback per mentor per trace
  UNIQUE(trace_id, mentor_id)
);

-- RLS
ALTER TABLE exercise_feedback ENABLE ROW LEVEL SECURITY;

-- Mentors can manage their own feedback
CREATE POLICY "Mentors manage own exercise feedback" ON exercise_feedback
  FOR ALL USING (mentor_id = auth.uid());

-- Students can read feedback on their own traces
CREATE POLICY "Students view feedback on own exercise traces" ON exercise_feedback
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM exercise_traces et
      WHERE et.id = exercise_feedback.trace_id
      AND et.student_id = auth.uid()
    )
  );

-- Admins can read all feedback
CREATE POLICY "Admins view all exercise feedback" ON exercise_feedback
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Indexes
CREATE INDEX idx_exercise_feedback_trace ON exercise_feedback(trace_id);
CREATE INDEX idx_exercise_feedback_mentor ON exercise_feedback(mentor_id);
