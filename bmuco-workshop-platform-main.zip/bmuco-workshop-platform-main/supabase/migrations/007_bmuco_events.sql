-- BMUCO event logging table for AXLE/build-review-trace telemetry

create table if not exists bmuco_events (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  session_id text not null,
  level_id text not null,
  mode text not null,
  step_id text not null,
  event text not null,
  value jsonb,
  duration_ms integer,
  confidence integer,
  annotation text
);

create index if not exists bmuco_events_session_id_idx on bmuco_events (session_id);
create index if not exists bmuco_events_level_mode_idx on bmuco_events (level_id, mode);
