-- Display name for leaderboard + partial session flags + leaderboard view privacy

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS username TEXT;

ALTER TABLE world1_attempts ADD COLUMN IF NOT EXISTS is_partial BOOLEAN DEFAULT false;

ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS is_partial BOOLEAN DEFAULT false;

-- Allow trace rows without a numeric game_levels FK (slug-based world 1 levels)
ALTER TABLE game_traces ALTER COLUMN level_id DROP NOT NULL;

-- Leaderboard: show custom username when set; never expose raw GitHub login or email here.
-- Previous view used u.raw_user_meta_data->>'user_name' which is often null → blank names.
CREATE OR REPLACE VIEW leaderboard AS
  SELECT
    p.user_id,
    CASE
      WHEN pr.username IS NOT NULL AND btrim(pr.username) <> '' THEN btrim(pr.username)
      ELSE 'Anonymous'
    END AS github_username,
    COALESCE(pr.avatar_url, u.raw_user_meta_data->>'avatar_url') AS avatar_url,
    p.total_stars,
    p.total_points,
    p.current_streak,
    RANK() OVER (ORDER BY p.total_stars DESC, p.total_points DESC) AS rank
  FROM player_progress p
  JOIN auth.users u ON u.id = p.user_id
  LEFT JOIN profiles pr ON pr.id = p.user_id
  ORDER BY rank;
