-- First-time formalization tracking (proof packets + level completions)

ALTER TABLE proof_packets
  ADD COLUMN IF NOT EXISTS is_first_attempt BOOLEAN DEFAULT true;

ALTER TABLE proof_packets
  ADD COLUMN IF NOT EXISTS previous_attempts_count INTEGER DEFAULT 0;

ALTER TABLE level_completions
  ADD COLUMN IF NOT EXISTS is_first_completion BOOLEAN DEFAULT true;
