-- Lemma — AXLE pipeline proof-packet columns
-- Adds columns required for the proof-data collection pipeline
-- Uses IF NOT EXISTS guards to be idempotent

-- ═══════════════════════════════════════════════════════
-- game_traces: new proof-packet fields
-- ═══════════════════════════════════════════════════════

ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS proof_state_before    TEXT;
ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS proof_state_after     TEXT;
ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS tactic_chosen         JSONB;
ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS alternatives_rejected JSONB DEFAULT '[]'::jsonb;
ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS reasoning_text        TEXT;
ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS hints_used            INTEGER DEFAULT 0;
ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS axle_verified         BOOLEAN;
ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS expert_quality_label  TEXT;
ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS confidence_scores     JSONB;
ALTER TABLE game_traces ADD COLUMN IF NOT EXISTS annotations           JSONB;

-- Make proof_shown nullable (trace mode does not always show a proof)
ALTER TABLE game_traces ALTER COLUMN proof_shown DROP NOT NULL;
ALTER TABLE game_traces ALTER COLUMN issues_identified DROP NOT NULL;
ALTER TABLE game_traces ALTER COLUMN issues_missed DROP NOT NULL;

-- ═══════════════════════════════════════════════════════
-- game_levels: theorem and review data fields
-- ═══════════════════════════════════════════════════════

ALTER TABLE game_levels ADD COLUMN IF NOT EXISTS theorem_name     TEXT;
ALTER TABLE game_levels ADD COLUMN IF NOT EXISTS formal_statement TEXT;
ALTER TABLE game_levels ADD COLUMN IF NOT EXISTS review_proof     TEXT;
ALTER TABLE game_levels ADD COLUMN IF NOT EXISTS review_issues    JSONB;
ALTER TABLE game_levels ADD COLUMN IF NOT EXISTS review_decoys    JSONB;

-- ═══════════════════════════════════════════════════════
-- world1_attempts: AXLE verification and proof state fields
-- ═══════════════════════════════════════════════════════

ALTER TABLE world1_attempts ADD COLUMN IF NOT EXISTS axle_verified      BOOLEAN;
ALTER TABLE world1_attempts ADD COLUMN IF NOT EXISTS tactic_chosen      JSONB;
ALTER TABLE world1_attempts ADD COLUMN IF NOT EXISTS proof_state_before TEXT;
ALTER TABLE world1_attempts ADD COLUMN IF NOT EXISTS proof_state_after  TEXT;
