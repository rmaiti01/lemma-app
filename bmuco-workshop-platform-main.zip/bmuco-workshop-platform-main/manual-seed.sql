-- BMUCO Studio — Manual Seed SQL
-- Paste this into Supabase SQL Editor (supabase.com > your project > SQL Editor)
-- Run it once to update World 1 + all 6 levels.

-- ═══ Step 1: Update World 1 description ═══
UPDATE game_worlds
SET description = 'Completed the Natural Number Game? Great. Now spot surface-level red flags in Lean 4 proofs.'
WHERE id = 1;

-- ═══ Step 2: Update Level 1-1 ═══
UPDATE game_levels
SET
  proof_display = 'theorem add_zero_eq (n : ℕ) : n + 0 = n := by
  induction n with
  | zero =>
    -- Base case: 0 + 0 = 0
    simp [Nat.add_zero]
  | succ k ih =>
    -- Inductive step: (k + 1) + 0 = k + 1
    rw [Nat.succ_add]
    rw [Nat.add_zero]
    rw [Nat.add_zero] at ih
    have h1 : k + 0 = k := ih
    have h2 : k + 1 = Nat.succ k := rfl
    rw [← h2]
    simp [Nat.add_zero]
    -- Clean up remaining goals
    rfl',
  issues = '[
    {"id":"length","label":"Proof is absurdly long for a trivial fact","explanation":"n + 0 = n is true by definition in Lean — it''s literally rfl (reflexivity) or simp. This 14-line proof with induction, rewrites, and helper hypotheses is massive overkill.","is_real_issue":true},
    {"id":"induction","label":"Uses induction when it''s not needed","explanation":"Induction is a powerful technique, but using it to prove n + 0 = n is like using a sledgehammer to hang a picture. The fact holds definitionally.","is_real_issue":true},
    {"id":"redundant","label":"Contains redundant steps (rw [Nat.add_zero] appears twice)","explanation":"The same rewrite Nat.add_zero is applied twice in quick succession, and a helper hypothesis h1 restates what ih already says. Redundant steps indicate sloppy reasoning.","is_real_issue":true}
  ]'::jsonb,
  decoys = '[
    {"id":"decoy_types","label":"Should use ℤ (integers) instead of ℕ (naturals)","is_real_issue":false},
    {"id":"decoy_name","label":"Theorem name add_zero_eq is incorrect","is_real_issue":false}
  ]'::jsonb
WHERE world_id = 1 AND level_number = 1;

-- ═══ Step 3: Update Level 1-2 ═══
UPDATE game_levels
SET
  proof_display = 'theorem h₁ {G : Type*} [Group G] (h₂ : G) : h₂ * h₂⁻¹ = 1 := by
  have h₃ : h₂ * h₂⁻¹ = h₂ * h₂⁻¹ := rfl
  have h₄ : h₂ * h₂⁻¹ = 1 := mul_inv_cancel h₂
  exact h₄',
  issues = '[
    {"id":"naming_subscripts","label":"Variables named h₁, h₂, h₃, h₄ instead of descriptive names","explanation":"The theorem is named h₁, the group element is h₂, and helper hypotheses are h₃ and h₄. In real mathematical code, you''d name the element g, the theorem mul_inv_cancel_self or similar. Subscript soup makes code unreadable.","is_real_issue":true},
    {"id":"redundant_step","label":"h₃ states something is equal to itself (completely useless)","explanation":"The hypothesis h₃ says h₂ * h₂⁻¹ = h₂ * h₂⁻¹, which is true by definition (rfl). It''s never used and adds nothing.","is_real_issue":true},
    {"id":"overcomplicated","label":"Creates an unnecessary helper to state what could be proved directly","explanation":"Instead of have h₄ ... exact h₄, the proof could just be exact mul_inv_cancel h₂. The intermediate hypothesis adds a step for no reason.","is_real_issue":true}
  ]'::jsonb,
  decoys = '[
    {"id":"decoy_group","label":"Should specify the group is commutative","is_real_issue":false},
    {"id":"decoy_result","label":"The result g * g⁻¹ = 1 is mathematically wrong","is_real_issue":false}
  ]'::jsonb
WHERE world_id = 1 AND level_number = 2;

-- ═══ Step 4: Update Level 1-3 ═══
UPDATE game_levels
SET
  proof_display = '-- Proof by induction on the structure of the ordering
theorem le_trans_proof (a b c : ℕ) (hab : a ≤ b) (hbc : b ≤ c) : a ≤ c := by
  -- First we perform case analysis on whether a = b
  -- Then we use the inductive hypothesis on the successor case
  omega',
  issues = '[
    {"id":"comment_lies","label":"Comments describe \"induction\" and \"case analysis\" but the proof just calls omega","explanation":"The comments claim the proof works by induction with case analysis on a = b and an inductive hypothesis on successors. But the actual proof is a single call to omega. The comments are completely fabricated.","is_real_issue":true},
    {"id":"not_mathlib","label":"Re-proves a standard library fact instead of citing it","explanation":"Transitivity of ≤ on natural numbers is available as le_trans or Nat.le_trans. Re-proving it (even with omega) is wasteful when the existing lemma would be more informative.","is_real_issue":true}
  ]'::jsonb,
  decoys = '[
    {"id":"decoy_omega","label":"omega is not a valid Lean tactic","is_real_issue":false},
    {"id":"decoy_types","label":"Should use ℤ instead of ℕ for generality","is_real_issue":false},
    {"id":"decoy_order","label":"The hypotheses hab and hbc are in the wrong order","is_real_issue":false}
  ]'::jsonb
WHERE world_id = 1 AND level_number = 3;

-- ═══ Step 5: Update Level 1-4 ═══
UPDATE game_levels
SET
  proof_display = '-- Proof that squares are non-negative for all real numbers
theorem sq_nonneg_proof (n : ℕ) : 0 ≤ n * n := by
  exact Nat.zero_le (n * n)',
  issues = '[
    {"id":"type_mismatch","label":"Claims to prove it for real numbers but actually proves it for ℕ (naturals)","explanation":"The natural language statement says \"for all real numbers\" but the Lean code uses (n : ℕ). For naturals, n * n ≥ 0 is trivially true because ALL naturals are ≥ 0. The interesting theorem is about reals.","is_real_issue":true},
    {"id":"trivial_proof","label":"The proof is trivially true for ℕ and doesn''t demonstrate the actual mathematical content","explanation":"Nat.zero_le says 0 ≤ n for ANY natural number n. So 0 ≤ n * n is just a special case of \"all naturals are non-negative.\" This sidesteps the real content: squaring preserves non-negativity even for negative inputs.","is_real_issue":true},
    {"id":"comment_mismatch","label":"Comment says \"real numbers\" but code uses natural numbers","explanation":"The code comment also claims this is about real numbers, reinforcing the mismatch.","is_real_issue":true}
  ]'::jsonb,
  decoys = '[
    {"id":"decoy_sq","label":"Should use x ^ 2 notation instead of n * n","is_real_issue":false},
    {"id":"decoy_proof_wrong","label":"Nat.zero_le is not a valid lemma","is_real_issue":false}
  ]'::jsonb
WHERE world_id = 1 AND level_number = 4;

-- ═══ Step 6: Update Level 1-5 ═══
UPDATE game_levels
SET
  proof_display = 'theorem list_length_zero_eq_nil {α : Type*} (l : List α) (h : l.length = 0) : l = [] := by
  cases l with
  | nil => rfl
  | cons head tail =>
    simp [List.length] at h
    simp [List.length] at h
    exact absurd h (by omega)
    exact absurd h (by omega)',
  issues = '[
    {"id":"duplicate_simp","label":"simp [List.length] at h appears twice in a row","explanation":"The exact same simplification is applied twice consecutively. The second call does nothing because the first already simplified h.","is_real_issue":true},
    {"id":"duplicate_absurd","label":"exact absurd h (by omega) appears twice in a row","explanation":"The same finishing tactic appears twice in a row. The second line is dead code that will never execute.","is_real_issue":true},
    {"id":"overcomplicated_case","label":"The cons case is overcomplicated — simp alone would close it","explanation":"In the cons case, simp [List.length] at h immediately gives h : False. A single contradiction would suffice.","is_real_issue":true}
  ]'::jsonb,
  decoys = '[
    {"id":"decoy_type","label":"The type variable α should be concrete (like ℕ)","is_real_issue":false},
    {"id":"decoy_nil","label":"The nil case should use simp instead of rfl","is_real_issue":false}
  ]'::jsonb
WHERE world_id = 1 AND level_number = 5;

-- ═══ Step 7: Update Level 1-6 (Boss) ═══
UPDATE game_levels
SET
  proof_display = 'axiom add_double_comm (a b : ℕ) : 2 * a + 2 * b = 2 * (a + b)

-- Proof by structural analysis of the existential witnesses
theorem even_add_even (m n : ℕ) (hm : ∃ k, m = 2 * k) (hn : ∃ k, n = 2 * k) :
    ∃ k, m + n = 2 * k := by
  obtain ⟨a, ha⟩ := hm
  obtain ⟨b, hb⟩ := hn
  use a + b
  rw [ha, hb]
  exact add_double_comm a b',
  issues = '[
    {"id":"fake_axiom","label":"Declares an axiom instead of proving the helper lemma","explanation":"The top of the file declares axiom add_double_comm — an unproven assumption accepted on faith. In Lean, axiom bypasses the proof checker entirely. This fact (2*a + 2*b = 2*(a+b)) is trivially provable with ring, so declaring it as an axiom is a red flag.","is_real_issue":true},
    {"id":"predicate","label":"Uses raw ∃ instead of the Even predicate","explanation":"Mathlib defines Even n as ∃ k, n = k + k. Using a raw existential ∃ k, m = 2 * k means this proof can''t interact with any other theorem about Even in Mathlib.","is_real_issue":true},
    {"id":"generality","label":"Hardcoded to ℕ instead of a general type","explanation":"The Mathlib version works over any AddMonoid — not just ℕ or ℤ. By restricting to ℕ, the proof is much less useful.","is_real_issue":true},
    {"id":"naming","label":"Named even_add_even instead of Even.add","explanation":"Mathlib uses dot notation: Even.add is in the Even namespace, so you can write hm.add hn. The name even_add_even is verbose and doesn''t enable dot notation.","is_real_issue":true},
    {"id":"convention","label":"Uses 2 * k instead of k + k (Mathlib convention for Even)","explanation":"Mathlib defines Even n as ∃ k, n = k + k (not 2 * k). This matters because k + k works in any AddMonoid, while 2 * k requires multiplication.","is_real_issue":true}
  ]'::jsonb,
  decoys = '[
    {"id":"decoy_witness","label":"The witness a + b is incorrect","is_real_issue":false},
    {"id":"decoy_obtain","label":"obtain should be replaced with rcases","is_real_issue":false},
    {"id":"decoy_comment","label":"The comment \"structural analysis\" is wrong terminology","is_real_issue":false}
  ]'::jsonb
WHERE world_id = 1 AND level_number = 6;
