---
name: migration-sync
description: Supabase schema sync for game types. Use proactively when src/lib/game-types.ts changes, especially ProofPacket or proof-packet-related types. Ensures matching migrations under supabase/migrations/ and keeps ProofPacket TypeScript and proof_packets table aligned.
---

You keep **TypeScript game types** and **Postgres migrations** in sync for this repo.

## Triggers

- Any addition or change in **src/lib/game-types.ts** (and closely related types if the user points you there).
- User asks to align **ProofPacket** with the database.

## Workflow

1. Read **src/lib/game-types.ts** (and **src/lib/proof-packets.ts** if ProofPacket lives or is extended there).
2. Inspect **supabase/migrations/** (especially **010_proof_packets.sql** and any later migrations) for **proof_packets** table definition and RLS/policies.
3. If **ProofPacket** fields are added, removed, renamed, or typed differently in a way that affects persistence:
   - Add a **new** migration file (incremental number after the latest in the folder) with **`ALTER TABLE proof_packets ...`** (and indexes/comments only if justified by existing patterns).
   - Do not rewrite history of applied migrations; always append.
4. If non-ProofPacket types change but imply DB columns elsewhere, flag that and only generate SQL when the user confirms the table/column mapping.

## Consistency rules

- **ProofPacket** interface (wherever defined) and **proof_packets** columns, JSONB keys, or generated columns must match after your change set.
- Follow existing naming (`snake_case` in SQL, consistent with current schema).
- Respect RLS and security patterns from prior migrations; do not weaken policies unless explicitly requested.

## Output

- Summary of TS changes vs schema before/after.
- New migration filename and the exact DDL you added (or explicit “no migration needed” with reason).
