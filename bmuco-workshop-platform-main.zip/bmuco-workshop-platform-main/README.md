# BMUCO Studio

**Finished with the Natural Number Game? Continue with our game to learn how to become a good Lean code reviewer!**

## Stack

- **Framework**: Next.js 14 (App Router)
- **Auth/DB**: Supabase
- **Verification**: Axiom Math AXLE API for Lean 4 proof checking
- **Styling**: Custom CSS design system (light theme, geometric accents)

## Getting Started

```bash
npm install
cp .env.local.example .env.local  # Add your Supabase keys
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Architecture

```
src/
├── app/                    # Next.js App Router
│   ├── page.tsx            # Landing page with inline exercise
│   ├── about/              # About page
│   ├── auth/               # Sign in / sign up
│   ├── dashboard/          # Protected routes
│   │   ├── student/        # Exercise workflow, curriculum, traces
│   │   ├── mentor/         # Review inbox, student management
│   │   └── admin/          # Applications, users, export, analytics
│   └── api/
│       ├── axle/           # AXLE API proxy (check, verify)
│       └── admin/          # Admin data export
├── components/
│   ├── InlineExercise.tsx  # Auth-free first exercise on landing page
│   ├── exercise/           # ExerciseWorkflow, AIReviewWorkflow, AxlePanel
│   ├── Navbar.tsx
│   └── Footer.tsx
└── lib/
    ├── axiommath.ts        # AXLE API client
    ├── data.ts             # 10-week curriculum definition
    ├── exercise-types.ts   # 5-layer exercise type system
    └── seed-data/          # Exercise bank (12 exercises across 3 tiers)
```

## License

MIT
