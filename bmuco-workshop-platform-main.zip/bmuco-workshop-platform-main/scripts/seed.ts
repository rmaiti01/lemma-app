// Seed script for the exercise bank
// Run with: npx tsx scripts/seed.ts
// Requires SUPABASE_SERVICE_ROLE_KEY in .env.local

import { createClient } from '@supabase/supabase-js'
import { SEED_EXERCISES } from '../src/lib/seed-data/exercises'
import * as dotenv from 'dotenv'
import * as path from 'path'

// Load env from .env.local
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') })

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !serviceRoleKey) {
  console.error('❌ Missing environment variables.')
  console.error('   Required: NEXT_PUBLIC_SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY')
  console.error('   Add SUPABASE_SERVICE_ROLE_KEY to your .env.local file.')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, serviceRoleKey, {
  auth: { persistSession: false }
})

async function seedExercises() {
  console.log('🌱 Seeding exercise bank...')
  console.log(`   ${SEED_EXERCISES.length} exercises to insert\n`)

  // Check if exercises already exist
  const { data: existing, error: checkError } = await supabase
    .from('exercises')
    .select('id', { count: 'exact' })

  if (checkError) {
    console.error('❌ Error checking existing exercises:', checkError.message)
    console.error('   Make sure the exercises table exists. Run the SQL migration first:')
    console.error('   supabase/migrations/002_exercises.sql')
    process.exit(1)
  }

  if (existing && existing.length > 0) {
    console.log(`⚠️  Found ${existing.length} existing exercises.`)
    console.log('   Clearing and re-seeding...\n')

    const { error: deleteError } = await supabase
      .from('exercises')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000') // Delete all

    if (deleteError) {
      console.error('❌ Error clearing exercises:', deleteError.message)
      process.exit(1)
    }
  }

  // Insert exercises
  for (const exercise of SEED_EXERCISES) {
    const { error } = await supabase
      .from('exercises')
      .insert(exercise)

    if (error) {
      console.error(`❌ Error inserting "${exercise.title}":`, error.message)
    } else {
      const marker = exercise.category === 'ai_review' ? '🤖' : '📐'
      console.log(`   ${marker} ${exercise.title} (Week ${exercise.week}, ⭐${exercise.difficulty})`)
    }
  }

  // Verify
  const { data: final, error: verifyError } = await supabase
    .from('exercises')
    .select('id, title, category, week, difficulty')
    .order('week')
    .order('difficulty')

  if (verifyError) {
    console.error('\n❌ Error verifying:', verifyError.message)
  } else {
    console.log(`\n✅ Seeded ${final?.length || 0} exercises successfully!`)
    console.log('\n   Breakdown:')

    const byCategory = (final || []).reduce((acc, ex) => {
      acc[ex.category] = (acc[ex.category] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    for (const [cat, count] of Object.entries(byCategory)) {
      console.log(`   - ${cat}: ${count}`)
    }
  }
}

seedExercises().catch(console.error)
