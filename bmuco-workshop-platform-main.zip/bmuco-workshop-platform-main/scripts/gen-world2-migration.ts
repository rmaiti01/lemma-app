import { writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { WORLD_2, WORLD_2_LEVELS } from '../src/lib/seed-data/world1-levels'

function escSqlString(s: string) {
  return s.replace(/'/g, "''")
}

const lines: string[] = []
lines.push('-- World 2 Style Police — seed game_worlds + game_levels')
lines.push('-- Generated from src/lib/seed-data/world1-levels.ts')
lines.push('')
lines.push('INSERT INTO game_worlds (id, name, slug, description, type, unlock_stars, is_active)')
lines.push('VALUES (')
lines.push(`  ${WORLD_2.id},`)
lines.push(`  '${escSqlString(WORLD_2.name)}',`)
lines.push(`  '${escSqlString(WORLD_2.slug)}',`)
lines.push(`  '${escSqlString(WORLD_2.description)}',`)
lines.push(`  '${escSqlString(WORLD_2.type)}',`)
lines.push(`  ${WORLD_2.unlock_stars},`)
lines.push(`  ${WORLD_2.is_active}`)
lines.push(')')
lines.push('ON CONFLICT (id) DO UPDATE SET')
lines.push('  name = EXCLUDED.name,')
lines.push('  slug = EXCLUDED.slug,')
lines.push('  description = EXCLUDED.description,')
lines.push('  type = EXCLUDED.type,')
lines.push('  unlock_stars = EXCLUDED.unlock_stars,')
lines.push('  is_active = EXCLUDED.is_active;')
lines.push('')
lines.push('DELETE FROM game_levels WHERE world_id = 2;')
lines.push('')

for (const L of WORLD_2_LEVELS) {
  const tag = `w2l${L.level_number}`
  lines.push(
    `INSERT INTO game_levels (world_id, level_number, title, skill_tag, proof_display, informal_statement, issues, decoys, total_issues, is_boss)`
  )
  lines.push(`VALUES (`)
  lines.push(`  ${L.world_id},`)
  lines.push(`  ${L.level_number},`)
  lines.push(`  '${escSqlString(L.title)}',`)
  lines.push(`  '${escSqlString(L.skill_tag || '')}',`)
  lines.push(`  $${tag}$${L.proof_display}$${tag}$,`)
  lines.push(`  '${escSqlString(L.informal_statement || '')}',`)
  lines.push(`  '${escSqlString(JSON.stringify(L.issues))}'::jsonb,`)
  lines.push(`  '${escSqlString(JSON.stringify(L.decoys))}'::jsonb,`)
  lines.push(`  ${L.total_issues},`)
  lines.push(`  ${L.is_boss}`)
  lines.push(`);`)
  lines.push('')
}

const outPath = join(process.cwd(), 'supabase/migrations/011_world2_style_police.sql')
writeFileSync(outPath, lines.join('\n'))
console.log('Wrote', outPath)
